// 实例化vue对象
/*new Vue({
	el:"#app",
	data:{
		name:"sds",	两个数据间必须用逗号间隔，否则无法生效
		cost1:"", 
		cost2:"",
		flag:true
	},
	methods:{

	},
	computed:{
		calculateSum(){
			return Number(this.cost1)+Number(this.cost2);
		}
	}
});
*/
new Vue({
	el:"#condition",
	data:{	
		authorityList:[
				{text:'--请选择--',value:'0'},
				{text:'普通用户',value:'1'},
				{text:'管理员',value:'2'},
				{text:'超级管理员',value:'3'}
			],		
		searchTags:[ 
					 {labeltext:'姓名:',name:"username",id:'username'},
					 {labeltext:'部门:',name:"deptname",id:'deptname'},
					 {labeltext:'职位:',name:"userposition",id:'userposition'},
					 {labeltext:'电话号码:',name:"usertel",id:'usertel'}
					 ],					
	},
	methods:{

	},
	computed:{

	}
});