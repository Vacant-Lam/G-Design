package com.cpms.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.cpms.pojo.CpmsUser;
import com.cpms.pojo.User_Dept_Com;
import com.cpms.service.ManageService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

@Controller
@RequestMapping("/manage")
public class ManageController {
	
	private static final int PAGE_SIZE = 5;
	
	@Autowired
	private ManageService manageService;
	
/*	@RequestMapping("/queryUsers")
	public ModelAndView queryUsers(
			HttpSession session,
			@RequestParam(value="pageNo",required=false,defaultValue="1")int pageNo){
		
		//pageNo ҳ��	  pageSize ÿҳ��¼��
		PageHelper.startPage(pageNo, PAGE_SIZE);
		//���ò�ѯ����ʱ���ݿ������ļ��еķ�ҳ�������һ�����أ������ݷ�ҳ 
		List<CpmsUser> list = manageService.findUsers();	
		
		ModelAndView mv = new ModelAndView();
		//����pageInfo���󣬷�ҳbean
		PageInfo pageInfo = new PageInfo<>(list);
		mv.addObject("userList", list);
		mv.addObject("pageInfo", pageInfo);
		mv.setViewName("admin");
		return mv;
	}*/
	
/*	@RequestMapping("/queryUDC")
	public ModelAndView queryUDC(
			HttpSession session,
			@RequestParam(value="pageNo",required=false,defaultValue="1")int pageNo){
		
		//pageNo ҳ��	  pageSize ÿҳ��¼��
		PageHelper.startPage(pageNo, PAGE_SIZE);
		//���ò�ѯ����ʱ���ݿ������ļ��еķ�ҳ�������һ�����أ������ݷ�ҳ 
		List<User_Dept_Com> list = manageService.findUDC();
		for (User_Dept_Com user_Dept_Com : list) {
			System.out.println("****"+user_Dept_Com);
		}
			
		ModelAndView mv = new ModelAndView();
		//����pageInfo���󣬷�ҳbean
		PageInfo pageInfo = new PageInfo<>(list);
		mv.addObject("udcList", list);
		mv.addObject("pageInfo", pageInfo);
		mv.setViewName("admin");
		return mv;
	}*/
	
	@RequestMapping("/queryUdcByCondition")
	@ResponseBody
	public ModelAndView queryUdcByCondition(@ModelAttribute("condition")User_Dept_Com condition,
			HttpSession session,
			@RequestParam(value="pageNo",required=false,defaultValue="1")int pageNo){
		
		System.out.println("******"+condition);
		
		//pageNo ҳ��	  pageSize ÿҳ��¼��
		PageHelper.startPage(pageNo, PAGE_SIZE);
		//���ò�ѯ����ʱ���ݿ������ļ��еķ�ҳ�������һ�����أ������ݷ�ҳ 
		List<User_Dept_Com> list = manageService.findUsersByCondition(condition);
//		for (User_Dept_Com user_Dept_Com : list) {
//			System.out.println("****"+user_Dept_Com);
//		}
		
		
		//����pageInfo���󣬷�ҳbean
		PageInfo pageInfo = new PageInfo<>(list);
		
		ModelAndView mv = new ModelAndView();
		mv.addObject("udcList", list);
		mv.addObject("pageInfo", pageInfo);
		mv.setViewName("admin");
		return mv;
	}
	
	//�鿴�û���Ϣ
	@RequestMapping("/scanUdcById")	
	public @ResponseBody User_Dept_Com scanUdcById(String userId){
		System.out.println("********"+userId);
		return manageService.getUserInfo(userId);
		
	}
	
}
