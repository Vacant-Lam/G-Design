package com.cpms.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cpms.pojo.CpmsUser;
import com.cpms.service.ManageService;
import com.cpms.service.UserService;

@Controller
@RequestMapping("/user")
public class UserController {
	
		@Autowired 
		private UserService userService;
		
		@Autowired 
		private ManageService manageService;
	
		//ע��
		@RequestMapping("/doLogout") 
		public String doLogout(){
			return "login";
		}
		
		@RequestMapping("/doLogin")
		public String doLogin(String userid,
							  String userpassword,
							  String validateCode,
							  Model model,
							  HttpSession session,
							  HttpServletRequest request){
//			System.out.println("**********1.******");
			String code = (String) session.getAttribute("Code");
//			System.out.println("**********2.******"+validateCode);
			
			//�����ж���֤��
			if(!validateCode.equals(code)){
				model.addAttribute("errorMsg","��֤�벻��ȷ");
				return "login";
			}
			
			CpmsUser loginUser = userService.login(userid, userpassword);
			if(loginUser!=null){//��½�ɹ�
				//����user��session
				session.setAttribute("user", loginUser);
				if(loginUser.getUsertype()==0) { 
					return "redirect:/manage/queryUdcByCondition";
				}
				return "redirect:/auction/queryAuctions";//�ض���AuctionController,��ѯ��Ʒ�����ݣ���ҳ��
			} else{//ʧ��
				//���������ʾ����������
				model.addAttribute("errorMsg","�˺Ż����벻��ȷ");
				return "login";
			}
		}
		

	}


