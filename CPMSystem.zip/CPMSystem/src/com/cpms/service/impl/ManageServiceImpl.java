package com.cpms.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cpms.mapper.CpmsUserMapper;
import com.cpms.mapper.U_D_C_Mapper;
import com.cpms.pojo.CpmsUser;
import com.cpms.pojo.CpmsUserExample;
import com.cpms.pojo.User_Dept_Com;
import com.cpms.service.ManageService;

@Service
public class ManageServiceImpl implements ManageService {

	@Autowired
	private CpmsUserMapper cpmsUserMapper;
	
	@Autowired
	private U_D_C_Mapper udcMapper;
	
/*	//��ѯ�����û���Ϣ
	public List<CpmsUser> findUsers() {	
		List<CpmsUser> list = cpmsUserMapper.selectUsers();
		if(list!=null&&list.size()>0) {
			return list;
		}

		return null;
	}
	
	//�û������š���˾������ͼ��ѯ
	public List<User_Dept_Com> findUDC() {	
		List<User_Dept_Com> list = udcMapper.selectUDC();
		if(list!=null&&list.size()>0) {
			return list;
		}

		return null;
	}*/
	
	//�û���Ϣ��ϲ�ѯ����
	public List<User_Dept_Com> findUsersByCondition(User_Dept_Com condition) {

//		System.out.println("*************"+condition.getJobContent()+"**************");
		/*if(condition!=null) 
		{
			if(condition.getUsername()!=null&&!"".equals(condition.getUsername()))
			{
				criteria.andUsernameLike("%"+condition.getUsername()+"%");
			}
			if(condition.getDeptname()!=null&&!"".equals(condition.getDeptname()))
			{
				criteria.andJobPlaceLike("%"+condition.getJobPlace()+"%");
			}
			if(condition.getJobContent()!=null&&!"".equals(condition.getJobContent()))
			{
				criteria.andJobContentLike("%"+condition.getJobContent()+"%");
			}
			if(condition.getJobNeed()!=null&&!"".equals(condition.getJobNeed()))
			{
				criteria.andJobNeedLike(condition.getJobNeed());
			}
		}
		jobExample.setOrderByClause("job_id desc");*/
		List<User_Dept_Com> userList = udcMapper.selectUsersByCondition(condition);
		
		return userList; 
	}

	public User_Dept_Com getUserInfo(String userId) {
		// TODO Auto-generated method stub
		return udcMapper.selectUserById(userId);
	}
	
}
