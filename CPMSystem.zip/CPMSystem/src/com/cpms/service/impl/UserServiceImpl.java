package com.cpms.service.impl;

import com.cpms.mapper.CpmsUserMapper;
import com.cpms.pojo.CpmsUser;
import com.cpms.pojo.CpmsUserExample;
import com.cpms.pojo.User_Dept_Com;
import com.cpms.service.UserService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private CpmsUserMapper cpmsuserMapper;
	
	public CpmsUser login(String userid, String userpassword) { 

		//��ѯ�����ķ�װ��
		CpmsUserExample cpmsUserExample = new CpmsUserExample();
		
		//ƴ��sql��ѯ����
		CpmsUserExample.Criteria criteria = cpmsUserExample.createCriteria();
		
		//ƴ��username��userpassword  select * from auctionuser where username=? and userpassword=?
		criteria.andUseridEqualTo(userid);
		criteria.andUserpasswordEqualTo(userpassword);
		
		//�����˺���ΨһԼ��
		List<CpmsUser> list = cpmsuserMapper.selectByExample(cpmsUserExample);
		if(list!=null && list.size()>0){
			return list.get(0);
		}
		
		return null;
	}



}
