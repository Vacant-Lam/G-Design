package com.cpms.service;

import java.util.List;

import com.cpms.pojo.CpmsUser;
import com.cpms.pojo.User_Dept_Com;

public interface ManageService {

/*	List<CpmsUser> findUsers(); 
	
	List<User_Dept_Com> findUDC();*/
	
	List<User_Dept_Com> findUsersByCondition(User_Dept_Com condition);
	
	User_Dept_Com getUserInfo(String userId);   

}
