package com.cpms.service;

import com.cpms.pojo.CpmsUser;
import com.cpms.pojo.User_Dept_Com;

public interface UserService { 
	public CpmsUser login(String userid,String password);
	

}
