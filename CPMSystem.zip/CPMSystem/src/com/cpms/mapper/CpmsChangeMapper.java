package com.cpms.mapper;

import com.cpms.pojo.CpmsChange;
import com.cpms.pojo.CpmsChangeExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface CpmsChangeMapper {
    int countByExample(CpmsChangeExample example);

    int deleteByExample(CpmsChangeExample example);

    int deleteByPrimaryKey(String changeid);

    int insert(CpmsChange record);

    int insertSelective(CpmsChange record);

    List<CpmsChange> selectByExample(CpmsChangeExample example);

    CpmsChange selectByPrimaryKey(String changeid);

    int updateByExampleSelective(@Param("record") CpmsChange record, @Param("example") CpmsChangeExample example);

    int updateByExample(@Param("record") CpmsChange record, @Param("example") CpmsChangeExample example);

    int updateByPrimaryKeySelective(CpmsChange record);

    int updateByPrimaryKey(CpmsChange record);
}