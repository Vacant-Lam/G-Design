package com.cpms.mapper;

import com.cpms.pojo.CpmsProject;
import com.cpms.pojo.CpmsProjectExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface CpmsProjectMapper {
    int countByExample(CpmsProjectExample example);

    int deleteByExample(CpmsProjectExample example);

    int deleteByPrimaryKey(String projectid);

    int insert(CpmsProject record);

    int insertSelective(CpmsProject record);

    List<CpmsProject> selectByExample(CpmsProjectExample example);

    CpmsProject selectByPrimaryKey(String projectid);

    int updateByExampleSelective(@Param("record") CpmsProject record, @Param("example") CpmsProjectExample example);

    int updateByExample(@Param("record") CpmsProject record, @Param("example") CpmsProjectExample example);

    int updateByPrimaryKeySelective(CpmsProject record);

    int updateByPrimaryKey(CpmsProject record);
}