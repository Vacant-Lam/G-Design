package com.cpms.mapper;

import com.cpms.pojo.CpmsMission;
import com.cpms.pojo.CpmsMissionExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface CpmsMissionMapper {
    int countByExample(CpmsMissionExample example);

    int deleteByExample(CpmsMissionExample example);

    int deleteByPrimaryKey(Integer missionid);

    int insert(CpmsMission record);

    int insertSelective(CpmsMission record);

    List<CpmsMission> selectByExample(CpmsMissionExample example);

    CpmsMission selectByPrimaryKey(Integer missionid);

    int updateByExampleSelective(@Param("record") CpmsMission record, @Param("example") CpmsMissionExample example);

    int updateByExample(@Param("record") CpmsMission record, @Param("example") CpmsMissionExample example);

    int updateByPrimaryKeySelective(CpmsMission record);

    int updateByPrimaryKey(CpmsMission record);
}