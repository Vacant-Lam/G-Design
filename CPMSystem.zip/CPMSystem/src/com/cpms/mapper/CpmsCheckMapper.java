package com.cpms.mapper;

import com.cpms.pojo.CpmsCheck;
import com.cpms.pojo.CpmsCheckExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface CpmsCheckMapper {
    int countByExample(CpmsCheckExample example);

    int deleteByExample(CpmsCheckExample example);

    int deleteByPrimaryKey(String checkid);

    int insert(CpmsCheck record);

    int insertSelective(CpmsCheck record);

    List<CpmsCheck> selectByExample(CpmsCheckExample example);

    CpmsCheck selectByPrimaryKey(String checkid);

    int updateByExampleSelective(@Param("record") CpmsCheck record, @Param("example") CpmsCheckExample example);

    int updateByExample(@Param("record") CpmsCheck record, @Param("example") CpmsCheckExample example);

    int updateByPrimaryKeySelective(CpmsCheck record);

    int updateByPrimaryKey(CpmsCheck record);
}