package com.cpms.mapper;

import com.cpms.pojo.CpmsDept;
import com.cpms.pojo.CpmsDeptExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface CpmsDeptMapper {
    int countByExample(CpmsDeptExample example);

    int deleteByExample(CpmsDeptExample example);

    int deleteByPrimaryKey(Integer deptid);

    int insert(CpmsDept record);

    int insertSelective(CpmsDept record);

    List<CpmsDept> selectByExample(CpmsDeptExample example);

    CpmsDept selectByPrimaryKey(Integer deptid);

    int updateByExampleSelective(@Param("record") CpmsDept record, @Param("example") CpmsDeptExample example);

    int updateByExample(@Param("record") CpmsDept record, @Param("example") CpmsDeptExample example);

    int updateByPrimaryKeySelective(CpmsDept record);

    int updateByPrimaryKey(CpmsDept record);
}