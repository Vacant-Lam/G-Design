package com.cpms.mapper;

import com.cpms.pojo.CpmsSchedule;
import com.cpms.pojo.CpmsScheduleExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface CpmsScheduleMapper {
    int countByExample(CpmsScheduleExample example);

    int deleteByExample(CpmsScheduleExample example);

    int deleteByPrimaryKey(String scheduleid);

    int insert(CpmsSchedule record);

    int insertSelective(CpmsSchedule record);

    List<CpmsSchedule> selectByExample(CpmsScheduleExample example);

    CpmsSchedule selectByPrimaryKey(String scheduleid);

    int updateByExampleSelective(@Param("record") CpmsSchedule record, @Param("example") CpmsScheduleExample example);

    int updateByExample(@Param("record") CpmsSchedule record, @Param("example") CpmsScheduleExample example);

    int updateByPrimaryKeySelective(CpmsSchedule record);

    int updateByPrimaryKey(CpmsSchedule record);
}