package com.cpms.mapper;

import com.cpms.pojo.CpmsScheme;
import com.cpms.pojo.CpmsSchemeExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface CpmsSchemeMapper {
    int countByExample(CpmsSchemeExample example);

    int deleteByExample(CpmsSchemeExample example);

    int deleteByPrimaryKey(String schemeid);

    int insert(CpmsScheme record);

    int insertSelective(CpmsScheme record);

    List<CpmsScheme> selectByExample(CpmsSchemeExample example);

    CpmsScheme selectByPrimaryKey(String schemeid);

    int updateByExampleSelective(@Param("record") CpmsScheme record, @Param("example") CpmsSchemeExample example);

    int updateByExample(@Param("record") CpmsScheme record, @Param("example") CpmsSchemeExample example);

    int updateByPrimaryKeySelective(CpmsScheme record);

    int updateByPrimaryKey(CpmsScheme record);
}