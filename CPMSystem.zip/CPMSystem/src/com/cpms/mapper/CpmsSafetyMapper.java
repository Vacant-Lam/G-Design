package com.cpms.mapper;

import com.cpms.pojo.CpmsSafety;
import com.cpms.pojo.CpmsSafetyExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface CpmsSafetyMapper {
    int countByExample(CpmsSafetyExample example);

    int deleteByExample(CpmsSafetyExample example);

    int deleteByPrimaryKey(String safetyid);

    int insert(CpmsSafety record);

    int insertSelective(CpmsSafety record);

    List<CpmsSafety> selectByExample(CpmsSafetyExample example);

    CpmsSafety selectByPrimaryKey(String safetyid);

    int updateByExampleSelective(@Param("record") CpmsSafety record, @Param("example") CpmsSafetyExample example);

    int updateByExample(@Param("record") CpmsSafety record, @Param("example") CpmsSafetyExample example);

    int updateByPrimaryKeySelective(CpmsSafety record);

    int updateByPrimaryKey(CpmsSafety record);
}