package com.cpms.mapper;

import com.cpms.pojo.CpmsCostDetail;
import com.cpms.pojo.CpmsCostDetailExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface CpmsCostDetailMapper {
    int countByExample(CpmsCostDetailExample example);

    int deleteByExample(CpmsCostDetailExample example);

    int deleteByPrimaryKey(Integer costdetailid);

    int insert(CpmsCostDetail record);

    int insertSelective(CpmsCostDetail record);

    List<CpmsCostDetail> selectByExample(CpmsCostDetailExample example);

    CpmsCostDetail selectByPrimaryKey(Integer costdetailid);

    int updateByExampleSelective(@Param("record") CpmsCostDetail record, @Param("example") CpmsCostDetailExample example);

    int updateByExample(@Param("record") CpmsCostDetail record, @Param("example") CpmsCostDetailExample example);

    int updateByPrimaryKeySelective(CpmsCostDetail record);

    int updateByPrimaryKey(CpmsCostDetail record);
}