package com.cpms.mapper;

import com.cpms.pojo.CpmsDiaryDetail;
import com.cpms.pojo.CpmsDiaryDetailExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface CpmsDiaryDetailMapper {
    int countByExample(CpmsDiaryDetailExample example);

    int deleteByExample(CpmsDiaryDetailExample example);

    int deleteByPrimaryKey(Integer diarydetailid);

    int insert(CpmsDiaryDetail record);

    int insertSelective(CpmsDiaryDetail record);

    List<CpmsDiaryDetail> selectByExample(CpmsDiaryDetailExample example);

    CpmsDiaryDetail selectByPrimaryKey(Integer diarydetailid);

    int updateByExampleSelective(@Param("record") CpmsDiaryDetail record, @Param("example") CpmsDiaryDetailExample example);

    int updateByExample(@Param("record") CpmsDiaryDetail record, @Param("example") CpmsDiaryDetailExample example);

    int updateByPrimaryKeySelective(CpmsDiaryDetail record);

    int updateByPrimaryKey(CpmsDiaryDetail record);
}