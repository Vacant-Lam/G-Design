package com.cpms.mapper;

import com.cpms.pojo.CpmsScheduleDetail;
import com.cpms.pojo.CpmsScheduleDetailExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface CpmsScheduleDetailMapper {
    int countByExample(CpmsScheduleDetailExample example);

    int deleteByExample(CpmsScheduleDetailExample example);

    int deleteByPrimaryKey(Integer schddetailid);

    int insert(CpmsScheduleDetail record);

    int insertSelective(CpmsScheduleDetail record);

    List<CpmsScheduleDetail> selectByExample(CpmsScheduleDetailExample example);

    CpmsScheduleDetail selectByPrimaryKey(Integer schddetailid);

    int updateByExampleSelective(@Param("record") CpmsScheduleDetail record, @Param("example") CpmsScheduleDetailExample example);

    int updateByExample(@Param("record") CpmsScheduleDetail record, @Param("example") CpmsScheduleDetailExample example);

    int updateByPrimaryKeySelective(CpmsScheduleDetail record);

    int updateByPrimaryKey(CpmsScheduleDetail record);
}