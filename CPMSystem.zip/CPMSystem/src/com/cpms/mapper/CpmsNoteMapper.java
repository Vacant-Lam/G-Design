package com.cpms.mapper;

import com.cpms.pojo.CpmsNote;
import com.cpms.pojo.CpmsNoteExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface CpmsNoteMapper {
    int countByExample(CpmsNoteExample example);

    int deleteByExample(CpmsNoteExample example);

    int deleteByPrimaryKey(String noteid);

    int insert(CpmsNote record);

    int insertSelective(CpmsNote record);

    List<CpmsNote> selectByExample(CpmsNoteExample example);

    CpmsNote selectByPrimaryKey(String noteid);

    int updateByExampleSelective(@Param("record") CpmsNote record, @Param("example") CpmsNoteExample example);

    int updateByExample(@Param("record") CpmsNote record, @Param("example") CpmsNoteExample example);

    int updateByPrimaryKeySelective(CpmsNote record);

    int updateByPrimaryKey(CpmsNote record);
}