package com.cpms.mapper;

import com.cpms.pojo.CpmsCompany;
import com.cpms.pojo.CpmsCompanyExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface CpmsCompanyMapper {
    int countByExample(CpmsCompanyExample example);

    int deleteByExample(CpmsCompanyExample example);

    int deleteByPrimaryKey(Integer companyid);

    int insert(CpmsCompany record);

    int insertSelective(CpmsCompany record);

    List<CpmsCompany> selectByExample(CpmsCompanyExample example);

    CpmsCompany selectByPrimaryKey(Integer companyid);

    int updateByExampleSelective(@Param("record") CpmsCompany record, @Param("example") CpmsCompanyExample example);

    int updateByExample(@Param("record") CpmsCompany record, @Param("example") CpmsCompanyExample example);

    int updateByPrimaryKeySelective(CpmsCompany record);

    int updateByPrimaryKey(CpmsCompany record);
}