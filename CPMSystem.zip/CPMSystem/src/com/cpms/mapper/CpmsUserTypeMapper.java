package com.cpms.mapper;

import com.cpms.pojo.CpmsUserType;
import com.cpms.pojo.CpmsUserTypeExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface CpmsUserTypeMapper {
    int countByExample(CpmsUserTypeExample example);

    int deleteByExample(CpmsUserTypeExample example);

    int deleteByPrimaryKey(Integer typeid);

    int insert(CpmsUserType record);

    int insertSelective(CpmsUserType record);

    List<CpmsUserType> selectByExample(CpmsUserTypeExample example);

    CpmsUserType selectByPrimaryKey(Integer typeid);

    int updateByExampleSelective(@Param("record") CpmsUserType record, @Param("example") CpmsUserTypeExample example);

    int updateByExample(@Param("record") CpmsUserType record, @Param("example") CpmsUserTypeExample example);

    int updateByPrimaryKeySelective(CpmsUserType record);

    int updateByPrimaryKey(CpmsUserType record);
}