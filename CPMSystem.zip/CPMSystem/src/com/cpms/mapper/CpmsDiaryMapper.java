package com.cpms.mapper;

import com.cpms.pojo.CpmsDiary;
import com.cpms.pojo.CpmsDiaryExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface CpmsDiaryMapper {
    int countByExample(CpmsDiaryExample example);

    int deleteByExample(CpmsDiaryExample example);

    int deleteByPrimaryKey(String diaryid);

    int insert(CpmsDiary record);

    int insertSelective(CpmsDiary record);

    List<CpmsDiary> selectByExample(CpmsDiaryExample example);

    CpmsDiary selectByPrimaryKey(String diaryid);

    int updateByExampleSelective(@Param("record") CpmsDiary record, @Param("example") CpmsDiaryExample example);

    int updateByExample(@Param("record") CpmsDiary record, @Param("example") CpmsDiaryExample example);

    int updateByPrimaryKeySelective(CpmsDiary record);

    int updateByPrimaryKey(CpmsDiary record);
}