package com.cpms.mapper;

import com.cpms.pojo.CpmsRectification;
import com.cpms.pojo.CpmsRectificationExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface CpmsRectificationMapper {
    int countByExample(CpmsRectificationExample example);

    int deleteByExample(CpmsRectificationExample example);

    int deleteByPrimaryKey(String rectificationid);

    int insert(CpmsRectification record);

    int insertSelective(CpmsRectification record);

    List<CpmsRectification> selectByExample(CpmsRectificationExample example);

    CpmsRectification selectByPrimaryKey(String rectificationid);

    int updateByExampleSelective(@Param("record") CpmsRectification record, @Param("example") CpmsRectificationExample example);

    int updateByExample(@Param("record") CpmsRectification record, @Param("example") CpmsRectificationExample example);

    int updateByPrimaryKeySelective(CpmsRectification record);

    int updateByPrimaryKey(CpmsRectification record);
}