package com.cpms.mapper;

import com.cpms.pojo.CpmsUser;
import com.cpms.pojo.CpmsUserExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface CpmsUserMapper {
    int countByExample(CpmsUserExample example);

    int deleteByExample(CpmsUserExample example);

    int deleteByPrimaryKey(String userid);

    int insert(CpmsUser record);

    int insertSelective(CpmsUser record);

    List<CpmsUser> selectByExample(CpmsUserExample example);

    CpmsUser selectByPrimaryKey(String userid);

    int updateByExampleSelective(@Param("record") CpmsUser record, @Param("example") CpmsUserExample example);

    int updateByExample(@Param("record") CpmsUser record, @Param("example") CpmsUserExample example);

    int updateByPrimaryKeySelective(CpmsUser record);

    int updateByPrimaryKey(CpmsUser record);
    
    //��ѯ�����û���Ϣ
    List<CpmsUser> selectUsers();
    
}