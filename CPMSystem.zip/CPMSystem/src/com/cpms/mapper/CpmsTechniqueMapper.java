package com.cpms.mapper;

import com.cpms.pojo.CpmsTechnique;
import com.cpms.pojo.CpmsTechniqueExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface CpmsTechniqueMapper {
    int countByExample(CpmsTechniqueExample example);

    int deleteByExample(CpmsTechniqueExample example);

    int deleteByPrimaryKey(String techniqueid);

    int insert(CpmsTechnique record);

    int insertSelective(CpmsTechnique record);

    List<CpmsTechnique> selectByExample(CpmsTechniqueExample example);

    CpmsTechnique selectByPrimaryKey(String techniqueid);

    int updateByExampleSelective(@Param("record") CpmsTechnique record, @Param("example") CpmsTechniqueExample example);

    int updateByExample(@Param("record") CpmsTechnique record, @Param("example") CpmsTechniqueExample example);

    int updateByPrimaryKeySelective(CpmsTechnique record);

    int updateByPrimaryKey(CpmsTechnique record);
}