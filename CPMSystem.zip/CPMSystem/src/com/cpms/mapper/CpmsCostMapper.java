package com.cpms.mapper;

import com.cpms.pojo.CpmsCost;
import com.cpms.pojo.CpmsCostExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface CpmsCostMapper {
    int countByExample(CpmsCostExample example);

    int deleteByExample(CpmsCostExample example);

    int deleteByPrimaryKey(String costid);

    int insert(CpmsCost record);

    int insertSelective(CpmsCost record);

    List<CpmsCost> selectByExample(CpmsCostExample example);

    CpmsCost selectByPrimaryKey(String costid);

    int updateByExampleSelective(@Param("record") CpmsCost record, @Param("example") CpmsCostExample example);

    int updateByExample(@Param("record") CpmsCost record, @Param("example") CpmsCostExample example);

    int updateByPrimaryKeySelective(CpmsCost record);

    int updateByPrimaryKey(CpmsCost record);
}