package com.cpms.pojo;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class CpmsChangeExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public CpmsChangeExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<java.sql.Date>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andChangeidIsNull() {
            addCriterion("changeId is null");
            return (Criteria) this;
        }

        public Criteria andChangeidIsNotNull() {
            addCriterion("changeId is not null");
            return (Criteria) this;
        }

        public Criteria andChangeidEqualTo(String value) {
            addCriterion("changeId =", value, "changeid");
            return (Criteria) this;
        }

        public Criteria andChangeidNotEqualTo(String value) {
            addCriterion("changeId <>", value, "changeid");
            return (Criteria) this;
        }

        public Criteria andChangeidGreaterThan(String value) {
            addCriterion("changeId >", value, "changeid");
            return (Criteria) this;
        }

        public Criteria andChangeidGreaterThanOrEqualTo(String value) {
            addCriterion("changeId >=", value, "changeid");
            return (Criteria) this;
        }

        public Criteria andChangeidLessThan(String value) {
            addCriterion("changeId <", value, "changeid");
            return (Criteria) this;
        }

        public Criteria andChangeidLessThanOrEqualTo(String value) {
            addCriterion("changeId <=", value, "changeid");
            return (Criteria) this;
        }

        public Criteria andChangeidLike(String value) {
            addCriterion("changeId like", value, "changeid");
            return (Criteria) this;
        }

        public Criteria andChangeidNotLike(String value) {
            addCriterion("changeId not like", value, "changeid");
            return (Criteria) this;
        }

        public Criteria andChangeidIn(List<String> values) {
            addCriterion("changeId in", values, "changeid");
            return (Criteria) this;
        }

        public Criteria andChangeidNotIn(List<String> values) {
            addCriterion("changeId not in", values, "changeid");
            return (Criteria) this;
        }

        public Criteria andChangeidBetween(String value1, String value2) {
            addCriterion("changeId between", value1, value2, "changeid");
            return (Criteria) this;
        }

        public Criteria andChangeidNotBetween(String value1, String value2) {
            addCriterion("changeId not between", value1, value2, "changeid");
            return (Criteria) this;
        }

        public Criteria andProjectidIsNull() {
            addCriterion("projectId is null");
            return (Criteria) this;
        }

        public Criteria andProjectidIsNotNull() {
            addCriterion("projectId is not null");
            return (Criteria) this;
        }

        public Criteria andProjectidEqualTo(String value) {
            addCriterion("projectId =", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidNotEqualTo(String value) {
            addCriterion("projectId <>", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidGreaterThan(String value) {
            addCriterion("projectId >", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidGreaterThanOrEqualTo(String value) {
            addCriterion("projectId >=", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidLessThan(String value) {
            addCriterion("projectId <", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidLessThanOrEqualTo(String value) {
            addCriterion("projectId <=", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidLike(String value) {
            addCriterion("projectId like", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidNotLike(String value) {
            addCriterion("projectId not like", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidIn(List<String> values) {
            addCriterion("projectId in", values, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidNotIn(List<String> values) {
            addCriterion("projectId not in", values, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidBetween(String value1, String value2) {
            addCriterion("projectId between", value1, value2, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidNotBetween(String value1, String value2) {
            addCriterion("projectId not between", value1, value2, "projectid");
            return (Criteria) this;
        }

        public Criteria andChangeeditoridIsNull() {
            addCriterion("changeEditorId is null");
            return (Criteria) this;
        }

        public Criteria andChangeeditoridIsNotNull() {
            addCriterion("changeEditorId is not null");
            return (Criteria) this;
        }

        public Criteria andChangeeditoridEqualTo(String value) {
            addCriterion("changeEditorId =", value, "changeeditorid");
            return (Criteria) this;
        }

        public Criteria andChangeeditoridNotEqualTo(String value) {
            addCriterion("changeEditorId <>", value, "changeeditorid");
            return (Criteria) this;
        }

        public Criteria andChangeeditoridGreaterThan(String value) {
            addCriterion("changeEditorId >", value, "changeeditorid");
            return (Criteria) this;
        }

        public Criteria andChangeeditoridGreaterThanOrEqualTo(String value) {
            addCriterion("changeEditorId >=", value, "changeeditorid");
            return (Criteria) this;
        }

        public Criteria andChangeeditoridLessThan(String value) {
            addCriterion("changeEditorId <", value, "changeeditorid");
            return (Criteria) this;
        }

        public Criteria andChangeeditoridLessThanOrEqualTo(String value) {
            addCriterion("changeEditorId <=", value, "changeeditorid");
            return (Criteria) this;
        }

        public Criteria andChangeeditoridLike(String value) {
            addCriterion("changeEditorId like", value, "changeeditorid");
            return (Criteria) this;
        }

        public Criteria andChangeeditoridNotLike(String value) {
            addCriterion("changeEditorId not like", value, "changeeditorid");
            return (Criteria) this;
        }

        public Criteria andChangeeditoridIn(List<String> values) {
            addCriterion("changeEditorId in", values, "changeeditorid");
            return (Criteria) this;
        }

        public Criteria andChangeeditoridNotIn(List<String> values) {
            addCriterion("changeEditorId not in", values, "changeeditorid");
            return (Criteria) this;
        }

        public Criteria andChangeeditoridBetween(String value1, String value2) {
            addCriterion("changeEditorId between", value1, value2, "changeeditorid");
            return (Criteria) this;
        }

        public Criteria andChangeeditoridNotBetween(String value1, String value2) {
            addCriterion("changeEditorId not between", value1, value2, "changeeditorid");
            return (Criteria) this;
        }

        public Criteria andChangeapproversidIsNull() {
            addCriterion("changeApproversId is null");
            return (Criteria) this;
        }

        public Criteria andChangeapproversidIsNotNull() {
            addCriterion("changeApproversId is not null");
            return (Criteria) this;
        }

        public Criteria andChangeapproversidEqualTo(String value) {
            addCriterion("changeApproversId =", value, "changeapproversid");
            return (Criteria) this;
        }

        public Criteria andChangeapproversidNotEqualTo(String value) {
            addCriterion("changeApproversId <>", value, "changeapproversid");
            return (Criteria) this;
        }

        public Criteria andChangeapproversidGreaterThan(String value) {
            addCriterion("changeApproversId >", value, "changeapproversid");
            return (Criteria) this;
        }

        public Criteria andChangeapproversidGreaterThanOrEqualTo(String value) {
            addCriterion("changeApproversId >=", value, "changeapproversid");
            return (Criteria) this;
        }

        public Criteria andChangeapproversidLessThan(String value) {
            addCriterion("changeApproversId <", value, "changeapproversid");
            return (Criteria) this;
        }

        public Criteria andChangeapproversidLessThanOrEqualTo(String value) {
            addCriterion("changeApproversId <=", value, "changeapproversid");
            return (Criteria) this;
        }

        public Criteria andChangeapproversidLike(String value) {
            addCriterion("changeApproversId like", value, "changeapproversid");
            return (Criteria) this;
        }

        public Criteria andChangeapproversidNotLike(String value) {
            addCriterion("changeApproversId not like", value, "changeapproversid");
            return (Criteria) this;
        }

        public Criteria andChangeapproversidIn(List<String> values) {
            addCriterion("changeApproversId in", values, "changeapproversid");
            return (Criteria) this;
        }

        public Criteria andChangeapproversidNotIn(List<String> values) {
            addCriterion("changeApproversId not in", values, "changeapproversid");
            return (Criteria) this;
        }

        public Criteria andChangeapproversidBetween(String value1, String value2) {
            addCriterion("changeApproversId between", value1, value2, "changeapproversid");
            return (Criteria) this;
        }

        public Criteria andChangeapproversidNotBetween(String value1, String value2) {
            addCriterion("changeApproversId not between", value1, value2, "changeapproversid");
            return (Criteria) this;
        }

        public Criteria andChangenameIsNull() {
            addCriterion("changeName is null");
            return (Criteria) this;
        }

        public Criteria andChangenameIsNotNull() {
            addCriterion("changeName is not null");
            return (Criteria) this;
        }

        public Criteria andChangenameEqualTo(String value) {
            addCriterion("changeName =", value, "changename");
            return (Criteria) this;
        }

        public Criteria andChangenameNotEqualTo(String value) {
            addCriterion("changeName <>", value, "changename");
            return (Criteria) this;
        }

        public Criteria andChangenameGreaterThan(String value) {
            addCriterion("changeName >", value, "changename");
            return (Criteria) this;
        }

        public Criteria andChangenameGreaterThanOrEqualTo(String value) {
            addCriterion("changeName >=", value, "changename");
            return (Criteria) this;
        }

        public Criteria andChangenameLessThan(String value) {
            addCriterion("changeName <", value, "changename");
            return (Criteria) this;
        }

        public Criteria andChangenameLessThanOrEqualTo(String value) {
            addCriterion("changeName <=", value, "changename");
            return (Criteria) this;
        }

        public Criteria andChangenameLike(String value) {
            addCriterion("changeName like", value, "changename");
            return (Criteria) this;
        }

        public Criteria andChangenameNotLike(String value) {
            addCriterion("changeName not like", value, "changename");
            return (Criteria) this;
        }

        public Criteria andChangenameIn(List<String> values) {
            addCriterion("changeName in", values, "changename");
            return (Criteria) this;
        }

        public Criteria andChangenameNotIn(List<String> values) {
            addCriterion("changeName not in", values, "changename");
            return (Criteria) this;
        }

        public Criteria andChangenameBetween(String value1, String value2) {
            addCriterion("changeName between", value1, value2, "changename");
            return (Criteria) this;
        }

        public Criteria andChangenameNotBetween(String value1, String value2) {
            addCriterion("changeName not between", value1, value2, "changename");
            return (Criteria) this;
        }

        public Criteria andChangedateIsNull() {
            addCriterion("changeDate is null");
            return (Criteria) this;
        }

        public Criteria andChangedateIsNotNull() {
            addCriterion("changeDate is not null");
            return (Criteria) this;
        }

        public Criteria andChangedateEqualTo(Date value) {
            addCriterionForJDBCDate("changeDate =", value, "changedate");
            return (Criteria) this;
        }

        public Criteria andChangedateNotEqualTo(Date value) {
            addCriterionForJDBCDate("changeDate <>", value, "changedate");
            return (Criteria) this;
        }

        public Criteria andChangedateGreaterThan(Date value) {
            addCriterionForJDBCDate("changeDate >", value, "changedate");
            return (Criteria) this;
        }

        public Criteria andChangedateGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("changeDate >=", value, "changedate");
            return (Criteria) this;
        }

        public Criteria andChangedateLessThan(Date value) {
            addCriterionForJDBCDate("changeDate <", value, "changedate");
            return (Criteria) this;
        }

        public Criteria andChangedateLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("changeDate <=", value, "changedate");
            return (Criteria) this;
        }

        public Criteria andChangedateIn(List<Date> values) {
            addCriterionForJDBCDate("changeDate in", values, "changedate");
            return (Criteria) this;
        }

        public Criteria andChangedateNotIn(List<Date> values) {
            addCriterionForJDBCDate("changeDate not in", values, "changedate");
            return (Criteria) this;
        }

        public Criteria andChangedateBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("changeDate between", value1, value2, "changedate");
            return (Criteria) this;
        }

        public Criteria andChangedateNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("changeDate not between", value1, value2, "changedate");
            return (Criteria) this;
        }

        public Criteria andChangeamountIsNull() {
            addCriterion("changeAmount is null");
            return (Criteria) this;
        }

        public Criteria andChangeamountIsNotNull() {
            addCriterion("changeAmount is not null");
            return (Criteria) this;
        }

        public Criteria andChangeamountEqualTo(Double value) {
            addCriterion("changeAmount =", value, "changeamount");
            return (Criteria) this;
        }

        public Criteria andChangeamountNotEqualTo(Double value) {
            addCriterion("changeAmount <>", value, "changeamount");
            return (Criteria) this;
        }

        public Criteria andChangeamountGreaterThan(Double value) {
            addCriterion("changeAmount >", value, "changeamount");
            return (Criteria) this;
        }

        public Criteria andChangeamountGreaterThanOrEqualTo(Double value) {
            addCriterion("changeAmount >=", value, "changeamount");
            return (Criteria) this;
        }

        public Criteria andChangeamountLessThan(Double value) {
            addCriterion("changeAmount <", value, "changeamount");
            return (Criteria) this;
        }

        public Criteria andChangeamountLessThanOrEqualTo(Double value) {
            addCriterion("changeAmount <=", value, "changeamount");
            return (Criteria) this;
        }

        public Criteria andChangeamountIn(List<Double> values) {
            addCriterion("changeAmount in", values, "changeamount");
            return (Criteria) this;
        }

        public Criteria andChangeamountNotIn(List<Double> values) {
            addCriterion("changeAmount not in", values, "changeamount");
            return (Criteria) this;
        }

        public Criteria andChangeamountBetween(Double value1, Double value2) {
            addCriterion("changeAmount between", value1, value2, "changeamount");
            return (Criteria) this;
        }

        public Criteria andChangeamountNotBetween(Double value1, Double value2) {
            addCriterion("changeAmount not between", value1, value2, "changeamount");
            return (Criteria) this;
        }

        public Criteria andChangeunitIsNull() {
            addCriterion("changeUnit is null");
            return (Criteria) this;
        }

        public Criteria andChangeunitIsNotNull() {
            addCriterion("changeUnit is not null");
            return (Criteria) this;
        }

        public Criteria andChangeunitEqualTo(String value) {
            addCriterion("changeUnit =", value, "changeunit");
            return (Criteria) this;
        }

        public Criteria andChangeunitNotEqualTo(String value) {
            addCriterion("changeUnit <>", value, "changeunit");
            return (Criteria) this;
        }

        public Criteria andChangeunitGreaterThan(String value) {
            addCriterion("changeUnit >", value, "changeunit");
            return (Criteria) this;
        }

        public Criteria andChangeunitGreaterThanOrEqualTo(String value) {
            addCriterion("changeUnit >=", value, "changeunit");
            return (Criteria) this;
        }

        public Criteria andChangeunitLessThan(String value) {
            addCriterion("changeUnit <", value, "changeunit");
            return (Criteria) this;
        }

        public Criteria andChangeunitLessThanOrEqualTo(String value) {
            addCriterion("changeUnit <=", value, "changeunit");
            return (Criteria) this;
        }

        public Criteria andChangeunitLike(String value) {
            addCriterion("changeUnit like", value, "changeunit");
            return (Criteria) this;
        }

        public Criteria andChangeunitNotLike(String value) {
            addCriterion("changeUnit not like", value, "changeunit");
            return (Criteria) this;
        }

        public Criteria andChangeunitIn(List<String> values) {
            addCriterion("changeUnit in", values, "changeunit");
            return (Criteria) this;
        }

        public Criteria andChangeunitNotIn(List<String> values) {
            addCriterion("changeUnit not in", values, "changeunit");
            return (Criteria) this;
        }

        public Criteria andChangeunitBetween(String value1, String value2) {
            addCriterion("changeUnit between", value1, value2, "changeunit");
            return (Criteria) this;
        }

        public Criteria andChangeunitNotBetween(String value1, String value2) {
            addCriterion("changeUnit not between", value1, value2, "changeunit");
            return (Criteria) this;
        }

        public Criteria andChangeolddesignIsNull() {
            addCriterion("changeOldDesign is null");
            return (Criteria) this;
        }

        public Criteria andChangeolddesignIsNotNull() {
            addCriterion("changeOldDesign is not null");
            return (Criteria) this;
        }

        public Criteria andChangeolddesignEqualTo(String value) {
            addCriterion("changeOldDesign =", value, "changeolddesign");
            return (Criteria) this;
        }

        public Criteria andChangeolddesignNotEqualTo(String value) {
            addCriterion("changeOldDesign <>", value, "changeolddesign");
            return (Criteria) this;
        }

        public Criteria andChangeolddesignGreaterThan(String value) {
            addCriterion("changeOldDesign >", value, "changeolddesign");
            return (Criteria) this;
        }

        public Criteria andChangeolddesignGreaterThanOrEqualTo(String value) {
            addCriterion("changeOldDesign >=", value, "changeolddesign");
            return (Criteria) this;
        }

        public Criteria andChangeolddesignLessThan(String value) {
            addCriterion("changeOldDesign <", value, "changeolddesign");
            return (Criteria) this;
        }

        public Criteria andChangeolddesignLessThanOrEqualTo(String value) {
            addCriterion("changeOldDesign <=", value, "changeolddesign");
            return (Criteria) this;
        }

        public Criteria andChangeolddesignLike(String value) {
            addCriterion("changeOldDesign like", value, "changeolddesign");
            return (Criteria) this;
        }

        public Criteria andChangeolddesignNotLike(String value) {
            addCriterion("changeOldDesign not like", value, "changeolddesign");
            return (Criteria) this;
        }

        public Criteria andChangeolddesignIn(List<String> values) {
            addCriterion("changeOldDesign in", values, "changeolddesign");
            return (Criteria) this;
        }

        public Criteria andChangeolddesignNotIn(List<String> values) {
            addCriterion("changeOldDesign not in", values, "changeolddesign");
            return (Criteria) this;
        }

        public Criteria andChangeolddesignBetween(String value1, String value2) {
            addCriterion("changeOldDesign between", value1, value2, "changeolddesign");
            return (Criteria) this;
        }

        public Criteria andChangeolddesignNotBetween(String value1, String value2) {
            addCriterion("changeOldDesign not between", value1, value2, "changeolddesign");
            return (Criteria) this;
        }

        public Criteria andChangeoldtypeIsNull() {
            addCriterion("changeOldType is null");
            return (Criteria) this;
        }

        public Criteria andChangeoldtypeIsNotNull() {
            addCriterion("changeOldType is not null");
            return (Criteria) this;
        }

        public Criteria andChangeoldtypeEqualTo(String value) {
            addCriterion("changeOldType =", value, "changeoldtype");
            return (Criteria) this;
        }

        public Criteria andChangeoldtypeNotEqualTo(String value) {
            addCriterion("changeOldType <>", value, "changeoldtype");
            return (Criteria) this;
        }

        public Criteria andChangeoldtypeGreaterThan(String value) {
            addCriterion("changeOldType >", value, "changeoldtype");
            return (Criteria) this;
        }

        public Criteria andChangeoldtypeGreaterThanOrEqualTo(String value) {
            addCriterion("changeOldType >=", value, "changeoldtype");
            return (Criteria) this;
        }

        public Criteria andChangeoldtypeLessThan(String value) {
            addCriterion("changeOldType <", value, "changeoldtype");
            return (Criteria) this;
        }

        public Criteria andChangeoldtypeLessThanOrEqualTo(String value) {
            addCriterion("changeOldType <=", value, "changeoldtype");
            return (Criteria) this;
        }

        public Criteria andChangeoldtypeLike(String value) {
            addCriterion("changeOldType like", value, "changeoldtype");
            return (Criteria) this;
        }

        public Criteria andChangeoldtypeNotLike(String value) {
            addCriterion("changeOldType not like", value, "changeoldtype");
            return (Criteria) this;
        }

        public Criteria andChangeoldtypeIn(List<String> values) {
            addCriterion("changeOldType in", values, "changeoldtype");
            return (Criteria) this;
        }

        public Criteria andChangeoldtypeNotIn(List<String> values) {
            addCriterion("changeOldType not in", values, "changeoldtype");
            return (Criteria) this;
        }

        public Criteria andChangeoldtypeBetween(String value1, String value2) {
            addCriterion("changeOldType between", value1, value2, "changeoldtype");
            return (Criteria) this;
        }

        public Criteria andChangeoldtypeNotBetween(String value1, String value2) {
            addCriterion("changeOldType not between", value1, value2, "changeoldtype");
            return (Criteria) this;
        }

        public Criteria andChangenewdesignIsNull() {
            addCriterion("changeNewDesign is null");
            return (Criteria) this;
        }

        public Criteria andChangenewdesignIsNotNull() {
            addCriterion("changeNewDesign is not null");
            return (Criteria) this;
        }

        public Criteria andChangenewdesignEqualTo(String value) {
            addCriterion("changeNewDesign =", value, "changenewdesign");
            return (Criteria) this;
        }

        public Criteria andChangenewdesignNotEqualTo(String value) {
            addCriterion("changeNewDesign <>", value, "changenewdesign");
            return (Criteria) this;
        }

        public Criteria andChangenewdesignGreaterThan(String value) {
            addCriterion("changeNewDesign >", value, "changenewdesign");
            return (Criteria) this;
        }

        public Criteria andChangenewdesignGreaterThanOrEqualTo(String value) {
            addCriterion("changeNewDesign >=", value, "changenewdesign");
            return (Criteria) this;
        }

        public Criteria andChangenewdesignLessThan(String value) {
            addCriterion("changeNewDesign <", value, "changenewdesign");
            return (Criteria) this;
        }

        public Criteria andChangenewdesignLessThanOrEqualTo(String value) {
            addCriterion("changeNewDesign <=", value, "changenewdesign");
            return (Criteria) this;
        }

        public Criteria andChangenewdesignLike(String value) {
            addCriterion("changeNewDesign like", value, "changenewdesign");
            return (Criteria) this;
        }

        public Criteria andChangenewdesignNotLike(String value) {
            addCriterion("changeNewDesign not like", value, "changenewdesign");
            return (Criteria) this;
        }

        public Criteria andChangenewdesignIn(List<String> values) {
            addCriterion("changeNewDesign in", values, "changenewdesign");
            return (Criteria) this;
        }

        public Criteria andChangenewdesignNotIn(List<String> values) {
            addCriterion("changeNewDesign not in", values, "changenewdesign");
            return (Criteria) this;
        }

        public Criteria andChangenewdesignBetween(String value1, String value2) {
            addCriterion("changeNewDesign between", value1, value2, "changenewdesign");
            return (Criteria) this;
        }

        public Criteria andChangenewdesignNotBetween(String value1, String value2) {
            addCriterion("changeNewDesign not between", value1, value2, "changenewdesign");
            return (Criteria) this;
        }

        public Criteria andChangenewtypeIsNull() {
            addCriterion("changeNewType is null");
            return (Criteria) this;
        }

        public Criteria andChangenewtypeIsNotNull() {
            addCriterion("changeNewType is not null");
            return (Criteria) this;
        }

        public Criteria andChangenewtypeEqualTo(String value) {
            addCriterion("changeNewType =", value, "changenewtype");
            return (Criteria) this;
        }

        public Criteria andChangenewtypeNotEqualTo(String value) {
            addCriterion("changeNewType <>", value, "changenewtype");
            return (Criteria) this;
        }

        public Criteria andChangenewtypeGreaterThan(String value) {
            addCriterion("changeNewType >", value, "changenewtype");
            return (Criteria) this;
        }

        public Criteria andChangenewtypeGreaterThanOrEqualTo(String value) {
            addCriterion("changeNewType >=", value, "changenewtype");
            return (Criteria) this;
        }

        public Criteria andChangenewtypeLessThan(String value) {
            addCriterion("changeNewType <", value, "changenewtype");
            return (Criteria) this;
        }

        public Criteria andChangenewtypeLessThanOrEqualTo(String value) {
            addCriterion("changeNewType <=", value, "changenewtype");
            return (Criteria) this;
        }

        public Criteria andChangenewtypeLike(String value) {
            addCriterion("changeNewType like", value, "changenewtype");
            return (Criteria) this;
        }

        public Criteria andChangenewtypeNotLike(String value) {
            addCriterion("changeNewType not like", value, "changenewtype");
            return (Criteria) this;
        }

        public Criteria andChangenewtypeIn(List<String> values) {
            addCriterion("changeNewType in", values, "changenewtype");
            return (Criteria) this;
        }

        public Criteria andChangenewtypeNotIn(List<String> values) {
            addCriterion("changeNewType not in", values, "changenewtype");
            return (Criteria) this;
        }

        public Criteria andChangenewtypeBetween(String value1, String value2) {
            addCriterion("changeNewType between", value1, value2, "changenewtype");
            return (Criteria) this;
        }

        public Criteria andChangenewtypeNotBetween(String value1, String value2) {
            addCriterion("changeNewType not between", value1, value2, "changenewtype");
            return (Criteria) this;
        }

        public Criteria andChangereasonIsNull() {
            addCriterion("changeReason is null");
            return (Criteria) this;
        }

        public Criteria andChangereasonIsNotNull() {
            addCriterion("changeReason is not null");
            return (Criteria) this;
        }

        public Criteria andChangereasonEqualTo(String value) {
            addCriterion("changeReason =", value, "changereason");
            return (Criteria) this;
        }

        public Criteria andChangereasonNotEqualTo(String value) {
            addCriterion("changeReason <>", value, "changereason");
            return (Criteria) this;
        }

        public Criteria andChangereasonGreaterThan(String value) {
            addCriterion("changeReason >", value, "changereason");
            return (Criteria) this;
        }

        public Criteria andChangereasonGreaterThanOrEqualTo(String value) {
            addCriterion("changeReason >=", value, "changereason");
            return (Criteria) this;
        }

        public Criteria andChangereasonLessThan(String value) {
            addCriterion("changeReason <", value, "changereason");
            return (Criteria) this;
        }

        public Criteria andChangereasonLessThanOrEqualTo(String value) {
            addCriterion("changeReason <=", value, "changereason");
            return (Criteria) this;
        }

        public Criteria andChangereasonLike(String value) {
            addCriterion("changeReason like", value, "changereason");
            return (Criteria) this;
        }

        public Criteria andChangereasonNotLike(String value) {
            addCriterion("changeReason not like", value, "changereason");
            return (Criteria) this;
        }

        public Criteria andChangereasonIn(List<String> values) {
            addCriterion("changeReason in", values, "changereason");
            return (Criteria) this;
        }

        public Criteria andChangereasonNotIn(List<String> values) {
            addCriterion("changeReason not in", values, "changereason");
            return (Criteria) this;
        }

        public Criteria andChangereasonBetween(String value1, String value2) {
            addCriterion("changeReason between", value1, value2, "changereason");
            return (Criteria) this;
        }

        public Criteria andChangereasonNotBetween(String value1, String value2) {
            addCriterion("changeReason not between", value1, value2, "changereason");
            return (Criteria) this;
        }

        public Criteria andChangecontentIsNull() {
            addCriterion("changeContent is null");
            return (Criteria) this;
        }

        public Criteria andChangecontentIsNotNull() {
            addCriterion("changeContent is not null");
            return (Criteria) this;
        }

        public Criteria andChangecontentEqualTo(String value) {
            addCriterion("changeContent =", value, "changecontent");
            return (Criteria) this;
        }

        public Criteria andChangecontentNotEqualTo(String value) {
            addCriterion("changeContent <>", value, "changecontent");
            return (Criteria) this;
        }

        public Criteria andChangecontentGreaterThan(String value) {
            addCriterion("changeContent >", value, "changecontent");
            return (Criteria) this;
        }

        public Criteria andChangecontentGreaterThanOrEqualTo(String value) {
            addCriterion("changeContent >=", value, "changecontent");
            return (Criteria) this;
        }

        public Criteria andChangecontentLessThan(String value) {
            addCriterion("changeContent <", value, "changecontent");
            return (Criteria) this;
        }

        public Criteria andChangecontentLessThanOrEqualTo(String value) {
            addCriterion("changeContent <=", value, "changecontent");
            return (Criteria) this;
        }

        public Criteria andChangecontentLike(String value) {
            addCriterion("changeContent like", value, "changecontent");
            return (Criteria) this;
        }

        public Criteria andChangecontentNotLike(String value) {
            addCriterion("changeContent not like", value, "changecontent");
            return (Criteria) this;
        }

        public Criteria andChangecontentIn(List<String> values) {
            addCriterion("changeContent in", values, "changecontent");
            return (Criteria) this;
        }

        public Criteria andChangecontentNotIn(List<String> values) {
            addCriterion("changeContent not in", values, "changecontent");
            return (Criteria) this;
        }

        public Criteria andChangecontentBetween(String value1, String value2) {
            addCriterion("changeContent between", value1, value2, "changecontent");
            return (Criteria) this;
        }

        public Criteria andChangecontentNotBetween(String value1, String value2) {
            addCriterion("changeContent not between", value1, value2, "changecontent");
            return (Criteria) this;
        }

        public Criteria andChangeremarkIsNull() {
            addCriterion("changeRemark is null");
            return (Criteria) this;
        }

        public Criteria andChangeremarkIsNotNull() {
            addCriterion("changeRemark is not null");
            return (Criteria) this;
        }

        public Criteria andChangeremarkEqualTo(String value) {
            addCriterion("changeRemark =", value, "changeremark");
            return (Criteria) this;
        }

        public Criteria andChangeremarkNotEqualTo(String value) {
            addCriterion("changeRemark <>", value, "changeremark");
            return (Criteria) this;
        }

        public Criteria andChangeremarkGreaterThan(String value) {
            addCriterion("changeRemark >", value, "changeremark");
            return (Criteria) this;
        }

        public Criteria andChangeremarkGreaterThanOrEqualTo(String value) {
            addCriterion("changeRemark >=", value, "changeremark");
            return (Criteria) this;
        }

        public Criteria andChangeremarkLessThan(String value) {
            addCriterion("changeRemark <", value, "changeremark");
            return (Criteria) this;
        }

        public Criteria andChangeremarkLessThanOrEqualTo(String value) {
            addCriterion("changeRemark <=", value, "changeremark");
            return (Criteria) this;
        }

        public Criteria andChangeremarkLike(String value) {
            addCriterion("changeRemark like", value, "changeremark");
            return (Criteria) this;
        }

        public Criteria andChangeremarkNotLike(String value) {
            addCriterion("changeRemark not like", value, "changeremark");
            return (Criteria) this;
        }

        public Criteria andChangeremarkIn(List<String> values) {
            addCriterion("changeRemark in", values, "changeremark");
            return (Criteria) this;
        }

        public Criteria andChangeremarkNotIn(List<String> values) {
            addCriterion("changeRemark not in", values, "changeremark");
            return (Criteria) this;
        }

        public Criteria andChangeremarkBetween(String value1, String value2) {
            addCriterion("changeRemark between", value1, value2, "changeremark");
            return (Criteria) this;
        }

        public Criteria andChangeremarkNotBetween(String value1, String value2) {
            addCriterion("changeRemark not between", value1, value2, "changeremark");
            return (Criteria) this;
        }

        public Criteria andChangestatusIsNull() {
            addCriterion("changeStatus is null");
            return (Criteria) this;
        }

        public Criteria andChangestatusIsNotNull() {
            addCriterion("changeStatus is not null");
            return (Criteria) this;
        }

        public Criteria andChangestatusEqualTo(Integer value) {
            addCriterion("changeStatus =", value, "changestatus");
            return (Criteria) this;
        }

        public Criteria andChangestatusNotEqualTo(Integer value) {
            addCriterion("changeStatus <>", value, "changestatus");
            return (Criteria) this;
        }

        public Criteria andChangestatusGreaterThan(Integer value) {
            addCriterion("changeStatus >", value, "changestatus");
            return (Criteria) this;
        }

        public Criteria andChangestatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("changeStatus >=", value, "changestatus");
            return (Criteria) this;
        }

        public Criteria andChangestatusLessThan(Integer value) {
            addCriterion("changeStatus <", value, "changestatus");
            return (Criteria) this;
        }

        public Criteria andChangestatusLessThanOrEqualTo(Integer value) {
            addCriterion("changeStatus <=", value, "changestatus");
            return (Criteria) this;
        }

        public Criteria andChangestatusIn(List<Integer> values) {
            addCriterion("changeStatus in", values, "changestatus");
            return (Criteria) this;
        }

        public Criteria andChangestatusNotIn(List<Integer> values) {
            addCriterion("changeStatus not in", values, "changestatus");
            return (Criteria) this;
        }

        public Criteria andChangestatusBetween(Integer value1, Integer value2) {
            addCriterion("changeStatus between", value1, value2, "changestatus");
            return (Criteria) this;
        }

        public Criteria andChangestatusNotBetween(Integer value1, Integer value2) {
            addCriterion("changeStatus not between", value1, value2, "changestatus");
            return (Criteria) this;
        }

        public Criteria andApprovedateIsNull() {
            addCriterion("approveDate is null");
            return (Criteria) this;
        }

        public Criteria andApprovedateIsNotNull() {
            addCriterion("approveDate is not null");
            return (Criteria) this;
        }

        public Criteria andApprovedateEqualTo(Date value) {
            addCriterion("approveDate =", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateNotEqualTo(Date value) {
            addCriterion("approveDate <>", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateGreaterThan(Date value) {
            addCriterion("approveDate >", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateGreaterThanOrEqualTo(Date value) {
            addCriterion("approveDate >=", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateLessThan(Date value) {
            addCriterion("approveDate <", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateLessThanOrEqualTo(Date value) {
            addCriterion("approveDate <=", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateIn(List<Date> values) {
            addCriterion("approveDate in", values, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateNotIn(List<Date> values) {
            addCriterion("approveDate not in", values, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateBetween(Date value1, Date value2) {
            addCriterion("approveDate between", value1, value2, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateNotBetween(Date value1, Date value2) {
            addCriterion("approveDate not between", value1, value2, "approvedate");
            return (Criteria) this;
        }

        public Criteria andChangecommentIsNull() {
            addCriterion("changeComment is null");
            return (Criteria) this;
        }

        public Criteria andChangecommentIsNotNull() {
            addCriterion("changeComment is not null");
            return (Criteria) this;
        }

        public Criteria andChangecommentEqualTo(String value) {
            addCriterion("changeComment =", value, "changecomment");
            return (Criteria) this;
        }

        public Criteria andChangecommentNotEqualTo(String value) {
            addCriterion("changeComment <>", value, "changecomment");
            return (Criteria) this;
        }

        public Criteria andChangecommentGreaterThan(String value) {
            addCriterion("changeComment >", value, "changecomment");
            return (Criteria) this;
        }

        public Criteria andChangecommentGreaterThanOrEqualTo(String value) {
            addCriterion("changeComment >=", value, "changecomment");
            return (Criteria) this;
        }

        public Criteria andChangecommentLessThan(String value) {
            addCriterion("changeComment <", value, "changecomment");
            return (Criteria) this;
        }

        public Criteria andChangecommentLessThanOrEqualTo(String value) {
            addCriterion("changeComment <=", value, "changecomment");
            return (Criteria) this;
        }

        public Criteria andChangecommentLike(String value) {
            addCriterion("changeComment like", value, "changecomment");
            return (Criteria) this;
        }

        public Criteria andChangecommentNotLike(String value) {
            addCriterion("changeComment not like", value, "changecomment");
            return (Criteria) this;
        }

        public Criteria andChangecommentIn(List<String> values) {
            addCriterion("changeComment in", values, "changecomment");
            return (Criteria) this;
        }

        public Criteria andChangecommentNotIn(List<String> values) {
            addCriterion("changeComment not in", values, "changecomment");
            return (Criteria) this;
        }

        public Criteria andChangecommentBetween(String value1, String value2) {
            addCriterion("changeComment between", value1, value2, "changecomment");
            return (Criteria) this;
        }

        public Criteria andChangecommentNotBetween(String value1, String value2) {
            addCriterion("changeComment not between", value1, value2, "changecomment");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}