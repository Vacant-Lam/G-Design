package com.cpms.pojo;

public class CpmsScheduleDetail {
    private Integer schddetailid;

    private String projectid;

    private String schddetailitem;

    private String schddetailunit;

    private Integer schddetailquantities;

    private Double schddetailprice;

    private Integer schddetaildone;

    public Integer getSchddetailid() {
        return schddetailid;
    }

    public void setSchddetailid(Integer schddetailid) {
        this.schddetailid = schddetailid;
    }

    public String getProjectid() {
        return projectid;
    }

    public void setProjectid(String projectid) {
        this.projectid = projectid == null ? null : projectid.trim();
    }

    public String getSchddetailitem() {
        return schddetailitem;
    }

    public void setSchddetailitem(String schddetailitem) {
        this.schddetailitem = schddetailitem == null ? null : schddetailitem.trim();
    }

    public String getSchddetailunit() {
        return schddetailunit;
    }

    public void setSchddetailunit(String schddetailunit) {
        this.schddetailunit = schddetailunit == null ? null : schddetailunit.trim();
    }

    public Integer getSchddetailquantities() {
        return schddetailquantities;
    }

    public void setSchddetailquantities(Integer schddetailquantities) {
        this.schddetailquantities = schddetailquantities;
    }

    public Double getSchddetailprice() {
        return schddetailprice;
    }

    public void setSchddetailprice(Double schddetailprice) {
        this.schddetailprice = schddetailprice;
    }

    public Integer getSchddetaildone() {
        return schddetaildone;
    }

    public void setSchddetaildone(Integer schddetaildone) {
        this.schddetaildone = schddetaildone;
    }
}