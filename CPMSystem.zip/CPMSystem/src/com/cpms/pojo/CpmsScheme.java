package com.cpms.pojo;

import java.util.Date;

public class CpmsScheme {
    private String schemeid;

    private String projectid;

    private String schemeeditorid;

    private String schemeapproversid;

    private String schemename;

    private Date schemedate;

    private String schemeattachment;

    private String attachmenttype;

    private String schemecontent;

    private String schemeremark;

    private Integer schemestatus;

    private Date approvedate;

    private String schemecomment;

    public String getSchemeid() {
        return schemeid;
    }

    public void setSchemeid(String schemeid) {
        this.schemeid = schemeid == null ? null : schemeid.trim();
    }

    public String getProjectid() {
        return projectid;
    }

    public void setProjectid(String projectid) {
        this.projectid = projectid == null ? null : projectid.trim();
    }

    public String getSchemeeditorid() {
        return schemeeditorid;
    }

    public void setSchemeeditorid(String schemeeditorid) {
        this.schemeeditorid = schemeeditorid == null ? null : schemeeditorid.trim();
    }

    public String getSchemeapproversid() {
        return schemeapproversid;
    }

    public void setSchemeapproversid(String schemeapproversid) {
        this.schemeapproversid = schemeapproversid == null ? null : schemeapproversid.trim();
    }

    public String getSchemename() {
        return schemename;
    }

    public void setSchemename(String schemename) {
        this.schemename = schemename == null ? null : schemename.trim();
    }

    public Date getSchemedate() {
        return schemedate;
    }

    public void setSchemedate(Date schemedate) {
        this.schemedate = schemedate;
    }

    public String getSchemeattachment() {
        return schemeattachment;
    }

    public void setSchemeattachment(String schemeattachment) {
        this.schemeattachment = schemeattachment == null ? null : schemeattachment.trim();
    }

    public String getAttachmenttype() {
        return attachmenttype;
    }

    public void setAttachmenttype(String attachmenttype) {
        this.attachmenttype = attachmenttype == null ? null : attachmenttype.trim();
    }

    public String getSchemecontent() {
        return schemecontent;
    }

    public void setSchemecontent(String schemecontent) {
        this.schemecontent = schemecontent == null ? null : schemecontent.trim();
    }

    public String getSchemeremark() {
        return schemeremark;
    }

    public void setSchemeremark(String schemeremark) {
        this.schemeremark = schemeremark == null ? null : schemeremark.trim();
    }

    public Integer getSchemestatus() {
        return schemestatus;
    }

    public void setSchemestatus(Integer schemestatus) {
        this.schemestatus = schemestatus;
    }

    public Date getApprovedate() {
        return approvedate;
    }

    public void setApprovedate(Date approvedate) {
        this.approvedate = approvedate;
    }

    public String getSchemecomment() {
        return schemecomment;
    }

    public void setSchemecomment(String schemecomment) {
        this.schemecomment = schemecomment == null ? null : schemecomment.trim();
    }
}