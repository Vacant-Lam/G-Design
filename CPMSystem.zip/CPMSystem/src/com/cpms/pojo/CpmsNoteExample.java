package com.cpms.pojo;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class CpmsNoteExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public CpmsNoteExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<java.sql.Date>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andNoteidIsNull() {
            addCriterion("noteId is null");
            return (Criteria) this;
        }

        public Criteria andNoteidIsNotNull() {
            addCriterion("noteId is not null");
            return (Criteria) this;
        }

        public Criteria andNoteidEqualTo(String value) {
            addCriterion("noteId =", value, "noteid");
            return (Criteria) this;
        }

        public Criteria andNoteidNotEqualTo(String value) {
            addCriterion("noteId <>", value, "noteid");
            return (Criteria) this;
        }

        public Criteria andNoteidGreaterThan(String value) {
            addCriterion("noteId >", value, "noteid");
            return (Criteria) this;
        }

        public Criteria andNoteidGreaterThanOrEqualTo(String value) {
            addCriterion("noteId >=", value, "noteid");
            return (Criteria) this;
        }

        public Criteria andNoteidLessThan(String value) {
            addCriterion("noteId <", value, "noteid");
            return (Criteria) this;
        }

        public Criteria andNoteidLessThanOrEqualTo(String value) {
            addCriterion("noteId <=", value, "noteid");
            return (Criteria) this;
        }

        public Criteria andNoteidLike(String value) {
            addCriterion("noteId like", value, "noteid");
            return (Criteria) this;
        }

        public Criteria andNoteidNotLike(String value) {
            addCriterion("noteId not like", value, "noteid");
            return (Criteria) this;
        }

        public Criteria andNoteidIn(List<String> values) {
            addCriterion("noteId in", values, "noteid");
            return (Criteria) this;
        }

        public Criteria andNoteidNotIn(List<String> values) {
            addCriterion("noteId not in", values, "noteid");
            return (Criteria) this;
        }

        public Criteria andNoteidBetween(String value1, String value2) {
            addCriterion("noteId between", value1, value2, "noteid");
            return (Criteria) this;
        }

        public Criteria andNoteidNotBetween(String value1, String value2) {
            addCriterion("noteId not between", value1, value2, "noteid");
            return (Criteria) this;
        }

        public Criteria andProjectidIsNull() {
            addCriterion("projectId is null");
            return (Criteria) this;
        }

        public Criteria andProjectidIsNotNull() {
            addCriterion("projectId is not null");
            return (Criteria) this;
        }

        public Criteria andProjectidEqualTo(String value) {
            addCriterion("projectId =", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidNotEqualTo(String value) {
            addCriterion("projectId <>", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidGreaterThan(String value) {
            addCriterion("projectId >", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidGreaterThanOrEqualTo(String value) {
            addCriterion("projectId >=", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidLessThan(String value) {
            addCriterion("projectId <", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidLessThanOrEqualTo(String value) {
            addCriterion("projectId <=", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidLike(String value) {
            addCriterion("projectId like", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidNotLike(String value) {
            addCriterion("projectId not like", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidIn(List<String> values) {
            addCriterion("projectId in", values, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidNotIn(List<String> values) {
            addCriterion("projectId not in", values, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidBetween(String value1, String value2) {
            addCriterion("projectId between", value1, value2, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidNotBetween(String value1, String value2) {
            addCriterion("projectId not between", value1, value2, "projectid");
            return (Criteria) this;
        }

        public Criteria andNoteeditoridIsNull() {
            addCriterion("noteEditorId is null");
            return (Criteria) this;
        }

        public Criteria andNoteeditoridIsNotNull() {
            addCriterion("noteEditorId is not null");
            return (Criteria) this;
        }

        public Criteria andNoteeditoridEqualTo(String value) {
            addCriterion("noteEditorId =", value, "noteeditorid");
            return (Criteria) this;
        }

        public Criteria andNoteeditoridNotEqualTo(String value) {
            addCriterion("noteEditorId <>", value, "noteeditorid");
            return (Criteria) this;
        }

        public Criteria andNoteeditoridGreaterThan(String value) {
            addCriterion("noteEditorId >", value, "noteeditorid");
            return (Criteria) this;
        }

        public Criteria andNoteeditoridGreaterThanOrEqualTo(String value) {
            addCriterion("noteEditorId >=", value, "noteeditorid");
            return (Criteria) this;
        }

        public Criteria andNoteeditoridLessThan(String value) {
            addCriterion("noteEditorId <", value, "noteeditorid");
            return (Criteria) this;
        }

        public Criteria andNoteeditoridLessThanOrEqualTo(String value) {
            addCriterion("noteEditorId <=", value, "noteeditorid");
            return (Criteria) this;
        }

        public Criteria andNoteeditoridLike(String value) {
            addCriterion("noteEditorId like", value, "noteeditorid");
            return (Criteria) this;
        }

        public Criteria andNoteeditoridNotLike(String value) {
            addCriterion("noteEditorId not like", value, "noteeditorid");
            return (Criteria) this;
        }

        public Criteria andNoteeditoridIn(List<String> values) {
            addCriterion("noteEditorId in", values, "noteeditorid");
            return (Criteria) this;
        }

        public Criteria andNoteeditoridNotIn(List<String> values) {
            addCriterion("noteEditorId not in", values, "noteeditorid");
            return (Criteria) this;
        }

        public Criteria andNoteeditoridBetween(String value1, String value2) {
            addCriterion("noteEditorId between", value1, value2, "noteeditorid");
            return (Criteria) this;
        }

        public Criteria andNoteeditoridNotBetween(String value1, String value2) {
            addCriterion("noteEditorId not between", value1, value2, "noteeditorid");
            return (Criteria) this;
        }

        public Criteria andNoteapproversidIsNull() {
            addCriterion("noteApproversId is null");
            return (Criteria) this;
        }

        public Criteria andNoteapproversidIsNotNull() {
            addCriterion("noteApproversId is not null");
            return (Criteria) this;
        }

        public Criteria andNoteapproversidEqualTo(String value) {
            addCriterion("noteApproversId =", value, "noteapproversid");
            return (Criteria) this;
        }

        public Criteria andNoteapproversidNotEqualTo(String value) {
            addCriterion("noteApproversId <>", value, "noteapproversid");
            return (Criteria) this;
        }

        public Criteria andNoteapproversidGreaterThan(String value) {
            addCriterion("noteApproversId >", value, "noteapproversid");
            return (Criteria) this;
        }

        public Criteria andNoteapproversidGreaterThanOrEqualTo(String value) {
            addCriterion("noteApproversId >=", value, "noteapproversid");
            return (Criteria) this;
        }

        public Criteria andNoteapproversidLessThan(String value) {
            addCriterion("noteApproversId <", value, "noteapproversid");
            return (Criteria) this;
        }

        public Criteria andNoteapproversidLessThanOrEqualTo(String value) {
            addCriterion("noteApproversId <=", value, "noteapproversid");
            return (Criteria) this;
        }

        public Criteria andNoteapproversidLike(String value) {
            addCriterion("noteApproversId like", value, "noteapproversid");
            return (Criteria) this;
        }

        public Criteria andNoteapproversidNotLike(String value) {
            addCriterion("noteApproversId not like", value, "noteapproversid");
            return (Criteria) this;
        }

        public Criteria andNoteapproversidIn(List<String> values) {
            addCriterion("noteApproversId in", values, "noteapproversid");
            return (Criteria) this;
        }

        public Criteria andNoteapproversidNotIn(List<String> values) {
            addCriterion("noteApproversId not in", values, "noteapproversid");
            return (Criteria) this;
        }

        public Criteria andNoteapproversidBetween(String value1, String value2) {
            addCriterion("noteApproversId between", value1, value2, "noteapproversid");
            return (Criteria) this;
        }

        public Criteria andNoteapproversidNotBetween(String value1, String value2) {
            addCriterion("noteApproversId not between", value1, value2, "noteapproversid");
            return (Criteria) this;
        }

        public Criteria andNotescaleIsNull() {
            addCriterion("noteScale is null");
            return (Criteria) this;
        }

        public Criteria andNotescaleIsNotNull() {
            addCriterion("noteScale is not null");
            return (Criteria) this;
        }

        public Criteria andNotescaleEqualTo(String value) {
            addCriterion("noteScale =", value, "notescale");
            return (Criteria) this;
        }

        public Criteria andNotescaleNotEqualTo(String value) {
            addCriterion("noteScale <>", value, "notescale");
            return (Criteria) this;
        }

        public Criteria andNotescaleGreaterThan(String value) {
            addCriterion("noteScale >", value, "notescale");
            return (Criteria) this;
        }

        public Criteria andNotescaleGreaterThanOrEqualTo(String value) {
            addCriterion("noteScale >=", value, "notescale");
            return (Criteria) this;
        }

        public Criteria andNotescaleLessThan(String value) {
            addCriterion("noteScale <", value, "notescale");
            return (Criteria) this;
        }

        public Criteria andNotescaleLessThanOrEqualTo(String value) {
            addCriterion("noteScale <=", value, "notescale");
            return (Criteria) this;
        }

        public Criteria andNotescaleLike(String value) {
            addCriterion("noteScale like", value, "notescale");
            return (Criteria) this;
        }

        public Criteria andNotescaleNotLike(String value) {
            addCriterion("noteScale not like", value, "notescale");
            return (Criteria) this;
        }

        public Criteria andNotescaleIn(List<String> values) {
            addCriterion("noteScale in", values, "notescale");
            return (Criteria) this;
        }

        public Criteria andNotescaleNotIn(List<String> values) {
            addCriterion("noteScale not in", values, "notescale");
            return (Criteria) this;
        }

        public Criteria andNotescaleBetween(String value1, String value2) {
            addCriterion("noteScale between", value1, value2, "notescale");
            return (Criteria) this;
        }

        public Criteria andNotescaleNotBetween(String value1, String value2) {
            addCriterion("noteScale not between", value1, value2, "notescale");
            return (Criteria) this;
        }

        public Criteria andNotecheckdateIsNull() {
            addCriterion("noteCheckDate is null");
            return (Criteria) this;
        }

        public Criteria andNotecheckdateIsNotNull() {
            addCriterion("noteCheckDate is not null");
            return (Criteria) this;
        }

        public Criteria andNotecheckdateEqualTo(Date value) {
            addCriterionForJDBCDate("noteCheckDate =", value, "notecheckdate");
            return (Criteria) this;
        }

        public Criteria andNotecheckdateNotEqualTo(Date value) {
            addCriterionForJDBCDate("noteCheckDate <>", value, "notecheckdate");
            return (Criteria) this;
        }

        public Criteria andNotecheckdateGreaterThan(Date value) {
            addCriterionForJDBCDate("noteCheckDate >", value, "notecheckdate");
            return (Criteria) this;
        }

        public Criteria andNotecheckdateGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("noteCheckDate >=", value, "notecheckdate");
            return (Criteria) this;
        }

        public Criteria andNotecheckdateLessThan(Date value) {
            addCriterionForJDBCDate("noteCheckDate <", value, "notecheckdate");
            return (Criteria) this;
        }

        public Criteria andNotecheckdateLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("noteCheckDate <=", value, "notecheckdate");
            return (Criteria) this;
        }

        public Criteria andNotecheckdateIn(List<Date> values) {
            addCriterionForJDBCDate("noteCheckDate in", values, "notecheckdate");
            return (Criteria) this;
        }

        public Criteria andNotecheckdateNotIn(List<Date> values) {
            addCriterionForJDBCDate("noteCheckDate not in", values, "notecheckdate");
            return (Criteria) this;
        }

        public Criteria andNotecheckdateBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("noteCheckDate between", value1, value2, "notecheckdate");
            return (Criteria) this;
        }

        public Criteria andNotecheckdateNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("noteCheckDate not between", value1, value2, "notecheckdate");
            return (Criteria) this;
        }

        public Criteria andNoteprogressIsNull() {
            addCriterion("noteProgress is null");
            return (Criteria) this;
        }

        public Criteria andNoteprogressIsNotNull() {
            addCriterion("noteProgress is not null");
            return (Criteria) this;
        }

        public Criteria andNoteprogressEqualTo(Integer value) {
            addCriterion("noteProgress =", value, "noteprogress");
            return (Criteria) this;
        }

        public Criteria andNoteprogressNotEqualTo(Integer value) {
            addCriterion("noteProgress <>", value, "noteprogress");
            return (Criteria) this;
        }

        public Criteria andNoteprogressGreaterThan(Integer value) {
            addCriterion("noteProgress >", value, "noteprogress");
            return (Criteria) this;
        }

        public Criteria andNoteprogressGreaterThanOrEqualTo(Integer value) {
            addCriterion("noteProgress >=", value, "noteprogress");
            return (Criteria) this;
        }

        public Criteria andNoteprogressLessThan(Integer value) {
            addCriterion("noteProgress <", value, "noteprogress");
            return (Criteria) this;
        }

        public Criteria andNoteprogressLessThanOrEqualTo(Integer value) {
            addCriterion("noteProgress <=", value, "noteprogress");
            return (Criteria) this;
        }

        public Criteria andNoteprogressIn(List<Integer> values) {
            addCriterion("noteProgress in", values, "noteprogress");
            return (Criteria) this;
        }

        public Criteria andNoteprogressNotIn(List<Integer> values) {
            addCriterion("noteProgress not in", values, "noteprogress");
            return (Criteria) this;
        }

        public Criteria andNoteprogressBetween(Integer value1, Integer value2) {
            addCriterion("noteProgress between", value1, value2, "noteprogress");
            return (Criteria) this;
        }

        public Criteria andNoteprogressNotBetween(Integer value1, Integer value2) {
            addCriterion("noteProgress not between", value1, value2, "noteprogress");
            return (Criteria) this;
        }

        public Criteria andNoterummagerIsNull() {
            addCriterion("noteRummager is null");
            return (Criteria) this;
        }

        public Criteria andNoterummagerIsNotNull() {
            addCriterion("noteRummager is not null");
            return (Criteria) this;
        }

        public Criteria andNoterummagerEqualTo(String value) {
            addCriterion("noteRummager =", value, "noterummager");
            return (Criteria) this;
        }

        public Criteria andNoterummagerNotEqualTo(String value) {
            addCriterion("noteRummager <>", value, "noterummager");
            return (Criteria) this;
        }

        public Criteria andNoterummagerGreaterThan(String value) {
            addCriterion("noteRummager >", value, "noterummager");
            return (Criteria) this;
        }

        public Criteria andNoterummagerGreaterThanOrEqualTo(String value) {
            addCriterion("noteRummager >=", value, "noterummager");
            return (Criteria) this;
        }

        public Criteria andNoterummagerLessThan(String value) {
            addCriterion("noteRummager <", value, "noterummager");
            return (Criteria) this;
        }

        public Criteria andNoterummagerLessThanOrEqualTo(String value) {
            addCriterion("noteRummager <=", value, "noterummager");
            return (Criteria) this;
        }

        public Criteria andNoterummagerLike(String value) {
            addCriterion("noteRummager like", value, "noterummager");
            return (Criteria) this;
        }

        public Criteria andNoterummagerNotLike(String value) {
            addCriterion("noteRummager not like", value, "noterummager");
            return (Criteria) this;
        }

        public Criteria andNoterummagerIn(List<String> values) {
            addCriterion("noteRummager in", values, "noterummager");
            return (Criteria) this;
        }

        public Criteria andNoterummagerNotIn(List<String> values) {
            addCriterion("noteRummager not in", values, "noterummager");
            return (Criteria) this;
        }

        public Criteria andNoterummagerBetween(String value1, String value2) {
            addCriterion("noteRummager between", value1, value2, "noterummager");
            return (Criteria) this;
        }

        public Criteria andNoterummagerNotBetween(String value1, String value2) {
            addCriterion("noteRummager not between", value1, value2, "noterummager");
            return (Criteria) this;
        }

        public Criteria andNotedateIsNull() {
            addCriterion("noteDate is null");
            return (Criteria) this;
        }

        public Criteria andNotedateIsNotNull() {
            addCriterion("noteDate is not null");
            return (Criteria) this;
        }

        public Criteria andNotedateEqualTo(Date value) {
            addCriterionForJDBCDate("noteDate =", value, "notedate");
            return (Criteria) this;
        }

        public Criteria andNotedateNotEqualTo(Date value) {
            addCriterionForJDBCDate("noteDate <>", value, "notedate");
            return (Criteria) this;
        }

        public Criteria andNotedateGreaterThan(Date value) {
            addCriterionForJDBCDate("noteDate >", value, "notedate");
            return (Criteria) this;
        }

        public Criteria andNotedateGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("noteDate >=", value, "notedate");
            return (Criteria) this;
        }

        public Criteria andNotedateLessThan(Date value) {
            addCriterionForJDBCDate("noteDate <", value, "notedate");
            return (Criteria) this;
        }

        public Criteria andNotedateLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("noteDate <=", value, "notedate");
            return (Criteria) this;
        }

        public Criteria andNotedateIn(List<Date> values) {
            addCriterionForJDBCDate("noteDate in", values, "notedate");
            return (Criteria) this;
        }

        public Criteria andNotedateNotIn(List<Date> values) {
            addCriterionForJDBCDate("noteDate not in", values, "notedate");
            return (Criteria) this;
        }

        public Criteria andNotedateBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("noteDate between", value1, value2, "notedate");
            return (Criteria) this;
        }

        public Criteria andNotedateNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("noteDate not between", value1, value2, "notedate");
            return (Criteria) this;
        }

        public Criteria andNoteattachmentIsNull() {
            addCriterion("noteAttachment is null");
            return (Criteria) this;
        }

        public Criteria andNoteattachmentIsNotNull() {
            addCriterion("noteAttachment is not null");
            return (Criteria) this;
        }

        public Criteria andNoteattachmentEqualTo(String value) {
            addCriterion("noteAttachment =", value, "noteattachment");
            return (Criteria) this;
        }

        public Criteria andNoteattachmentNotEqualTo(String value) {
            addCriterion("noteAttachment <>", value, "noteattachment");
            return (Criteria) this;
        }

        public Criteria andNoteattachmentGreaterThan(String value) {
            addCriterion("noteAttachment >", value, "noteattachment");
            return (Criteria) this;
        }

        public Criteria andNoteattachmentGreaterThanOrEqualTo(String value) {
            addCriterion("noteAttachment >=", value, "noteattachment");
            return (Criteria) this;
        }

        public Criteria andNoteattachmentLessThan(String value) {
            addCriterion("noteAttachment <", value, "noteattachment");
            return (Criteria) this;
        }

        public Criteria andNoteattachmentLessThanOrEqualTo(String value) {
            addCriterion("noteAttachment <=", value, "noteattachment");
            return (Criteria) this;
        }

        public Criteria andNoteattachmentLike(String value) {
            addCriterion("noteAttachment like", value, "noteattachment");
            return (Criteria) this;
        }

        public Criteria andNoteattachmentNotLike(String value) {
            addCriterion("noteAttachment not like", value, "noteattachment");
            return (Criteria) this;
        }

        public Criteria andNoteattachmentIn(List<String> values) {
            addCriterion("noteAttachment in", values, "noteattachment");
            return (Criteria) this;
        }

        public Criteria andNoteattachmentNotIn(List<String> values) {
            addCriterion("noteAttachment not in", values, "noteattachment");
            return (Criteria) this;
        }

        public Criteria andNoteattachmentBetween(String value1, String value2) {
            addCriterion("noteAttachment between", value1, value2, "noteattachment");
            return (Criteria) this;
        }

        public Criteria andNoteattachmentNotBetween(String value1, String value2) {
            addCriterion("noteAttachment not between", value1, value2, "noteattachment");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeIsNull() {
            addCriterion("attachmentType is null");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeIsNotNull() {
            addCriterion("attachmentType is not null");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeEqualTo(String value) {
            addCriterion("attachmentType =", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeNotEqualTo(String value) {
            addCriterion("attachmentType <>", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeGreaterThan(String value) {
            addCriterion("attachmentType >", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeGreaterThanOrEqualTo(String value) {
            addCriterion("attachmentType >=", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeLessThan(String value) {
            addCriterion("attachmentType <", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeLessThanOrEqualTo(String value) {
            addCriterion("attachmentType <=", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeLike(String value) {
            addCriterion("attachmentType like", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeNotLike(String value) {
            addCriterion("attachmentType not like", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeIn(List<String> values) {
            addCriterion("attachmentType in", values, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeNotIn(List<String> values) {
            addCriterion("attachmentType not in", values, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeBetween(String value1, String value2) {
            addCriterion("attachmentType between", value1, value2, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeNotBetween(String value1, String value2) {
            addCriterion("attachmentType not between", value1, value2, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andNoteconditionIsNull() {
            addCriterion("noteCondition is null");
            return (Criteria) this;
        }

        public Criteria andNoteconditionIsNotNull() {
            addCriterion("noteCondition is not null");
            return (Criteria) this;
        }

        public Criteria andNoteconditionEqualTo(String value) {
            addCriterion("noteCondition =", value, "notecondition");
            return (Criteria) this;
        }

        public Criteria andNoteconditionNotEqualTo(String value) {
            addCriterion("noteCondition <>", value, "notecondition");
            return (Criteria) this;
        }

        public Criteria andNoteconditionGreaterThan(String value) {
            addCriterion("noteCondition >", value, "notecondition");
            return (Criteria) this;
        }

        public Criteria andNoteconditionGreaterThanOrEqualTo(String value) {
            addCriterion("noteCondition >=", value, "notecondition");
            return (Criteria) this;
        }

        public Criteria andNoteconditionLessThan(String value) {
            addCriterion("noteCondition <", value, "notecondition");
            return (Criteria) this;
        }

        public Criteria andNoteconditionLessThanOrEqualTo(String value) {
            addCriterion("noteCondition <=", value, "notecondition");
            return (Criteria) this;
        }

        public Criteria andNoteconditionLike(String value) {
            addCriterion("noteCondition like", value, "notecondition");
            return (Criteria) this;
        }

        public Criteria andNoteconditionNotLike(String value) {
            addCriterion("noteCondition not like", value, "notecondition");
            return (Criteria) this;
        }

        public Criteria andNoteconditionIn(List<String> values) {
            addCriterion("noteCondition in", values, "notecondition");
            return (Criteria) this;
        }

        public Criteria andNoteconditionNotIn(List<String> values) {
            addCriterion("noteCondition not in", values, "notecondition");
            return (Criteria) this;
        }

        public Criteria andNoteconditionBetween(String value1, String value2) {
            addCriterion("noteCondition between", value1, value2, "notecondition");
            return (Criteria) this;
        }

        public Criteria andNoteconditionNotBetween(String value1, String value2) {
            addCriterion("noteCondition not between", value1, value2, "notecondition");
            return (Criteria) this;
        }

        public Criteria andNotecheckIsNull() {
            addCriterion("noteCheck is null");
            return (Criteria) this;
        }

        public Criteria andNotecheckIsNotNull() {
            addCriterion("noteCheck is not null");
            return (Criteria) this;
        }

        public Criteria andNotecheckEqualTo(String value) {
            addCriterion("noteCheck =", value, "notecheck");
            return (Criteria) this;
        }

        public Criteria andNotecheckNotEqualTo(String value) {
            addCriterion("noteCheck <>", value, "notecheck");
            return (Criteria) this;
        }

        public Criteria andNotecheckGreaterThan(String value) {
            addCriterion("noteCheck >", value, "notecheck");
            return (Criteria) this;
        }

        public Criteria andNotecheckGreaterThanOrEqualTo(String value) {
            addCriterion("noteCheck >=", value, "notecheck");
            return (Criteria) this;
        }

        public Criteria andNotecheckLessThan(String value) {
            addCriterion("noteCheck <", value, "notecheck");
            return (Criteria) this;
        }

        public Criteria andNotecheckLessThanOrEqualTo(String value) {
            addCriterion("noteCheck <=", value, "notecheck");
            return (Criteria) this;
        }

        public Criteria andNotecheckLike(String value) {
            addCriterion("noteCheck like", value, "notecheck");
            return (Criteria) this;
        }

        public Criteria andNotecheckNotLike(String value) {
            addCriterion("noteCheck not like", value, "notecheck");
            return (Criteria) this;
        }

        public Criteria andNotecheckIn(List<String> values) {
            addCriterion("noteCheck in", values, "notecheck");
            return (Criteria) this;
        }

        public Criteria andNotecheckNotIn(List<String> values) {
            addCriterion("noteCheck not in", values, "notecheck");
            return (Criteria) this;
        }

        public Criteria andNotecheckBetween(String value1, String value2) {
            addCriterion("noteCheck between", value1, value2, "notecheck");
            return (Criteria) this;
        }

        public Criteria andNotecheckNotBetween(String value1, String value2) {
            addCriterion("noteCheck not between", value1, value2, "notecheck");
            return (Criteria) this;
        }

        public Criteria andNotemeasureIsNull() {
            addCriterion("noteMeasure is null");
            return (Criteria) this;
        }

        public Criteria andNotemeasureIsNotNull() {
            addCriterion("noteMeasure is not null");
            return (Criteria) this;
        }

        public Criteria andNotemeasureEqualTo(String value) {
            addCriterion("noteMeasure =", value, "notemeasure");
            return (Criteria) this;
        }

        public Criteria andNotemeasureNotEqualTo(String value) {
            addCriterion("noteMeasure <>", value, "notemeasure");
            return (Criteria) this;
        }

        public Criteria andNotemeasureGreaterThan(String value) {
            addCriterion("noteMeasure >", value, "notemeasure");
            return (Criteria) this;
        }

        public Criteria andNotemeasureGreaterThanOrEqualTo(String value) {
            addCriterion("noteMeasure >=", value, "notemeasure");
            return (Criteria) this;
        }

        public Criteria andNotemeasureLessThan(String value) {
            addCriterion("noteMeasure <", value, "notemeasure");
            return (Criteria) this;
        }

        public Criteria andNotemeasureLessThanOrEqualTo(String value) {
            addCriterion("noteMeasure <=", value, "notemeasure");
            return (Criteria) this;
        }

        public Criteria andNotemeasureLike(String value) {
            addCriterion("noteMeasure like", value, "notemeasure");
            return (Criteria) this;
        }

        public Criteria andNotemeasureNotLike(String value) {
            addCriterion("noteMeasure not like", value, "notemeasure");
            return (Criteria) this;
        }

        public Criteria andNotemeasureIn(List<String> values) {
            addCriterion("noteMeasure in", values, "notemeasure");
            return (Criteria) this;
        }

        public Criteria andNotemeasureNotIn(List<String> values) {
            addCriterion("noteMeasure not in", values, "notemeasure");
            return (Criteria) this;
        }

        public Criteria andNotemeasureBetween(String value1, String value2) {
            addCriterion("noteMeasure between", value1, value2, "notemeasure");
            return (Criteria) this;
        }

        public Criteria andNotemeasureNotBetween(String value1, String value2) {
            addCriterion("noteMeasure not between", value1, value2, "notemeasure");
            return (Criteria) this;
        }

        public Criteria andNotereviewIsNull() {
            addCriterion("noteReview is null");
            return (Criteria) this;
        }

        public Criteria andNotereviewIsNotNull() {
            addCriterion("noteReview is not null");
            return (Criteria) this;
        }

        public Criteria andNotereviewEqualTo(String value) {
            addCriterion("noteReview =", value, "notereview");
            return (Criteria) this;
        }

        public Criteria andNotereviewNotEqualTo(String value) {
            addCriterion("noteReview <>", value, "notereview");
            return (Criteria) this;
        }

        public Criteria andNotereviewGreaterThan(String value) {
            addCriterion("noteReview >", value, "notereview");
            return (Criteria) this;
        }

        public Criteria andNotereviewGreaterThanOrEqualTo(String value) {
            addCriterion("noteReview >=", value, "notereview");
            return (Criteria) this;
        }

        public Criteria andNotereviewLessThan(String value) {
            addCriterion("noteReview <", value, "notereview");
            return (Criteria) this;
        }

        public Criteria andNotereviewLessThanOrEqualTo(String value) {
            addCriterion("noteReview <=", value, "notereview");
            return (Criteria) this;
        }

        public Criteria andNotereviewLike(String value) {
            addCriterion("noteReview like", value, "notereview");
            return (Criteria) this;
        }

        public Criteria andNotereviewNotLike(String value) {
            addCriterion("noteReview not like", value, "notereview");
            return (Criteria) this;
        }

        public Criteria andNotereviewIn(List<String> values) {
            addCriterion("noteReview in", values, "notereview");
            return (Criteria) this;
        }

        public Criteria andNotereviewNotIn(List<String> values) {
            addCriterion("noteReview not in", values, "notereview");
            return (Criteria) this;
        }

        public Criteria andNotereviewBetween(String value1, String value2) {
            addCriterion("noteReview between", value1, value2, "notereview");
            return (Criteria) this;
        }

        public Criteria andNotereviewNotBetween(String value1, String value2) {
            addCriterion("noteReview not between", value1, value2, "notereview");
            return (Criteria) this;
        }

        public Criteria andSafetystatusIsNull() {
            addCriterion("safetyStatus is null");
            return (Criteria) this;
        }

        public Criteria andSafetystatusIsNotNull() {
            addCriterion("safetyStatus is not null");
            return (Criteria) this;
        }

        public Criteria andSafetystatusEqualTo(Integer value) {
            addCriterion("safetyStatus =", value, "safetystatus");
            return (Criteria) this;
        }

        public Criteria andSafetystatusNotEqualTo(Integer value) {
            addCriterion("safetyStatus <>", value, "safetystatus");
            return (Criteria) this;
        }

        public Criteria andSafetystatusGreaterThan(Integer value) {
            addCriterion("safetyStatus >", value, "safetystatus");
            return (Criteria) this;
        }

        public Criteria andSafetystatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("safetyStatus >=", value, "safetystatus");
            return (Criteria) this;
        }

        public Criteria andSafetystatusLessThan(Integer value) {
            addCriterion("safetyStatus <", value, "safetystatus");
            return (Criteria) this;
        }

        public Criteria andSafetystatusLessThanOrEqualTo(Integer value) {
            addCriterion("safetyStatus <=", value, "safetystatus");
            return (Criteria) this;
        }

        public Criteria andSafetystatusIn(List<Integer> values) {
            addCriterion("safetyStatus in", values, "safetystatus");
            return (Criteria) this;
        }

        public Criteria andSafetystatusNotIn(List<Integer> values) {
            addCriterion("safetyStatus not in", values, "safetystatus");
            return (Criteria) this;
        }

        public Criteria andSafetystatusBetween(Integer value1, Integer value2) {
            addCriterion("safetyStatus between", value1, value2, "safetystatus");
            return (Criteria) this;
        }

        public Criteria andSafetystatusNotBetween(Integer value1, Integer value2) {
            addCriterion("safetyStatus not between", value1, value2, "safetystatus");
            return (Criteria) this;
        }

        public Criteria andApprovedateIsNull() {
            addCriterion("approveDate is null");
            return (Criteria) this;
        }

        public Criteria andApprovedateIsNotNull() {
            addCriterion("approveDate is not null");
            return (Criteria) this;
        }

        public Criteria andApprovedateEqualTo(Date value) {
            addCriterion("approveDate =", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateNotEqualTo(Date value) {
            addCriterion("approveDate <>", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateGreaterThan(Date value) {
            addCriterion("approveDate >", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateGreaterThanOrEqualTo(Date value) {
            addCriterion("approveDate >=", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateLessThan(Date value) {
            addCriterion("approveDate <", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateLessThanOrEqualTo(Date value) {
            addCriterion("approveDate <=", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateIn(List<Date> values) {
            addCriterion("approveDate in", values, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateNotIn(List<Date> values) {
            addCriterion("approveDate not in", values, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateBetween(Date value1, Date value2) {
            addCriterion("approveDate between", value1, value2, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateNotBetween(Date value1, Date value2) {
            addCriterion("approveDate not between", value1, value2, "approvedate");
            return (Criteria) this;
        }

        public Criteria andSafetycommentIsNull() {
            addCriterion("safetyComment is null");
            return (Criteria) this;
        }

        public Criteria andSafetycommentIsNotNull() {
            addCriterion("safetyComment is not null");
            return (Criteria) this;
        }

        public Criteria andSafetycommentEqualTo(String value) {
            addCriterion("safetyComment =", value, "safetycomment");
            return (Criteria) this;
        }

        public Criteria andSafetycommentNotEqualTo(String value) {
            addCriterion("safetyComment <>", value, "safetycomment");
            return (Criteria) this;
        }

        public Criteria andSafetycommentGreaterThan(String value) {
            addCriterion("safetyComment >", value, "safetycomment");
            return (Criteria) this;
        }

        public Criteria andSafetycommentGreaterThanOrEqualTo(String value) {
            addCriterion("safetyComment >=", value, "safetycomment");
            return (Criteria) this;
        }

        public Criteria andSafetycommentLessThan(String value) {
            addCriterion("safetyComment <", value, "safetycomment");
            return (Criteria) this;
        }

        public Criteria andSafetycommentLessThanOrEqualTo(String value) {
            addCriterion("safetyComment <=", value, "safetycomment");
            return (Criteria) this;
        }

        public Criteria andSafetycommentLike(String value) {
            addCriterion("safetyComment like", value, "safetycomment");
            return (Criteria) this;
        }

        public Criteria andSafetycommentNotLike(String value) {
            addCriterion("safetyComment not like", value, "safetycomment");
            return (Criteria) this;
        }

        public Criteria andSafetycommentIn(List<String> values) {
            addCriterion("safetyComment in", values, "safetycomment");
            return (Criteria) this;
        }

        public Criteria andSafetycommentNotIn(List<String> values) {
            addCriterion("safetyComment not in", values, "safetycomment");
            return (Criteria) this;
        }

        public Criteria andSafetycommentBetween(String value1, String value2) {
            addCriterion("safetyComment between", value1, value2, "safetycomment");
            return (Criteria) this;
        }

        public Criteria andSafetycommentNotBetween(String value1, String value2) {
            addCriterion("safetyComment not between", value1, value2, "safetycomment");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}