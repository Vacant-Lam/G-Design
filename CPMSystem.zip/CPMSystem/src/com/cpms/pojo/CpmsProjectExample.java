package com.cpms.pojo;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class CpmsProjectExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public CpmsProjectExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<java.sql.Date>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andProjectidIsNull() {
            addCriterion("projectId is null");
            return (Criteria) this;
        }

        public Criteria andProjectidIsNotNull() {
            addCriterion("projectId is not null");
            return (Criteria) this;
        }

        public Criteria andProjectidEqualTo(String value) {
            addCriterion("projectId =", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidNotEqualTo(String value) {
            addCriterion("projectId <>", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidGreaterThan(String value) {
            addCriterion("projectId >", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidGreaterThanOrEqualTo(String value) {
            addCriterion("projectId >=", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidLessThan(String value) {
            addCriterion("projectId <", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidLessThanOrEqualTo(String value) {
            addCriterion("projectId <=", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidLike(String value) {
            addCriterion("projectId like", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidNotLike(String value) {
            addCriterion("projectId not like", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidIn(List<String> values) {
            addCriterion("projectId in", values, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidNotIn(List<String> values) {
            addCriterion("projectId not in", values, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidBetween(String value1, String value2) {
            addCriterion("projectId between", value1, value2, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidNotBetween(String value1, String value2) {
            addCriterion("projectId not between", value1, value2, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectnameIsNull() {
            addCriterion("projectName is null");
            return (Criteria) this;
        }

        public Criteria andProjectnameIsNotNull() {
            addCriterion("projectName is not null");
            return (Criteria) this;
        }

        public Criteria andProjectnameEqualTo(String value) {
            addCriterion("projectName =", value, "projectname");
            return (Criteria) this;
        }

        public Criteria andProjectnameNotEqualTo(String value) {
            addCriterion("projectName <>", value, "projectname");
            return (Criteria) this;
        }

        public Criteria andProjectnameGreaterThan(String value) {
            addCriterion("projectName >", value, "projectname");
            return (Criteria) this;
        }

        public Criteria andProjectnameGreaterThanOrEqualTo(String value) {
            addCriterion("projectName >=", value, "projectname");
            return (Criteria) this;
        }

        public Criteria andProjectnameLessThan(String value) {
            addCriterion("projectName <", value, "projectname");
            return (Criteria) this;
        }

        public Criteria andProjectnameLessThanOrEqualTo(String value) {
            addCriterion("projectName <=", value, "projectname");
            return (Criteria) this;
        }

        public Criteria andProjectnameLike(String value) {
            addCriterion("projectName like", value, "projectname");
            return (Criteria) this;
        }

        public Criteria andProjectnameNotLike(String value) {
            addCriterion("projectName not like", value, "projectname");
            return (Criteria) this;
        }

        public Criteria andProjectnameIn(List<String> values) {
            addCriterion("projectName in", values, "projectname");
            return (Criteria) this;
        }

        public Criteria andProjectnameNotIn(List<String> values) {
            addCriterion("projectName not in", values, "projectname");
            return (Criteria) this;
        }

        public Criteria andProjectnameBetween(String value1, String value2) {
            addCriterion("projectName between", value1, value2, "projectname");
            return (Criteria) this;
        }

        public Criteria andProjectnameNotBetween(String value1, String value2) {
            addCriterion("projectName not between", value1, value2, "projectname");
            return (Criteria) this;
        }

        public Criteria andProjectstarttimeIsNull() {
            addCriterion("projectStartTime is null");
            return (Criteria) this;
        }

        public Criteria andProjectstarttimeIsNotNull() {
            addCriterion("projectStartTime is not null");
            return (Criteria) this;
        }

        public Criteria andProjectstarttimeEqualTo(Date value) {
            addCriterionForJDBCDate("projectStartTime =", value, "projectstarttime");
            return (Criteria) this;
        }

        public Criteria andProjectstarttimeNotEqualTo(Date value) {
            addCriterionForJDBCDate("projectStartTime <>", value, "projectstarttime");
            return (Criteria) this;
        }

        public Criteria andProjectstarttimeGreaterThan(Date value) {
            addCriterionForJDBCDate("projectStartTime >", value, "projectstarttime");
            return (Criteria) this;
        }

        public Criteria andProjectstarttimeGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("projectStartTime >=", value, "projectstarttime");
            return (Criteria) this;
        }

        public Criteria andProjectstarttimeLessThan(Date value) {
            addCriterionForJDBCDate("projectStartTime <", value, "projectstarttime");
            return (Criteria) this;
        }

        public Criteria andProjectstarttimeLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("projectStartTime <=", value, "projectstarttime");
            return (Criteria) this;
        }

        public Criteria andProjectstarttimeIn(List<Date> values) {
            addCriterionForJDBCDate("projectStartTime in", values, "projectstarttime");
            return (Criteria) this;
        }

        public Criteria andProjectstarttimeNotIn(List<Date> values) {
            addCriterionForJDBCDate("projectStartTime not in", values, "projectstarttime");
            return (Criteria) this;
        }

        public Criteria andProjectstarttimeBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("projectStartTime between", value1, value2, "projectstarttime");
            return (Criteria) this;
        }

        public Criteria andProjectstarttimeNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("projectStartTime not between", value1, value2, "projectstarttime");
            return (Criteria) this;
        }

        public Criteria andProjectendtimeIsNull() {
            addCriterion("projectEndTime is null");
            return (Criteria) this;
        }

        public Criteria andProjectendtimeIsNotNull() {
            addCriterion("projectEndTime is not null");
            return (Criteria) this;
        }

        public Criteria andProjectendtimeEqualTo(Date value) {
            addCriterionForJDBCDate("projectEndTime =", value, "projectendtime");
            return (Criteria) this;
        }

        public Criteria andProjectendtimeNotEqualTo(Date value) {
            addCriterionForJDBCDate("projectEndTime <>", value, "projectendtime");
            return (Criteria) this;
        }

        public Criteria andProjectendtimeGreaterThan(Date value) {
            addCriterionForJDBCDate("projectEndTime >", value, "projectendtime");
            return (Criteria) this;
        }

        public Criteria andProjectendtimeGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("projectEndTime >=", value, "projectendtime");
            return (Criteria) this;
        }

        public Criteria andProjectendtimeLessThan(Date value) {
            addCriterionForJDBCDate("projectEndTime <", value, "projectendtime");
            return (Criteria) this;
        }

        public Criteria andProjectendtimeLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("projectEndTime <=", value, "projectendtime");
            return (Criteria) this;
        }

        public Criteria andProjectendtimeIn(List<Date> values) {
            addCriterionForJDBCDate("projectEndTime in", values, "projectendtime");
            return (Criteria) this;
        }

        public Criteria andProjectendtimeNotIn(List<Date> values) {
            addCriterionForJDBCDate("projectEndTime not in", values, "projectendtime");
            return (Criteria) this;
        }

        public Criteria andProjectendtimeBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("projectEndTime between", value1, value2, "projectendtime");
            return (Criteria) this;
        }

        public Criteria andProjectendtimeNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("projectEndTime not between", value1, value2, "projectendtime");
            return (Criteria) this;
        }

        public Criteria andProjectareaIsNull() {
            addCriterion("projectArea is null");
            return (Criteria) this;
        }

        public Criteria andProjectareaIsNotNull() {
            addCriterion("projectArea is not null");
            return (Criteria) this;
        }

        public Criteria andProjectareaEqualTo(String value) {
            addCriterion("projectArea =", value, "projectarea");
            return (Criteria) this;
        }

        public Criteria andProjectareaNotEqualTo(String value) {
            addCriterion("projectArea <>", value, "projectarea");
            return (Criteria) this;
        }

        public Criteria andProjectareaGreaterThan(String value) {
            addCriterion("projectArea >", value, "projectarea");
            return (Criteria) this;
        }

        public Criteria andProjectareaGreaterThanOrEqualTo(String value) {
            addCriterion("projectArea >=", value, "projectarea");
            return (Criteria) this;
        }

        public Criteria andProjectareaLessThan(String value) {
            addCriterion("projectArea <", value, "projectarea");
            return (Criteria) this;
        }

        public Criteria andProjectareaLessThanOrEqualTo(String value) {
            addCriterion("projectArea <=", value, "projectarea");
            return (Criteria) this;
        }

        public Criteria andProjectareaLike(String value) {
            addCriterion("projectArea like", value, "projectarea");
            return (Criteria) this;
        }

        public Criteria andProjectareaNotLike(String value) {
            addCriterion("projectArea not like", value, "projectarea");
            return (Criteria) this;
        }

        public Criteria andProjectareaIn(List<String> values) {
            addCriterion("projectArea in", values, "projectarea");
            return (Criteria) this;
        }

        public Criteria andProjectareaNotIn(List<String> values) {
            addCriterion("projectArea not in", values, "projectarea");
            return (Criteria) this;
        }

        public Criteria andProjectareaBetween(String value1, String value2) {
            addCriterion("projectArea between", value1, value2, "projectarea");
            return (Criteria) this;
        }

        public Criteria andProjectareaNotBetween(String value1, String value2) {
            addCriterion("projectArea not between", value1, value2, "projectarea");
            return (Criteria) this;
        }

        public Criteria andProjectaddressIsNull() {
            addCriterion("projectAddress is null");
            return (Criteria) this;
        }

        public Criteria andProjectaddressIsNotNull() {
            addCriterion("projectAddress is not null");
            return (Criteria) this;
        }

        public Criteria andProjectaddressEqualTo(String value) {
            addCriterion("projectAddress =", value, "projectaddress");
            return (Criteria) this;
        }

        public Criteria andProjectaddressNotEqualTo(String value) {
            addCriterion("projectAddress <>", value, "projectaddress");
            return (Criteria) this;
        }

        public Criteria andProjectaddressGreaterThan(String value) {
            addCriterion("projectAddress >", value, "projectaddress");
            return (Criteria) this;
        }

        public Criteria andProjectaddressGreaterThanOrEqualTo(String value) {
            addCriterion("projectAddress >=", value, "projectaddress");
            return (Criteria) this;
        }

        public Criteria andProjectaddressLessThan(String value) {
            addCriterion("projectAddress <", value, "projectaddress");
            return (Criteria) this;
        }

        public Criteria andProjectaddressLessThanOrEqualTo(String value) {
            addCriterion("projectAddress <=", value, "projectaddress");
            return (Criteria) this;
        }

        public Criteria andProjectaddressLike(String value) {
            addCriterion("projectAddress like", value, "projectaddress");
            return (Criteria) this;
        }

        public Criteria andProjectaddressNotLike(String value) {
            addCriterion("projectAddress not like", value, "projectaddress");
            return (Criteria) this;
        }

        public Criteria andProjectaddressIn(List<String> values) {
            addCriterion("projectAddress in", values, "projectaddress");
            return (Criteria) this;
        }

        public Criteria andProjectaddressNotIn(List<String> values) {
            addCriterion("projectAddress not in", values, "projectaddress");
            return (Criteria) this;
        }

        public Criteria andProjectaddressBetween(String value1, String value2) {
            addCriterion("projectAddress between", value1, value2, "projectaddress");
            return (Criteria) this;
        }

        public Criteria andProjectaddressNotBetween(String value1, String value2) {
            addCriterion("projectAddress not between", value1, value2, "projectaddress");
            return (Criteria) this;
        }

        public Criteria andProjectdurationIsNull() {
            addCriterion("projectDuration is null");
            return (Criteria) this;
        }

        public Criteria andProjectdurationIsNotNull() {
            addCriterion("projectDuration is not null");
            return (Criteria) this;
        }

        public Criteria andProjectdurationEqualTo(String value) {
            addCriterion("projectDuration =", value, "projectduration");
            return (Criteria) this;
        }

        public Criteria andProjectdurationNotEqualTo(String value) {
            addCriterion("projectDuration <>", value, "projectduration");
            return (Criteria) this;
        }

        public Criteria andProjectdurationGreaterThan(String value) {
            addCriterion("projectDuration >", value, "projectduration");
            return (Criteria) this;
        }

        public Criteria andProjectdurationGreaterThanOrEqualTo(String value) {
            addCriterion("projectDuration >=", value, "projectduration");
            return (Criteria) this;
        }

        public Criteria andProjectdurationLessThan(String value) {
            addCriterion("projectDuration <", value, "projectduration");
            return (Criteria) this;
        }

        public Criteria andProjectdurationLessThanOrEqualTo(String value) {
            addCriterion("projectDuration <=", value, "projectduration");
            return (Criteria) this;
        }

        public Criteria andProjectdurationLike(String value) {
            addCriterion("projectDuration like", value, "projectduration");
            return (Criteria) this;
        }

        public Criteria andProjectdurationNotLike(String value) {
            addCriterion("projectDuration not like", value, "projectduration");
            return (Criteria) this;
        }

        public Criteria andProjectdurationIn(List<String> values) {
            addCriterion("projectDuration in", values, "projectduration");
            return (Criteria) this;
        }

        public Criteria andProjectdurationNotIn(List<String> values) {
            addCriterion("projectDuration not in", values, "projectduration");
            return (Criteria) this;
        }

        public Criteria andProjectdurationBetween(String value1, String value2) {
            addCriterion("projectDuration between", value1, value2, "projectduration");
            return (Criteria) this;
        }

        public Criteria andProjectdurationNotBetween(String value1, String value2) {
            addCriterion("projectDuration not between", value1, value2, "projectduration");
            return (Criteria) this;
        }

        public Criteria andProjectquantitiesestimateIsNull() {
            addCriterion("projectQuantitiesEstimate is null");
            return (Criteria) this;
        }

        public Criteria andProjectquantitiesestimateIsNotNull() {
            addCriterion("projectQuantitiesEstimate is not null");
            return (Criteria) this;
        }

        public Criteria andProjectquantitiesestimateEqualTo(Integer value) {
            addCriterion("projectQuantitiesEstimate =", value, "projectquantitiesestimate");
            return (Criteria) this;
        }

        public Criteria andProjectquantitiesestimateNotEqualTo(Integer value) {
            addCriterion("projectQuantitiesEstimate <>", value, "projectquantitiesestimate");
            return (Criteria) this;
        }

        public Criteria andProjectquantitiesestimateGreaterThan(Integer value) {
            addCriterion("projectQuantitiesEstimate >", value, "projectquantitiesestimate");
            return (Criteria) this;
        }

        public Criteria andProjectquantitiesestimateGreaterThanOrEqualTo(Integer value) {
            addCriterion("projectQuantitiesEstimate >=", value, "projectquantitiesestimate");
            return (Criteria) this;
        }

        public Criteria andProjectquantitiesestimateLessThan(Integer value) {
            addCriterion("projectQuantitiesEstimate <", value, "projectquantitiesestimate");
            return (Criteria) this;
        }

        public Criteria andProjectquantitiesestimateLessThanOrEqualTo(Integer value) {
            addCriterion("projectQuantitiesEstimate <=", value, "projectquantitiesestimate");
            return (Criteria) this;
        }

        public Criteria andProjectquantitiesestimateIn(List<Integer> values) {
            addCriterion("projectQuantitiesEstimate in", values, "projectquantitiesestimate");
            return (Criteria) this;
        }

        public Criteria andProjectquantitiesestimateNotIn(List<Integer> values) {
            addCriterion("projectQuantitiesEstimate not in", values, "projectquantitiesestimate");
            return (Criteria) this;
        }

        public Criteria andProjectquantitiesestimateBetween(Integer value1, Integer value2) {
            addCriterion("projectQuantitiesEstimate between", value1, value2, "projectquantitiesestimate");
            return (Criteria) this;
        }

        public Criteria andProjectquantitiesestimateNotBetween(Integer value1, Integer value2) {
            addCriterion("projectQuantitiesEstimate not between", value1, value2, "projectquantitiesestimate");
            return (Criteria) this;
        }

        public Criteria andProjectcostestimateIsNull() {
            addCriterion("projectCostEstimate is null");
            return (Criteria) this;
        }

        public Criteria andProjectcostestimateIsNotNull() {
            addCriterion("projectCostEstimate is not null");
            return (Criteria) this;
        }

        public Criteria andProjectcostestimateEqualTo(Double value) {
            addCriterion("projectCostEstimate =", value, "projectcostestimate");
            return (Criteria) this;
        }

        public Criteria andProjectcostestimateNotEqualTo(Double value) {
            addCriterion("projectCostEstimate <>", value, "projectcostestimate");
            return (Criteria) this;
        }

        public Criteria andProjectcostestimateGreaterThan(Double value) {
            addCriterion("projectCostEstimate >", value, "projectcostestimate");
            return (Criteria) this;
        }

        public Criteria andProjectcostestimateGreaterThanOrEqualTo(Double value) {
            addCriterion("projectCostEstimate >=", value, "projectcostestimate");
            return (Criteria) this;
        }

        public Criteria andProjectcostestimateLessThan(Double value) {
            addCriterion("projectCostEstimate <", value, "projectcostestimate");
            return (Criteria) this;
        }

        public Criteria andProjectcostestimateLessThanOrEqualTo(Double value) {
            addCriterion("projectCostEstimate <=", value, "projectcostestimate");
            return (Criteria) this;
        }

        public Criteria andProjectcostestimateIn(List<Double> values) {
            addCriterion("projectCostEstimate in", values, "projectcostestimate");
            return (Criteria) this;
        }

        public Criteria andProjectcostestimateNotIn(List<Double> values) {
            addCriterion("projectCostEstimate not in", values, "projectcostestimate");
            return (Criteria) this;
        }

        public Criteria andProjectcostestimateBetween(Double value1, Double value2) {
            addCriterion("projectCostEstimate between", value1, value2, "projectcostestimate");
            return (Criteria) this;
        }

        public Criteria andProjectcostestimateNotBetween(Double value1, Double value2) {
            addCriterion("projectCostEstimate not between", value1, value2, "projectcostestimate");
            return (Criteria) this;
        }

        public Criteria andProjectprofitestimateIsNull() {
            addCriterion("projectProfitEstimate is null");
            return (Criteria) this;
        }

        public Criteria andProjectprofitestimateIsNotNull() {
            addCriterion("projectProfitEstimate is not null");
            return (Criteria) this;
        }

        public Criteria andProjectprofitestimateEqualTo(Double value) {
            addCriterion("projectProfitEstimate =", value, "projectprofitestimate");
            return (Criteria) this;
        }

        public Criteria andProjectprofitestimateNotEqualTo(Double value) {
            addCriterion("projectProfitEstimate <>", value, "projectprofitestimate");
            return (Criteria) this;
        }

        public Criteria andProjectprofitestimateGreaterThan(Double value) {
            addCriterion("projectProfitEstimate >", value, "projectprofitestimate");
            return (Criteria) this;
        }

        public Criteria andProjectprofitestimateGreaterThanOrEqualTo(Double value) {
            addCriterion("projectProfitEstimate >=", value, "projectprofitestimate");
            return (Criteria) this;
        }

        public Criteria andProjectprofitestimateLessThan(Double value) {
            addCriterion("projectProfitEstimate <", value, "projectprofitestimate");
            return (Criteria) this;
        }

        public Criteria andProjectprofitestimateLessThanOrEqualTo(Double value) {
            addCriterion("projectProfitEstimate <=", value, "projectprofitestimate");
            return (Criteria) this;
        }

        public Criteria andProjectprofitestimateIn(List<Double> values) {
            addCriterion("projectProfitEstimate in", values, "projectprofitestimate");
            return (Criteria) this;
        }

        public Criteria andProjectprofitestimateNotIn(List<Double> values) {
            addCriterion("projectProfitEstimate not in", values, "projectprofitestimate");
            return (Criteria) this;
        }

        public Criteria andProjectprofitestimateBetween(Double value1, Double value2) {
            addCriterion("projectProfitEstimate between", value1, value2, "projectprofitestimate");
            return (Criteria) this;
        }

        public Criteria andProjectprofitestimateNotBetween(Double value1, Double value2) {
            addCriterion("projectProfitEstimate not between", value1, value2, "projectprofitestimate");
            return (Criteria) this;
        }

        public Criteria andProjectqualitylevelIsNull() {
            addCriterion("projectQualityLevel is null");
            return (Criteria) this;
        }

        public Criteria andProjectqualitylevelIsNotNull() {
            addCriterion("projectQualityLevel is not null");
            return (Criteria) this;
        }

        public Criteria andProjectqualitylevelEqualTo(String value) {
            addCriterion("projectQualityLevel =", value, "projectqualitylevel");
            return (Criteria) this;
        }

        public Criteria andProjectqualitylevelNotEqualTo(String value) {
            addCriterion("projectQualityLevel <>", value, "projectqualitylevel");
            return (Criteria) this;
        }

        public Criteria andProjectqualitylevelGreaterThan(String value) {
            addCriterion("projectQualityLevel >", value, "projectqualitylevel");
            return (Criteria) this;
        }

        public Criteria andProjectqualitylevelGreaterThanOrEqualTo(String value) {
            addCriterion("projectQualityLevel >=", value, "projectqualitylevel");
            return (Criteria) this;
        }

        public Criteria andProjectqualitylevelLessThan(String value) {
            addCriterion("projectQualityLevel <", value, "projectqualitylevel");
            return (Criteria) this;
        }

        public Criteria andProjectqualitylevelLessThanOrEqualTo(String value) {
            addCriterion("projectQualityLevel <=", value, "projectqualitylevel");
            return (Criteria) this;
        }

        public Criteria andProjectqualitylevelLike(String value) {
            addCriterion("projectQualityLevel like", value, "projectqualitylevel");
            return (Criteria) this;
        }

        public Criteria andProjectqualitylevelNotLike(String value) {
            addCriterion("projectQualityLevel not like", value, "projectqualitylevel");
            return (Criteria) this;
        }

        public Criteria andProjectqualitylevelIn(List<String> values) {
            addCriterion("projectQualityLevel in", values, "projectqualitylevel");
            return (Criteria) this;
        }

        public Criteria andProjectqualitylevelNotIn(List<String> values) {
            addCriterion("projectQualityLevel not in", values, "projectqualitylevel");
            return (Criteria) this;
        }

        public Criteria andProjectqualitylevelBetween(String value1, String value2) {
            addCriterion("projectQualityLevel between", value1, value2, "projectqualitylevel");
            return (Criteria) this;
        }

        public Criteria andProjectqualitylevelNotBetween(String value1, String value2) {
            addCriterion("projectQualityLevel not between", value1, value2, "projectqualitylevel");
            return (Criteria) this;
        }

        public Criteria andProjecttrackeridIsNull() {
            addCriterion("projectTrackerId is null");
            return (Criteria) this;
        }

        public Criteria andProjecttrackeridIsNotNull() {
            addCriterion("projectTrackerId is not null");
            return (Criteria) this;
        }

        public Criteria andProjecttrackeridEqualTo(String value) {
            addCriterion("projectTrackerId =", value, "projecttrackerid");
            return (Criteria) this;
        }

        public Criteria andProjecttrackeridNotEqualTo(String value) {
            addCriterion("projectTrackerId <>", value, "projecttrackerid");
            return (Criteria) this;
        }

        public Criteria andProjecttrackeridGreaterThan(String value) {
            addCriterion("projectTrackerId >", value, "projecttrackerid");
            return (Criteria) this;
        }

        public Criteria andProjecttrackeridGreaterThanOrEqualTo(String value) {
            addCriterion("projectTrackerId >=", value, "projecttrackerid");
            return (Criteria) this;
        }

        public Criteria andProjecttrackeridLessThan(String value) {
            addCriterion("projectTrackerId <", value, "projecttrackerid");
            return (Criteria) this;
        }

        public Criteria andProjecttrackeridLessThanOrEqualTo(String value) {
            addCriterion("projectTrackerId <=", value, "projecttrackerid");
            return (Criteria) this;
        }

        public Criteria andProjecttrackeridLike(String value) {
            addCriterion("projectTrackerId like", value, "projecttrackerid");
            return (Criteria) this;
        }

        public Criteria andProjecttrackeridNotLike(String value) {
            addCriterion("projectTrackerId not like", value, "projecttrackerid");
            return (Criteria) this;
        }

        public Criteria andProjecttrackeridIn(List<String> values) {
            addCriterion("projectTrackerId in", values, "projecttrackerid");
            return (Criteria) this;
        }

        public Criteria andProjecttrackeridNotIn(List<String> values) {
            addCriterion("projectTrackerId not in", values, "projecttrackerid");
            return (Criteria) this;
        }

        public Criteria andProjecttrackeridBetween(String value1, String value2) {
            addCriterion("projectTrackerId between", value1, value2, "projecttrackerid");
            return (Criteria) this;
        }

        public Criteria andProjecttrackeridNotBetween(String value1, String value2) {
            addCriterion("projectTrackerId not between", value1, value2, "projecttrackerid");
            return (Criteria) this;
        }

        public Criteria andProjectstatusIsNull() {
            addCriterion("projectStatus is null");
            return (Criteria) this;
        }

        public Criteria andProjectstatusIsNotNull() {
            addCriterion("projectStatus is not null");
            return (Criteria) this;
        }

        public Criteria andProjectstatusEqualTo(String value) {
            addCriterion("projectStatus =", value, "projectstatus");
            return (Criteria) this;
        }

        public Criteria andProjectstatusNotEqualTo(String value) {
            addCriterion("projectStatus <>", value, "projectstatus");
            return (Criteria) this;
        }

        public Criteria andProjectstatusGreaterThan(String value) {
            addCriterion("projectStatus >", value, "projectstatus");
            return (Criteria) this;
        }

        public Criteria andProjectstatusGreaterThanOrEqualTo(String value) {
            addCriterion("projectStatus >=", value, "projectstatus");
            return (Criteria) this;
        }

        public Criteria andProjectstatusLessThan(String value) {
            addCriterion("projectStatus <", value, "projectstatus");
            return (Criteria) this;
        }

        public Criteria andProjectstatusLessThanOrEqualTo(String value) {
            addCriterion("projectStatus <=", value, "projectstatus");
            return (Criteria) this;
        }

        public Criteria andProjectstatusLike(String value) {
            addCriterion("projectStatus like", value, "projectstatus");
            return (Criteria) this;
        }

        public Criteria andProjectstatusNotLike(String value) {
            addCriterion("projectStatus not like", value, "projectstatus");
            return (Criteria) this;
        }

        public Criteria andProjectstatusIn(List<String> values) {
            addCriterion("projectStatus in", values, "projectstatus");
            return (Criteria) this;
        }

        public Criteria andProjectstatusNotIn(List<String> values) {
            addCriterion("projectStatus not in", values, "projectstatus");
            return (Criteria) this;
        }

        public Criteria andProjectstatusBetween(String value1, String value2) {
            addCriterion("projectStatus between", value1, value2, "projectstatus");
            return (Criteria) this;
        }

        public Criteria andProjectstatusNotBetween(String value1, String value2) {
            addCriterion("projectStatus not between", value1, value2, "projectstatus");
            return (Criteria) this;
        }

        public Criteria andProjectdateIsNull() {
            addCriterion("projectDate is null");
            return (Criteria) this;
        }

        public Criteria andProjectdateIsNotNull() {
            addCriterion("projectDate is not null");
            return (Criteria) this;
        }

        public Criteria andProjectdateEqualTo(Date value) {
            addCriterionForJDBCDate("projectDate =", value, "projectdate");
            return (Criteria) this;
        }

        public Criteria andProjectdateNotEqualTo(Date value) {
            addCriterionForJDBCDate("projectDate <>", value, "projectdate");
            return (Criteria) this;
        }

        public Criteria andProjectdateGreaterThan(Date value) {
            addCriterionForJDBCDate("projectDate >", value, "projectdate");
            return (Criteria) this;
        }

        public Criteria andProjectdateGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("projectDate >=", value, "projectdate");
            return (Criteria) this;
        }

        public Criteria andProjectdateLessThan(Date value) {
            addCriterionForJDBCDate("projectDate <", value, "projectdate");
            return (Criteria) this;
        }

        public Criteria andProjectdateLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("projectDate <=", value, "projectdate");
            return (Criteria) this;
        }

        public Criteria andProjectdateIn(List<Date> values) {
            addCriterionForJDBCDate("projectDate in", values, "projectdate");
            return (Criteria) this;
        }

        public Criteria andProjectdateNotIn(List<Date> values) {
            addCriterionForJDBCDate("projectDate not in", values, "projectdate");
            return (Criteria) this;
        }

        public Criteria andProjectdateBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("projectDate between", value1, value2, "projectdate");
            return (Criteria) this;
        }

        public Criteria andProjectdateNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("projectDate not between", value1, value2, "projectdate");
            return (Criteria) this;
        }

        public Criteria andProjectremarkIsNull() {
            addCriterion("projectRemark is null");
            return (Criteria) this;
        }

        public Criteria andProjectremarkIsNotNull() {
            addCriterion("projectRemark is not null");
            return (Criteria) this;
        }

        public Criteria andProjectremarkEqualTo(String value) {
            addCriterion("projectRemark =", value, "projectremark");
            return (Criteria) this;
        }

        public Criteria andProjectremarkNotEqualTo(String value) {
            addCriterion("projectRemark <>", value, "projectremark");
            return (Criteria) this;
        }

        public Criteria andProjectremarkGreaterThan(String value) {
            addCriterion("projectRemark >", value, "projectremark");
            return (Criteria) this;
        }

        public Criteria andProjectremarkGreaterThanOrEqualTo(String value) {
            addCriterion("projectRemark >=", value, "projectremark");
            return (Criteria) this;
        }

        public Criteria andProjectremarkLessThan(String value) {
            addCriterion("projectRemark <", value, "projectremark");
            return (Criteria) this;
        }

        public Criteria andProjectremarkLessThanOrEqualTo(String value) {
            addCriterion("projectRemark <=", value, "projectremark");
            return (Criteria) this;
        }

        public Criteria andProjectremarkLike(String value) {
            addCriterion("projectRemark like", value, "projectremark");
            return (Criteria) this;
        }

        public Criteria andProjectremarkNotLike(String value) {
            addCriterion("projectRemark not like", value, "projectremark");
            return (Criteria) this;
        }

        public Criteria andProjectremarkIn(List<String> values) {
            addCriterion("projectRemark in", values, "projectremark");
            return (Criteria) this;
        }

        public Criteria andProjectremarkNotIn(List<String> values) {
            addCriterion("projectRemark not in", values, "projectremark");
            return (Criteria) this;
        }

        public Criteria andProjectremarkBetween(String value1, String value2) {
            addCriterion("projectRemark between", value1, value2, "projectremark");
            return (Criteria) this;
        }

        public Criteria andProjectremarkNotBetween(String value1, String value2) {
            addCriterion("projectRemark not between", value1, value2, "projectremark");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}