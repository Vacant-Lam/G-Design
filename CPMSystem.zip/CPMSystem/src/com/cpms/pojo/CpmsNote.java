package com.cpms.pojo;

import java.util.Date;

public class CpmsNote {
    private String noteid;

    private String projectid;

    private String noteeditorid;

    private String noteapproversid;

    private String notescale;

    private Date notecheckdate;

    private Integer noteprogress;

    private String noterummager;

    private Date notedate;

    private String noteattachment;

    private String attachmenttype;

    private String notecondition;

    private String notecheck;

    private String notemeasure;

    private String notereview;

    private Integer safetystatus;

    private Date approvedate;

    private String safetycomment;

    public String getNoteid() {
        return noteid;
    }

    public void setNoteid(String noteid) {
        this.noteid = noteid == null ? null : noteid.trim();
    }

    public String getProjectid() {
        return projectid;
    }

    public void setProjectid(String projectid) {
        this.projectid = projectid == null ? null : projectid.trim();
    }

    public String getNoteeditorid() {
        return noteeditorid;
    }

    public void setNoteeditorid(String noteeditorid) {
        this.noteeditorid = noteeditorid == null ? null : noteeditorid.trim();
    }

    public String getNoteapproversid() {
        return noteapproversid;
    }

    public void setNoteapproversid(String noteapproversid) {
        this.noteapproversid = noteapproversid == null ? null : noteapproversid.trim();
    }

    public String getNotescale() {
        return notescale;
    }

    public void setNotescale(String notescale) {
        this.notescale = notescale == null ? null : notescale.trim();
    }

    public Date getNotecheckdate() {
        return notecheckdate;
    }

    public void setNotecheckdate(Date notecheckdate) {
        this.notecheckdate = notecheckdate;
    }

    public Integer getNoteprogress() {
        return noteprogress;
    }

    public void setNoteprogress(Integer noteprogress) {
        this.noteprogress = noteprogress;
    }

    public String getNoterummager() {
        return noterummager;
    }

    public void setNoterummager(String noterummager) {
        this.noterummager = noterummager == null ? null : noterummager.trim();
    }

    public Date getNotedate() {
        return notedate;
    }

    public void setNotedate(Date notedate) {
        this.notedate = notedate;
    }

    public String getNoteattachment() {
        return noteattachment;
    }

    public void setNoteattachment(String noteattachment) {
        this.noteattachment = noteattachment == null ? null : noteattachment.trim();
    }

    public String getAttachmenttype() {
        return attachmenttype;
    }

    public void setAttachmenttype(String attachmenttype) {
        this.attachmenttype = attachmenttype == null ? null : attachmenttype.trim();
    }

    public String getNotecondition() {
        return notecondition;
    }

    public void setNotecondition(String notecondition) {
        this.notecondition = notecondition == null ? null : notecondition.trim();
    }

    public String getNotecheck() {
        return notecheck;
    }

    public void setNotecheck(String notecheck) {
        this.notecheck = notecheck == null ? null : notecheck.trim();
    }

    public String getNotemeasure() {
        return notemeasure;
    }

    public void setNotemeasure(String notemeasure) {
        this.notemeasure = notemeasure == null ? null : notemeasure.trim();
    }

    public String getNotereview() {
        return notereview;
    }

    public void setNotereview(String notereview) {
        this.notereview = notereview == null ? null : notereview.trim();
    }

    public Integer getSafetystatus() {
        return safetystatus;
    }

    public void setSafetystatus(Integer safetystatus) {
        this.safetystatus = safetystatus;
    }

    public Date getApprovedate() {
        return approvedate;
    }

    public void setApprovedate(Date approvedate) {
        this.approvedate = approvedate;
    }

    public String getSafetycomment() {
        return safetycomment;
    }

    public void setSafetycomment(String safetycomment) {
        this.safetycomment = safetycomment == null ? null : safetycomment.trim();
    }
}