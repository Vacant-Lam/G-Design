package com.cpms.pojo;

public class CpmsUser {
    private String userid;

    private String username;

    private Integer userdeptid;

    private String usersex;

    private String userposition;

    private String usersuperior;

    private String usertel;

    private String useremail;

    private Integer usertype;

    private String userpassword;
    
    private CpmsDept dept;

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid == null ? null : userid.trim();
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username == null ? null : username.trim();
    }

    public Integer getUserdeptid() {
        return userdeptid;
    }

    public void setUserdeptid(Integer userdeptid) {
        this.userdeptid = userdeptid;
    }

    public String getUsersex() {
        return usersex;
    }

    public void setUsersex(String usersex) {
        this.usersex = usersex;
    }

    public String getUserposition() {
        return userposition;
    }

    public void setUserposition(String userposition) {
        this.userposition = userposition == null ? null : userposition.trim();
    }

    public String getUsersuperior() {
        return usersuperior;
    }

    public void setUsersuperior(String usersuperior) {
        this.usersuperior = usersuperior == null ? null : usersuperior.trim();
    }

    public String getUsertel() {
        return usertel;
    }

    public void setUsertel(String usertel) {
        this.usertel = usertel == null ? null : usertel.trim();
    }

    public String getUseremail() {
        return useremail;
    }

    public void setUseremail(String useremail) {
        this.useremail = useremail == null ? null : useremail.trim();
    }

    public Integer getUsertype() {
        return usertype;
    }

    public void setUsertype(Integer usertype) {
        this.usertype = usertype;
    }

    public String getUserpassword() {
        return userpassword;
    }

    public void setUserpassword(String userpassword) {
        this.userpassword = userpassword == null ? null : userpassword.trim();
    }

	public CpmsDept getDept() {
		return dept;
	}

	public void setDept(CpmsDept dept) {
		this.dept = dept;
	}
    
    
}