package com.cpms.pojo;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class CpmsRectificationExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public CpmsRectificationExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<java.sql.Date>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andRectificationidIsNull() {
            addCriterion("rectificationId is null");
            return (Criteria) this;
        }

        public Criteria andRectificationidIsNotNull() {
            addCriterion("rectificationId is not null");
            return (Criteria) this;
        }

        public Criteria andRectificationidEqualTo(String value) {
            addCriterion("rectificationId =", value, "rectificationid");
            return (Criteria) this;
        }

        public Criteria andRectificationidNotEqualTo(String value) {
            addCriterion("rectificationId <>", value, "rectificationid");
            return (Criteria) this;
        }

        public Criteria andRectificationidGreaterThan(String value) {
            addCriterion("rectificationId >", value, "rectificationid");
            return (Criteria) this;
        }

        public Criteria andRectificationidGreaterThanOrEqualTo(String value) {
            addCriterion("rectificationId >=", value, "rectificationid");
            return (Criteria) this;
        }

        public Criteria andRectificationidLessThan(String value) {
            addCriterion("rectificationId <", value, "rectificationid");
            return (Criteria) this;
        }

        public Criteria andRectificationidLessThanOrEqualTo(String value) {
            addCriterion("rectificationId <=", value, "rectificationid");
            return (Criteria) this;
        }

        public Criteria andRectificationidLike(String value) {
            addCriterion("rectificationId like", value, "rectificationid");
            return (Criteria) this;
        }

        public Criteria andRectificationidNotLike(String value) {
            addCriterion("rectificationId not like", value, "rectificationid");
            return (Criteria) this;
        }

        public Criteria andRectificationidIn(List<String> values) {
            addCriterion("rectificationId in", values, "rectificationid");
            return (Criteria) this;
        }

        public Criteria andRectificationidNotIn(List<String> values) {
            addCriterion("rectificationId not in", values, "rectificationid");
            return (Criteria) this;
        }

        public Criteria andRectificationidBetween(String value1, String value2) {
            addCriterion("rectificationId between", value1, value2, "rectificationid");
            return (Criteria) this;
        }

        public Criteria andRectificationidNotBetween(String value1, String value2) {
            addCriterion("rectificationId not between", value1, value2, "rectificationid");
            return (Criteria) this;
        }

        public Criteria andProjectidIsNull() {
            addCriterion("projectId is null");
            return (Criteria) this;
        }

        public Criteria andProjectidIsNotNull() {
            addCriterion("projectId is not null");
            return (Criteria) this;
        }

        public Criteria andProjectidEqualTo(String value) {
            addCriterion("projectId =", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidNotEqualTo(String value) {
            addCriterion("projectId <>", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidGreaterThan(String value) {
            addCriterion("projectId >", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidGreaterThanOrEqualTo(String value) {
            addCriterion("projectId >=", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidLessThan(String value) {
            addCriterion("projectId <", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidLessThanOrEqualTo(String value) {
            addCriterion("projectId <=", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidLike(String value) {
            addCriterion("projectId like", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidNotLike(String value) {
            addCriterion("projectId not like", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidIn(List<String> values) {
            addCriterion("projectId in", values, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidNotIn(List<String> values) {
            addCriterion("projectId not in", values, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidBetween(String value1, String value2) {
            addCriterion("projectId between", value1, value2, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidNotBetween(String value1, String value2) {
            addCriterion("projectId not between", value1, value2, "projectid");
            return (Criteria) this;
        }

        public Criteria andRtfcteditoridIsNull() {
            addCriterion("rtfctEditorId is null");
            return (Criteria) this;
        }

        public Criteria andRtfcteditoridIsNotNull() {
            addCriterion("rtfctEditorId is not null");
            return (Criteria) this;
        }

        public Criteria andRtfcteditoridEqualTo(String value) {
            addCriterion("rtfctEditorId =", value, "rtfcteditorid");
            return (Criteria) this;
        }

        public Criteria andRtfcteditoridNotEqualTo(String value) {
            addCriterion("rtfctEditorId <>", value, "rtfcteditorid");
            return (Criteria) this;
        }

        public Criteria andRtfcteditoridGreaterThan(String value) {
            addCriterion("rtfctEditorId >", value, "rtfcteditorid");
            return (Criteria) this;
        }

        public Criteria andRtfcteditoridGreaterThanOrEqualTo(String value) {
            addCriterion("rtfctEditorId >=", value, "rtfcteditorid");
            return (Criteria) this;
        }

        public Criteria andRtfcteditoridLessThan(String value) {
            addCriterion("rtfctEditorId <", value, "rtfcteditorid");
            return (Criteria) this;
        }

        public Criteria andRtfcteditoridLessThanOrEqualTo(String value) {
            addCriterion("rtfctEditorId <=", value, "rtfcteditorid");
            return (Criteria) this;
        }

        public Criteria andRtfcteditoridLike(String value) {
            addCriterion("rtfctEditorId like", value, "rtfcteditorid");
            return (Criteria) this;
        }

        public Criteria andRtfcteditoridNotLike(String value) {
            addCriterion("rtfctEditorId not like", value, "rtfcteditorid");
            return (Criteria) this;
        }

        public Criteria andRtfcteditoridIn(List<String> values) {
            addCriterion("rtfctEditorId in", values, "rtfcteditorid");
            return (Criteria) this;
        }

        public Criteria andRtfcteditoridNotIn(List<String> values) {
            addCriterion("rtfctEditorId not in", values, "rtfcteditorid");
            return (Criteria) this;
        }

        public Criteria andRtfcteditoridBetween(String value1, String value2) {
            addCriterion("rtfctEditorId between", value1, value2, "rtfcteditorid");
            return (Criteria) this;
        }

        public Criteria andRtfcteditoridNotBetween(String value1, String value2) {
            addCriterion("rtfctEditorId not between", value1, value2, "rtfcteditorid");
            return (Criteria) this;
        }

        public Criteria andRtfcttrackerIsNull() {
            addCriterion("rtfctTracker is null");
            return (Criteria) this;
        }

        public Criteria andRtfcttrackerIsNotNull() {
            addCriterion("rtfctTracker is not null");
            return (Criteria) this;
        }

        public Criteria andRtfcttrackerEqualTo(String value) {
            addCriterion("rtfctTracker =", value, "rtfcttracker");
            return (Criteria) this;
        }

        public Criteria andRtfcttrackerNotEqualTo(String value) {
            addCriterion("rtfctTracker <>", value, "rtfcttracker");
            return (Criteria) this;
        }

        public Criteria andRtfcttrackerGreaterThan(String value) {
            addCriterion("rtfctTracker >", value, "rtfcttracker");
            return (Criteria) this;
        }

        public Criteria andRtfcttrackerGreaterThanOrEqualTo(String value) {
            addCriterion("rtfctTracker >=", value, "rtfcttracker");
            return (Criteria) this;
        }

        public Criteria andRtfcttrackerLessThan(String value) {
            addCriterion("rtfctTracker <", value, "rtfcttracker");
            return (Criteria) this;
        }

        public Criteria andRtfcttrackerLessThanOrEqualTo(String value) {
            addCriterion("rtfctTracker <=", value, "rtfcttracker");
            return (Criteria) this;
        }

        public Criteria andRtfcttrackerLike(String value) {
            addCriterion("rtfctTracker like", value, "rtfcttracker");
            return (Criteria) this;
        }

        public Criteria andRtfcttrackerNotLike(String value) {
            addCriterion("rtfctTracker not like", value, "rtfcttracker");
            return (Criteria) this;
        }

        public Criteria andRtfcttrackerIn(List<String> values) {
            addCriterion("rtfctTracker in", values, "rtfcttracker");
            return (Criteria) this;
        }

        public Criteria andRtfcttrackerNotIn(List<String> values) {
            addCriterion("rtfctTracker not in", values, "rtfcttracker");
            return (Criteria) this;
        }

        public Criteria andRtfcttrackerBetween(String value1, String value2) {
            addCriterion("rtfctTracker between", value1, value2, "rtfcttracker");
            return (Criteria) this;
        }

        public Criteria andRtfcttrackerNotBetween(String value1, String value2) {
            addCriterion("rtfctTracker not between", value1, value2, "rtfcttracker");
            return (Criteria) this;
        }

        public Criteria andRtfctapproversidIsNull() {
            addCriterion("rtfctApproversId is null");
            return (Criteria) this;
        }

        public Criteria andRtfctapproversidIsNotNull() {
            addCriterion("rtfctApproversId is not null");
            return (Criteria) this;
        }

        public Criteria andRtfctapproversidEqualTo(String value) {
            addCriterion("rtfctApproversId =", value, "rtfctapproversid");
            return (Criteria) this;
        }

        public Criteria andRtfctapproversidNotEqualTo(String value) {
            addCriterion("rtfctApproversId <>", value, "rtfctapproversid");
            return (Criteria) this;
        }

        public Criteria andRtfctapproversidGreaterThan(String value) {
            addCriterion("rtfctApproversId >", value, "rtfctapproversid");
            return (Criteria) this;
        }

        public Criteria andRtfctapproversidGreaterThanOrEqualTo(String value) {
            addCriterion("rtfctApproversId >=", value, "rtfctapproversid");
            return (Criteria) this;
        }

        public Criteria andRtfctapproversidLessThan(String value) {
            addCriterion("rtfctApproversId <", value, "rtfctapproversid");
            return (Criteria) this;
        }

        public Criteria andRtfctapproversidLessThanOrEqualTo(String value) {
            addCriterion("rtfctApproversId <=", value, "rtfctapproversid");
            return (Criteria) this;
        }

        public Criteria andRtfctapproversidLike(String value) {
            addCriterion("rtfctApproversId like", value, "rtfctapproversid");
            return (Criteria) this;
        }

        public Criteria andRtfctapproversidNotLike(String value) {
            addCriterion("rtfctApproversId not like", value, "rtfctapproversid");
            return (Criteria) this;
        }

        public Criteria andRtfctapproversidIn(List<String> values) {
            addCriterion("rtfctApproversId in", values, "rtfctapproversid");
            return (Criteria) this;
        }

        public Criteria andRtfctapproversidNotIn(List<String> values) {
            addCriterion("rtfctApproversId not in", values, "rtfctapproversid");
            return (Criteria) this;
        }

        public Criteria andRtfctapproversidBetween(String value1, String value2) {
            addCriterion("rtfctApproversId between", value1, value2, "rtfctapproversid");
            return (Criteria) this;
        }

        public Criteria andRtfctapproversidNotBetween(String value1, String value2) {
            addCriterion("rtfctApproversId not between", value1, value2, "rtfctapproversid");
            return (Criteria) this;
        }

        public Criteria andRectificationpartIsNull() {
            addCriterion("rectificationPart is null");
            return (Criteria) this;
        }

        public Criteria andRectificationpartIsNotNull() {
            addCriterion("rectificationPart is not null");
            return (Criteria) this;
        }

        public Criteria andRectificationpartEqualTo(String value) {
            addCriterion("rectificationPart =", value, "rectificationpart");
            return (Criteria) this;
        }

        public Criteria andRectificationpartNotEqualTo(String value) {
            addCriterion("rectificationPart <>", value, "rectificationpart");
            return (Criteria) this;
        }

        public Criteria andRectificationpartGreaterThan(String value) {
            addCriterion("rectificationPart >", value, "rectificationpart");
            return (Criteria) this;
        }

        public Criteria andRectificationpartGreaterThanOrEqualTo(String value) {
            addCriterion("rectificationPart >=", value, "rectificationpart");
            return (Criteria) this;
        }

        public Criteria andRectificationpartLessThan(String value) {
            addCriterion("rectificationPart <", value, "rectificationpart");
            return (Criteria) this;
        }

        public Criteria andRectificationpartLessThanOrEqualTo(String value) {
            addCriterion("rectificationPart <=", value, "rectificationpart");
            return (Criteria) this;
        }

        public Criteria andRectificationpartLike(String value) {
            addCriterion("rectificationPart like", value, "rectificationpart");
            return (Criteria) this;
        }

        public Criteria andRectificationpartNotLike(String value) {
            addCriterion("rectificationPart not like", value, "rectificationpart");
            return (Criteria) this;
        }

        public Criteria andRectificationpartIn(List<String> values) {
            addCriterion("rectificationPart in", values, "rectificationpart");
            return (Criteria) this;
        }

        public Criteria andRectificationpartNotIn(List<String> values) {
            addCriterion("rectificationPart not in", values, "rectificationpart");
            return (Criteria) this;
        }

        public Criteria andRectificationpartBetween(String value1, String value2) {
            addCriterion("rectificationPart between", value1, value2, "rectificationpart");
            return (Criteria) this;
        }

        public Criteria andRectificationpartNotBetween(String value1, String value2) {
            addCriterion("rectificationPart not between", value1, value2, "rectificationpart");
            return (Criteria) this;
        }

        public Criteria andRtfctproblemsIsNull() {
            addCriterion("rtfctProblems is null");
            return (Criteria) this;
        }

        public Criteria andRtfctproblemsIsNotNull() {
            addCriterion("rtfctProblems is not null");
            return (Criteria) this;
        }

        public Criteria andRtfctproblemsEqualTo(String value) {
            addCriterion("rtfctProblems =", value, "rtfctproblems");
            return (Criteria) this;
        }

        public Criteria andRtfctproblemsNotEqualTo(String value) {
            addCriterion("rtfctProblems <>", value, "rtfctproblems");
            return (Criteria) this;
        }

        public Criteria andRtfctproblemsGreaterThan(String value) {
            addCriterion("rtfctProblems >", value, "rtfctproblems");
            return (Criteria) this;
        }

        public Criteria andRtfctproblemsGreaterThanOrEqualTo(String value) {
            addCriterion("rtfctProblems >=", value, "rtfctproblems");
            return (Criteria) this;
        }

        public Criteria andRtfctproblemsLessThan(String value) {
            addCriterion("rtfctProblems <", value, "rtfctproblems");
            return (Criteria) this;
        }

        public Criteria andRtfctproblemsLessThanOrEqualTo(String value) {
            addCriterion("rtfctProblems <=", value, "rtfctproblems");
            return (Criteria) this;
        }

        public Criteria andRtfctproblemsLike(String value) {
            addCriterion("rtfctProblems like", value, "rtfctproblems");
            return (Criteria) this;
        }

        public Criteria andRtfctproblemsNotLike(String value) {
            addCriterion("rtfctProblems not like", value, "rtfctproblems");
            return (Criteria) this;
        }

        public Criteria andRtfctproblemsIn(List<String> values) {
            addCriterion("rtfctProblems in", values, "rtfctproblems");
            return (Criteria) this;
        }

        public Criteria andRtfctproblemsNotIn(List<String> values) {
            addCriterion("rtfctProblems not in", values, "rtfctproblems");
            return (Criteria) this;
        }

        public Criteria andRtfctproblemsBetween(String value1, String value2) {
            addCriterion("rtfctProblems between", value1, value2, "rtfctproblems");
            return (Criteria) this;
        }

        public Criteria andRtfctproblemsNotBetween(String value1, String value2) {
            addCriterion("rtfctProblems not between", value1, value2, "rtfctproblems");
            return (Criteria) this;
        }

        public Criteria andRtfctcontentIsNull() {
            addCriterion("rtfctContent is null");
            return (Criteria) this;
        }

        public Criteria andRtfctcontentIsNotNull() {
            addCriterion("rtfctContent is not null");
            return (Criteria) this;
        }

        public Criteria andRtfctcontentEqualTo(String value) {
            addCriterion("rtfctContent =", value, "rtfctcontent");
            return (Criteria) this;
        }

        public Criteria andRtfctcontentNotEqualTo(String value) {
            addCriterion("rtfctContent <>", value, "rtfctcontent");
            return (Criteria) this;
        }

        public Criteria andRtfctcontentGreaterThan(String value) {
            addCriterion("rtfctContent >", value, "rtfctcontent");
            return (Criteria) this;
        }

        public Criteria andRtfctcontentGreaterThanOrEqualTo(String value) {
            addCriterion("rtfctContent >=", value, "rtfctcontent");
            return (Criteria) this;
        }

        public Criteria andRtfctcontentLessThan(String value) {
            addCriterion("rtfctContent <", value, "rtfctcontent");
            return (Criteria) this;
        }

        public Criteria andRtfctcontentLessThanOrEqualTo(String value) {
            addCriterion("rtfctContent <=", value, "rtfctcontent");
            return (Criteria) this;
        }

        public Criteria andRtfctcontentLike(String value) {
            addCriterion("rtfctContent like", value, "rtfctcontent");
            return (Criteria) this;
        }

        public Criteria andRtfctcontentNotLike(String value) {
            addCriterion("rtfctContent not like", value, "rtfctcontent");
            return (Criteria) this;
        }

        public Criteria andRtfctcontentIn(List<String> values) {
            addCriterion("rtfctContent in", values, "rtfctcontent");
            return (Criteria) this;
        }

        public Criteria andRtfctcontentNotIn(List<String> values) {
            addCriterion("rtfctContent not in", values, "rtfctcontent");
            return (Criteria) this;
        }

        public Criteria andRtfctcontentBetween(String value1, String value2) {
            addCriterion("rtfctContent between", value1, value2, "rtfctcontent");
            return (Criteria) this;
        }

        public Criteria andRtfctcontentNotBetween(String value1, String value2) {
            addCriterion("rtfctContent not between", value1, value2, "rtfctcontent");
            return (Criteria) this;
        }

        public Criteria andRectificationpicIsNull() {
            addCriterion("rectificationPic is null");
            return (Criteria) this;
        }

        public Criteria andRectificationpicIsNotNull() {
            addCriterion("rectificationPic is not null");
            return (Criteria) this;
        }

        public Criteria andRectificationpicEqualTo(String value) {
            addCriterion("rectificationPic =", value, "rectificationpic");
            return (Criteria) this;
        }

        public Criteria andRectificationpicNotEqualTo(String value) {
            addCriterion("rectificationPic <>", value, "rectificationpic");
            return (Criteria) this;
        }

        public Criteria andRectificationpicGreaterThan(String value) {
            addCriterion("rectificationPic >", value, "rectificationpic");
            return (Criteria) this;
        }

        public Criteria andRectificationpicGreaterThanOrEqualTo(String value) {
            addCriterion("rectificationPic >=", value, "rectificationpic");
            return (Criteria) this;
        }

        public Criteria andRectificationpicLessThan(String value) {
            addCriterion("rectificationPic <", value, "rectificationpic");
            return (Criteria) this;
        }

        public Criteria andRectificationpicLessThanOrEqualTo(String value) {
            addCriterion("rectificationPic <=", value, "rectificationpic");
            return (Criteria) this;
        }

        public Criteria andRectificationpicLike(String value) {
            addCriterion("rectificationPic like", value, "rectificationpic");
            return (Criteria) this;
        }

        public Criteria andRectificationpicNotLike(String value) {
            addCriterion("rectificationPic not like", value, "rectificationpic");
            return (Criteria) this;
        }

        public Criteria andRectificationpicIn(List<String> values) {
            addCriterion("rectificationPic in", values, "rectificationpic");
            return (Criteria) this;
        }

        public Criteria andRectificationpicNotIn(List<String> values) {
            addCriterion("rectificationPic not in", values, "rectificationpic");
            return (Criteria) this;
        }

        public Criteria andRectificationpicBetween(String value1, String value2) {
            addCriterion("rectificationPic between", value1, value2, "rectificationpic");
            return (Criteria) this;
        }

        public Criteria andRectificationpicNotBetween(String value1, String value2) {
            addCriterion("rectificationPic not between", value1, value2, "rectificationpic");
            return (Criteria) this;
        }

        public Criteria andPictypeIsNull() {
            addCriterion("PicType is null");
            return (Criteria) this;
        }

        public Criteria andPictypeIsNotNull() {
            addCriterion("PicType is not null");
            return (Criteria) this;
        }

        public Criteria andPictypeEqualTo(String value) {
            addCriterion("PicType =", value, "pictype");
            return (Criteria) this;
        }

        public Criteria andPictypeNotEqualTo(String value) {
            addCriterion("PicType <>", value, "pictype");
            return (Criteria) this;
        }

        public Criteria andPictypeGreaterThan(String value) {
            addCriterion("PicType >", value, "pictype");
            return (Criteria) this;
        }

        public Criteria andPictypeGreaterThanOrEqualTo(String value) {
            addCriterion("PicType >=", value, "pictype");
            return (Criteria) this;
        }

        public Criteria andPictypeLessThan(String value) {
            addCriterion("PicType <", value, "pictype");
            return (Criteria) this;
        }

        public Criteria andPictypeLessThanOrEqualTo(String value) {
            addCriterion("PicType <=", value, "pictype");
            return (Criteria) this;
        }

        public Criteria andPictypeLike(String value) {
            addCriterion("PicType like", value, "pictype");
            return (Criteria) this;
        }

        public Criteria andPictypeNotLike(String value) {
            addCriterion("PicType not like", value, "pictype");
            return (Criteria) this;
        }

        public Criteria andPictypeIn(List<String> values) {
            addCriterion("PicType in", values, "pictype");
            return (Criteria) this;
        }

        public Criteria andPictypeNotIn(List<String> values) {
            addCriterion("PicType not in", values, "pictype");
            return (Criteria) this;
        }

        public Criteria andPictypeBetween(String value1, String value2) {
            addCriterion("PicType between", value1, value2, "pictype");
            return (Criteria) this;
        }

        public Criteria andPictypeNotBetween(String value1, String value2) {
            addCriterion("PicType not between", value1, value2, "pictype");
            return (Criteria) this;
        }

        public Criteria andRtfctattachmentIsNull() {
            addCriterion("rtfctAttachment is null");
            return (Criteria) this;
        }

        public Criteria andRtfctattachmentIsNotNull() {
            addCriterion("rtfctAttachment is not null");
            return (Criteria) this;
        }

        public Criteria andRtfctattachmentEqualTo(String value) {
            addCriterion("rtfctAttachment =", value, "rtfctattachment");
            return (Criteria) this;
        }

        public Criteria andRtfctattachmentNotEqualTo(String value) {
            addCriterion("rtfctAttachment <>", value, "rtfctattachment");
            return (Criteria) this;
        }

        public Criteria andRtfctattachmentGreaterThan(String value) {
            addCriterion("rtfctAttachment >", value, "rtfctattachment");
            return (Criteria) this;
        }

        public Criteria andRtfctattachmentGreaterThanOrEqualTo(String value) {
            addCriterion("rtfctAttachment >=", value, "rtfctattachment");
            return (Criteria) this;
        }

        public Criteria andRtfctattachmentLessThan(String value) {
            addCriterion("rtfctAttachment <", value, "rtfctattachment");
            return (Criteria) this;
        }

        public Criteria andRtfctattachmentLessThanOrEqualTo(String value) {
            addCriterion("rtfctAttachment <=", value, "rtfctattachment");
            return (Criteria) this;
        }

        public Criteria andRtfctattachmentLike(String value) {
            addCriterion("rtfctAttachment like", value, "rtfctattachment");
            return (Criteria) this;
        }

        public Criteria andRtfctattachmentNotLike(String value) {
            addCriterion("rtfctAttachment not like", value, "rtfctattachment");
            return (Criteria) this;
        }

        public Criteria andRtfctattachmentIn(List<String> values) {
            addCriterion("rtfctAttachment in", values, "rtfctattachment");
            return (Criteria) this;
        }

        public Criteria andRtfctattachmentNotIn(List<String> values) {
            addCriterion("rtfctAttachment not in", values, "rtfctattachment");
            return (Criteria) this;
        }

        public Criteria andRtfctattachmentBetween(String value1, String value2) {
            addCriterion("rtfctAttachment between", value1, value2, "rtfctattachment");
            return (Criteria) this;
        }

        public Criteria andRtfctattachmentNotBetween(String value1, String value2) {
            addCriterion("rtfctAttachment not between", value1, value2, "rtfctattachment");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeIsNull() {
            addCriterion("attachmentType is null");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeIsNotNull() {
            addCriterion("attachmentType is not null");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeEqualTo(String value) {
            addCriterion("attachmentType =", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeNotEqualTo(String value) {
            addCriterion("attachmentType <>", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeGreaterThan(String value) {
            addCriterion("attachmentType >", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeGreaterThanOrEqualTo(String value) {
            addCriterion("attachmentType >=", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeLessThan(String value) {
            addCriterion("attachmentType <", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeLessThanOrEqualTo(String value) {
            addCriterion("attachmentType <=", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeLike(String value) {
            addCriterion("attachmentType like", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeNotLike(String value) {
            addCriterion("attachmentType not like", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeIn(List<String> values) {
            addCriterion("attachmentType in", values, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeNotIn(List<String> values) {
            addCriterion("attachmentType not in", values, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeBetween(String value1, String value2) {
            addCriterion("attachmentType between", value1, value2, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeNotBetween(String value1, String value2) {
            addCriterion("attachmentType not between", value1, value2, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAssigndateIsNull() {
            addCriterion("assignDate is null");
            return (Criteria) this;
        }

        public Criteria andAssigndateIsNotNull() {
            addCriterion("assignDate is not null");
            return (Criteria) this;
        }

        public Criteria andAssigndateEqualTo(Date value) {
            addCriterionForJDBCDate("assignDate =", value, "assigndate");
            return (Criteria) this;
        }

        public Criteria andAssigndateNotEqualTo(Date value) {
            addCriterionForJDBCDate("assignDate <>", value, "assigndate");
            return (Criteria) this;
        }

        public Criteria andAssigndateGreaterThan(Date value) {
            addCriterionForJDBCDate("assignDate >", value, "assigndate");
            return (Criteria) this;
        }

        public Criteria andAssigndateGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("assignDate >=", value, "assigndate");
            return (Criteria) this;
        }

        public Criteria andAssigndateLessThan(Date value) {
            addCriterionForJDBCDate("assignDate <", value, "assigndate");
            return (Criteria) this;
        }

        public Criteria andAssigndateLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("assignDate <=", value, "assigndate");
            return (Criteria) this;
        }

        public Criteria andAssigndateIn(List<Date> values) {
            addCriterionForJDBCDate("assignDate in", values, "assigndate");
            return (Criteria) this;
        }

        public Criteria andAssigndateNotIn(List<Date> values) {
            addCriterionForJDBCDate("assignDate not in", values, "assigndate");
            return (Criteria) this;
        }

        public Criteria andAssigndateBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("assignDate between", value1, value2, "assigndate");
            return (Criteria) this;
        }

        public Criteria andAssigndateNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("assignDate not between", value1, value2, "assigndate");
            return (Criteria) this;
        }

        public Criteria andRectificationtimeIsNull() {
            addCriterion("rectificationTime is null");
            return (Criteria) this;
        }

        public Criteria andRectificationtimeIsNotNull() {
            addCriterion("rectificationTime is not null");
            return (Criteria) this;
        }

        public Criteria andRectificationtimeEqualTo(Date value) {
            addCriterionForJDBCDate("rectificationTime =", value, "rectificationtime");
            return (Criteria) this;
        }

        public Criteria andRectificationtimeNotEqualTo(Date value) {
            addCriterionForJDBCDate("rectificationTime <>", value, "rectificationtime");
            return (Criteria) this;
        }

        public Criteria andRectificationtimeGreaterThan(Date value) {
            addCriterionForJDBCDate("rectificationTime >", value, "rectificationtime");
            return (Criteria) this;
        }

        public Criteria andRectificationtimeGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("rectificationTime >=", value, "rectificationtime");
            return (Criteria) this;
        }

        public Criteria andRectificationtimeLessThan(Date value) {
            addCriterionForJDBCDate("rectificationTime <", value, "rectificationtime");
            return (Criteria) this;
        }

        public Criteria andRectificationtimeLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("rectificationTime <=", value, "rectificationtime");
            return (Criteria) this;
        }

        public Criteria andRectificationtimeIn(List<Date> values) {
            addCriterionForJDBCDate("rectificationTime in", values, "rectificationtime");
            return (Criteria) this;
        }

        public Criteria andRectificationtimeNotIn(List<Date> values) {
            addCriterionForJDBCDate("rectificationTime not in", values, "rectificationtime");
            return (Criteria) this;
        }

        public Criteria andRectificationtimeBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("rectificationTime between", value1, value2, "rectificationtime");
            return (Criteria) this;
        }

        public Criteria andRectificationtimeNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("rectificationTime not between", value1, value2, "rectificationtime");
            return (Criteria) this;
        }

        public Criteria andRectificationdateIsNull() {
            addCriterion("rectificationDate is null");
            return (Criteria) this;
        }

        public Criteria andRectificationdateIsNotNull() {
            addCriterion("rectificationDate is not null");
            return (Criteria) this;
        }

        public Criteria andRectificationdateEqualTo(Date value) {
            addCriterionForJDBCDate("rectificationDate =", value, "rectificationdate");
            return (Criteria) this;
        }

        public Criteria andRectificationdateNotEqualTo(Date value) {
            addCriterionForJDBCDate("rectificationDate <>", value, "rectificationdate");
            return (Criteria) this;
        }

        public Criteria andRectificationdateGreaterThan(Date value) {
            addCriterionForJDBCDate("rectificationDate >", value, "rectificationdate");
            return (Criteria) this;
        }

        public Criteria andRectificationdateGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("rectificationDate >=", value, "rectificationdate");
            return (Criteria) this;
        }

        public Criteria andRectificationdateLessThan(Date value) {
            addCriterionForJDBCDate("rectificationDate <", value, "rectificationdate");
            return (Criteria) this;
        }

        public Criteria andRectificationdateLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("rectificationDate <=", value, "rectificationdate");
            return (Criteria) this;
        }

        public Criteria andRectificationdateIn(List<Date> values) {
            addCriterionForJDBCDate("rectificationDate in", values, "rectificationdate");
            return (Criteria) this;
        }

        public Criteria andRectificationdateNotIn(List<Date> values) {
            addCriterionForJDBCDate("rectificationDate not in", values, "rectificationdate");
            return (Criteria) this;
        }

        public Criteria andRectificationdateBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("rectificationDate between", value1, value2, "rectificationdate");
            return (Criteria) this;
        }

        public Criteria andRectificationdateNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("rectificationDate not between", value1, value2, "rectificationdate");
            return (Criteria) this;
        }

        public Criteria andRtfctfeedbackIsNull() {
            addCriterion("rtfctFeedback is null");
            return (Criteria) this;
        }

        public Criteria andRtfctfeedbackIsNotNull() {
            addCriterion("rtfctFeedback is not null");
            return (Criteria) this;
        }

        public Criteria andRtfctfeedbackEqualTo(String value) {
            addCriterion("rtfctFeedback =", value, "rtfctfeedback");
            return (Criteria) this;
        }

        public Criteria andRtfctfeedbackNotEqualTo(String value) {
            addCriterion("rtfctFeedback <>", value, "rtfctfeedback");
            return (Criteria) this;
        }

        public Criteria andRtfctfeedbackGreaterThan(String value) {
            addCriterion("rtfctFeedback >", value, "rtfctfeedback");
            return (Criteria) this;
        }

        public Criteria andRtfctfeedbackGreaterThanOrEqualTo(String value) {
            addCriterion("rtfctFeedback >=", value, "rtfctfeedback");
            return (Criteria) this;
        }

        public Criteria andRtfctfeedbackLessThan(String value) {
            addCriterion("rtfctFeedback <", value, "rtfctfeedback");
            return (Criteria) this;
        }

        public Criteria andRtfctfeedbackLessThanOrEqualTo(String value) {
            addCriterion("rtfctFeedback <=", value, "rtfctfeedback");
            return (Criteria) this;
        }

        public Criteria andRtfctfeedbackLike(String value) {
            addCriterion("rtfctFeedback like", value, "rtfctfeedback");
            return (Criteria) this;
        }

        public Criteria andRtfctfeedbackNotLike(String value) {
            addCriterion("rtfctFeedback not like", value, "rtfctfeedback");
            return (Criteria) this;
        }

        public Criteria andRtfctfeedbackIn(List<String> values) {
            addCriterion("rtfctFeedback in", values, "rtfctfeedback");
            return (Criteria) this;
        }

        public Criteria andRtfctfeedbackNotIn(List<String> values) {
            addCriterion("rtfctFeedback not in", values, "rtfctfeedback");
            return (Criteria) this;
        }

        public Criteria andRtfctfeedbackBetween(String value1, String value2) {
            addCriterion("rtfctFeedback between", value1, value2, "rtfctfeedback");
            return (Criteria) this;
        }

        public Criteria andRtfctfeedbackNotBetween(String value1, String value2) {
            addCriterion("rtfctFeedback not between", value1, value2, "rtfctfeedback");
            return (Criteria) this;
        }

        public Criteria andRtfctstatusIsNull() {
            addCriterion("rtfctStatus is null");
            return (Criteria) this;
        }

        public Criteria andRtfctstatusIsNotNull() {
            addCriterion("rtfctStatus is not null");
            return (Criteria) this;
        }

        public Criteria andRtfctstatusEqualTo(Integer value) {
            addCriterion("rtfctStatus =", value, "rtfctstatus");
            return (Criteria) this;
        }

        public Criteria andRtfctstatusNotEqualTo(Integer value) {
            addCriterion("rtfctStatus <>", value, "rtfctstatus");
            return (Criteria) this;
        }

        public Criteria andRtfctstatusGreaterThan(Integer value) {
            addCriterion("rtfctStatus >", value, "rtfctstatus");
            return (Criteria) this;
        }

        public Criteria andRtfctstatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("rtfctStatus >=", value, "rtfctstatus");
            return (Criteria) this;
        }

        public Criteria andRtfctstatusLessThan(Integer value) {
            addCriterion("rtfctStatus <", value, "rtfctstatus");
            return (Criteria) this;
        }

        public Criteria andRtfctstatusLessThanOrEqualTo(Integer value) {
            addCriterion("rtfctStatus <=", value, "rtfctstatus");
            return (Criteria) this;
        }

        public Criteria andRtfctstatusIn(List<Integer> values) {
            addCriterion("rtfctStatus in", values, "rtfctstatus");
            return (Criteria) this;
        }

        public Criteria andRtfctstatusNotIn(List<Integer> values) {
            addCriterion("rtfctStatus not in", values, "rtfctstatus");
            return (Criteria) this;
        }

        public Criteria andRtfctstatusBetween(Integer value1, Integer value2) {
            addCriterion("rtfctStatus between", value1, value2, "rtfctstatus");
            return (Criteria) this;
        }

        public Criteria andRtfctstatusNotBetween(Integer value1, Integer value2) {
            addCriterion("rtfctStatus not between", value1, value2, "rtfctstatus");
            return (Criteria) this;
        }

        public Criteria andApprovedateIsNull() {
            addCriterion("approveDate is null");
            return (Criteria) this;
        }

        public Criteria andApprovedateIsNotNull() {
            addCriterion("approveDate is not null");
            return (Criteria) this;
        }

        public Criteria andApprovedateEqualTo(Date value) {
            addCriterion("approveDate =", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateNotEqualTo(Date value) {
            addCriterion("approveDate <>", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateGreaterThan(Date value) {
            addCriterion("approveDate >", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateGreaterThanOrEqualTo(Date value) {
            addCriterion("approveDate >=", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateLessThan(Date value) {
            addCriterion("approveDate <", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateLessThanOrEqualTo(Date value) {
            addCriterion("approveDate <=", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateIn(List<Date> values) {
            addCriterion("approveDate in", values, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateNotIn(List<Date> values) {
            addCriterion("approveDate not in", values, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateBetween(Date value1, Date value2) {
            addCriterion("approveDate between", value1, value2, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateNotBetween(Date value1, Date value2) {
            addCriterion("approveDate not between", value1, value2, "approvedate");
            return (Criteria) this;
        }

        public Criteria andRtfctcommentIsNull() {
            addCriterion("rtfctComment is null");
            return (Criteria) this;
        }

        public Criteria andRtfctcommentIsNotNull() {
            addCriterion("rtfctComment is not null");
            return (Criteria) this;
        }

        public Criteria andRtfctcommentEqualTo(String value) {
            addCriterion("rtfctComment =", value, "rtfctcomment");
            return (Criteria) this;
        }

        public Criteria andRtfctcommentNotEqualTo(String value) {
            addCriterion("rtfctComment <>", value, "rtfctcomment");
            return (Criteria) this;
        }

        public Criteria andRtfctcommentGreaterThan(String value) {
            addCriterion("rtfctComment >", value, "rtfctcomment");
            return (Criteria) this;
        }

        public Criteria andRtfctcommentGreaterThanOrEqualTo(String value) {
            addCriterion("rtfctComment >=", value, "rtfctcomment");
            return (Criteria) this;
        }

        public Criteria andRtfctcommentLessThan(String value) {
            addCriterion("rtfctComment <", value, "rtfctcomment");
            return (Criteria) this;
        }

        public Criteria andRtfctcommentLessThanOrEqualTo(String value) {
            addCriterion("rtfctComment <=", value, "rtfctcomment");
            return (Criteria) this;
        }

        public Criteria andRtfctcommentLike(String value) {
            addCriterion("rtfctComment like", value, "rtfctcomment");
            return (Criteria) this;
        }

        public Criteria andRtfctcommentNotLike(String value) {
            addCriterion("rtfctComment not like", value, "rtfctcomment");
            return (Criteria) this;
        }

        public Criteria andRtfctcommentIn(List<String> values) {
            addCriterion("rtfctComment in", values, "rtfctcomment");
            return (Criteria) this;
        }

        public Criteria andRtfctcommentNotIn(List<String> values) {
            addCriterion("rtfctComment not in", values, "rtfctcomment");
            return (Criteria) this;
        }

        public Criteria andRtfctcommentBetween(String value1, String value2) {
            addCriterion("rtfctComment between", value1, value2, "rtfctcomment");
            return (Criteria) this;
        }

        public Criteria andRtfctcommentNotBetween(String value1, String value2) {
            addCriterion("rtfctComment not between", value1, value2, "rtfctcomment");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}