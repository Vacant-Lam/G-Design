package com.cpms.pojo;

import java.util.Date;

public class CpmsRectification {
    private String rectificationid;

    private String projectid;

    private String rtfcteditorid;

    private String rtfcttracker;

    private String rtfctapproversid;

    private String rectificationpart;

    private String rtfctproblems;

    private String rtfctcontent;

    private String rectificationpic;

    private String pictype;

    private String rtfctattachment;

    private String attachmenttype;

    private Date assigndate;

    private Date rectificationtime;

    private Date rectificationdate;

    private String rtfctfeedback;

    private Integer rtfctstatus;

    private Date approvedate;

    private String rtfctcomment;

    public String getRectificationid() {
        return rectificationid;
    }

    public void setRectificationid(String rectificationid) {
        this.rectificationid = rectificationid == null ? null : rectificationid.trim();
    }

    public String getProjectid() {
        return projectid;
    }

    public void setProjectid(String projectid) {
        this.projectid = projectid == null ? null : projectid.trim();
    }

    public String getRtfcteditorid() {
        return rtfcteditorid;
    }

    public void setRtfcteditorid(String rtfcteditorid) {
        this.rtfcteditorid = rtfcteditorid == null ? null : rtfcteditorid.trim();
    }

    public String getRtfcttracker() {
        return rtfcttracker;
    }

    public void setRtfcttracker(String rtfcttracker) {
        this.rtfcttracker = rtfcttracker == null ? null : rtfcttracker.trim();
    }

    public String getRtfctapproversid() {
        return rtfctapproversid;
    }

    public void setRtfctapproversid(String rtfctapproversid) {
        this.rtfctapproversid = rtfctapproversid == null ? null : rtfctapproversid.trim();
    }

    public String getRectificationpart() {
        return rectificationpart;
    }

    public void setRectificationpart(String rectificationpart) {
        this.rectificationpart = rectificationpart == null ? null : rectificationpart.trim();
    }

    public String getRtfctproblems() {
        return rtfctproblems;
    }

    public void setRtfctproblems(String rtfctproblems) {
        this.rtfctproblems = rtfctproblems == null ? null : rtfctproblems.trim();
    }

    public String getRtfctcontent() {
        return rtfctcontent;
    }

    public void setRtfctcontent(String rtfctcontent) {
        this.rtfctcontent = rtfctcontent == null ? null : rtfctcontent.trim();
    }

    public String getRectificationpic() {
        return rectificationpic;
    }

    public void setRectificationpic(String rectificationpic) {
        this.rectificationpic = rectificationpic == null ? null : rectificationpic.trim();
    }

    public String getPictype() {
        return pictype;
    }

    public void setPictype(String pictype) {
        this.pictype = pictype == null ? null : pictype.trim();
    }

    public String getRtfctattachment() {
        return rtfctattachment;
    }

    public void setRtfctattachment(String rtfctattachment) {
        this.rtfctattachment = rtfctattachment == null ? null : rtfctattachment.trim();
    }

    public String getAttachmenttype() {
        return attachmenttype;
    }

    public void setAttachmenttype(String attachmenttype) {
        this.attachmenttype = attachmenttype == null ? null : attachmenttype.trim();
    }

    public Date getAssigndate() {
        return assigndate;
    }

    public void setAssigndate(Date assigndate) {
        this.assigndate = assigndate;
    }

    public Date getRectificationtime() {
        return rectificationtime;
    }

    public void setRectificationtime(Date rectificationtime) {
        this.rectificationtime = rectificationtime;
    }

    public Date getRectificationdate() {
        return rectificationdate;
    }

    public void setRectificationdate(Date rectificationdate) {
        this.rectificationdate = rectificationdate;
    }

    public String getRtfctfeedback() {
        return rtfctfeedback;
    }

    public void setRtfctfeedback(String rtfctfeedback) {
        this.rtfctfeedback = rtfctfeedback == null ? null : rtfctfeedback.trim();
    }

    public Integer getRtfctstatus() {
        return rtfctstatus;
    }

    public void setRtfctstatus(Integer rtfctstatus) {
        this.rtfctstatus = rtfctstatus;
    }

    public Date getApprovedate() {
        return approvedate;
    }

    public void setApprovedate(Date approvedate) {
        this.approvedate = approvedate;
    }

    public String getRtfctcomment() {
        return rtfctcomment;
    }

    public void setRtfctcomment(String rtfctcomment) {
        this.rtfctcomment = rtfctcomment == null ? null : rtfctcomment.trim();
    }
}