package com.cpms.pojo;

//�û��������ű�����˾����ͼpojo
public class User_Dept_Com {

    private String userid;

    private String username;

    private Integer userdeptid;

    private String usersex;

    private String userposition;

    private String usersuperior;

    private String usertel;

    private String useremail;

    private Integer usertype;

    private String userpassword;
    

    private String deptname;

 
    private Integer companyid;

    private String companyname;
    
    
    private String typename;
    
    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid == null ? null : userid.trim();
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username == null ? null : username.trim();
    }

    public Integer getUserdeptid() {
        return userdeptid;
    }

    public void setUserdeptid(Integer userdeptid) {
        this.userdeptid = userdeptid;
    }

    public String getUsersex() {
        return usersex;
    }

    public void setUsersex(String usersex) {
        this.usersex = usersex;
    }

    public String getUserposition() {
        return userposition;
    }

    public void setUserposition(String userposition) {
        this.userposition = userposition == null ? null : userposition.trim();
    }

    public String getUsersuperior() {
        return usersuperior;
    }

    public void setUsersuperior(String usersuperior) {
        this.usersuperior = usersuperior == null ? null : usersuperior.trim();
    }

    public String getUsertel() {
        return usertel;
    }

    public void setUsertel(String usertel) {
        this.usertel = usertel == null ? null : usertel.trim();
    }

    public String getUseremail() {
        return useremail;
    }

    public void setUseremail(String useremail) {
        this.useremail = useremail == null ? null : useremail.trim();
    }

    public Integer getUsertype() {
        return usertype;
    }

    public void setUsertype(Integer usertype) {
        this.usertype = usertype;
    }

    public String getUserpassword() {
        return userpassword;
    }

    public void setUserpassword(String userpassword) {
        this.userpassword = userpassword == null ? null : userpassword.trim();
    }

    public String getDeptname() {
        return deptname;
    }

    public void setDeptname(String deptname) {
        this.deptname = deptname == null ? null : deptname.trim();
    }
    
    public Integer getCompanyid() {
        return companyid;
    }

    public void setCompanyid(Integer companyid) {
        this.companyid = companyid;
    }

    public String getCompanyname() {
        return companyname;
    }

    public void setCompanyname(String companyname) {
        this.companyname = companyname == null ? null : companyname.trim();
    }
    
    
    public String getTypename() {
        return typename;
    }

    public void setTypename(String typename) {
        this.typename = typename == null ? null : typename.trim();
    }

	@Override
	public String toString() {
		return "User_Dept_Com [userid=" + userid + ", username=" + username + ", userdeptid=" + userdeptid
				+ ", usersex=" + usersex + ", userposition=" + userposition + ", usersuperior=" + usersuperior
				+ ", usertel=" + usertel + ", useremail=" + useremail + ", usertype=" + usertype + ", userpassword="
				+ userpassword + ", deptname=" + deptname + ", companyid=" + companyid + ", companyname=" + companyname
				+ ", typename=" + typename + "]";
	}
      
}