package com.cpms.pojo;

import java.util.ArrayList;
import java.util.List;

public class CpmsScheduleDetailExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public CpmsScheduleDetailExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andSchddetailidIsNull() {
            addCriterion("schdDetailId is null");
            return (Criteria) this;
        }

        public Criteria andSchddetailidIsNotNull() {
            addCriterion("schdDetailId is not null");
            return (Criteria) this;
        }

        public Criteria andSchddetailidEqualTo(Integer value) {
            addCriterion("schdDetailId =", value, "schddetailid");
            return (Criteria) this;
        }

        public Criteria andSchddetailidNotEqualTo(Integer value) {
            addCriterion("schdDetailId <>", value, "schddetailid");
            return (Criteria) this;
        }

        public Criteria andSchddetailidGreaterThan(Integer value) {
            addCriterion("schdDetailId >", value, "schddetailid");
            return (Criteria) this;
        }

        public Criteria andSchddetailidGreaterThanOrEqualTo(Integer value) {
            addCriterion("schdDetailId >=", value, "schddetailid");
            return (Criteria) this;
        }

        public Criteria andSchddetailidLessThan(Integer value) {
            addCriterion("schdDetailId <", value, "schddetailid");
            return (Criteria) this;
        }

        public Criteria andSchddetailidLessThanOrEqualTo(Integer value) {
            addCriterion("schdDetailId <=", value, "schddetailid");
            return (Criteria) this;
        }

        public Criteria andSchddetailidIn(List<Integer> values) {
            addCriterion("schdDetailId in", values, "schddetailid");
            return (Criteria) this;
        }

        public Criteria andSchddetailidNotIn(List<Integer> values) {
            addCriterion("schdDetailId not in", values, "schddetailid");
            return (Criteria) this;
        }

        public Criteria andSchddetailidBetween(Integer value1, Integer value2) {
            addCriterion("schdDetailId between", value1, value2, "schddetailid");
            return (Criteria) this;
        }

        public Criteria andSchddetailidNotBetween(Integer value1, Integer value2) {
            addCriterion("schdDetailId not between", value1, value2, "schddetailid");
            return (Criteria) this;
        }

        public Criteria andProjectidIsNull() {
            addCriterion("projectId is null");
            return (Criteria) this;
        }

        public Criteria andProjectidIsNotNull() {
            addCriterion("projectId is not null");
            return (Criteria) this;
        }

        public Criteria andProjectidEqualTo(String value) {
            addCriterion("projectId =", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidNotEqualTo(String value) {
            addCriterion("projectId <>", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidGreaterThan(String value) {
            addCriterion("projectId >", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidGreaterThanOrEqualTo(String value) {
            addCriterion("projectId >=", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidLessThan(String value) {
            addCriterion("projectId <", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidLessThanOrEqualTo(String value) {
            addCriterion("projectId <=", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidLike(String value) {
            addCriterion("projectId like", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidNotLike(String value) {
            addCriterion("projectId not like", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidIn(List<String> values) {
            addCriterion("projectId in", values, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidNotIn(List<String> values) {
            addCriterion("projectId not in", values, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidBetween(String value1, String value2) {
            addCriterion("projectId between", value1, value2, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidNotBetween(String value1, String value2) {
            addCriterion("projectId not between", value1, value2, "projectid");
            return (Criteria) this;
        }

        public Criteria andSchddetailitemIsNull() {
            addCriterion("schdDetailItem is null");
            return (Criteria) this;
        }

        public Criteria andSchddetailitemIsNotNull() {
            addCriterion("schdDetailItem is not null");
            return (Criteria) this;
        }

        public Criteria andSchddetailitemEqualTo(String value) {
            addCriterion("schdDetailItem =", value, "schddetailitem");
            return (Criteria) this;
        }

        public Criteria andSchddetailitemNotEqualTo(String value) {
            addCriterion("schdDetailItem <>", value, "schddetailitem");
            return (Criteria) this;
        }

        public Criteria andSchddetailitemGreaterThan(String value) {
            addCriterion("schdDetailItem >", value, "schddetailitem");
            return (Criteria) this;
        }

        public Criteria andSchddetailitemGreaterThanOrEqualTo(String value) {
            addCriterion("schdDetailItem >=", value, "schddetailitem");
            return (Criteria) this;
        }

        public Criteria andSchddetailitemLessThan(String value) {
            addCriterion("schdDetailItem <", value, "schddetailitem");
            return (Criteria) this;
        }

        public Criteria andSchddetailitemLessThanOrEqualTo(String value) {
            addCriterion("schdDetailItem <=", value, "schddetailitem");
            return (Criteria) this;
        }

        public Criteria andSchddetailitemLike(String value) {
            addCriterion("schdDetailItem like", value, "schddetailitem");
            return (Criteria) this;
        }

        public Criteria andSchddetailitemNotLike(String value) {
            addCriterion("schdDetailItem not like", value, "schddetailitem");
            return (Criteria) this;
        }

        public Criteria andSchddetailitemIn(List<String> values) {
            addCriterion("schdDetailItem in", values, "schddetailitem");
            return (Criteria) this;
        }

        public Criteria andSchddetailitemNotIn(List<String> values) {
            addCriterion("schdDetailItem not in", values, "schddetailitem");
            return (Criteria) this;
        }

        public Criteria andSchddetailitemBetween(String value1, String value2) {
            addCriterion("schdDetailItem between", value1, value2, "schddetailitem");
            return (Criteria) this;
        }

        public Criteria andSchddetailitemNotBetween(String value1, String value2) {
            addCriterion("schdDetailItem not between", value1, value2, "schddetailitem");
            return (Criteria) this;
        }

        public Criteria andSchddetailunitIsNull() {
            addCriterion("schdDetailUnit is null");
            return (Criteria) this;
        }

        public Criteria andSchddetailunitIsNotNull() {
            addCriterion("schdDetailUnit is not null");
            return (Criteria) this;
        }

        public Criteria andSchddetailunitEqualTo(String value) {
            addCriterion("schdDetailUnit =", value, "schddetailunit");
            return (Criteria) this;
        }

        public Criteria andSchddetailunitNotEqualTo(String value) {
            addCriterion("schdDetailUnit <>", value, "schddetailunit");
            return (Criteria) this;
        }

        public Criteria andSchddetailunitGreaterThan(String value) {
            addCriterion("schdDetailUnit >", value, "schddetailunit");
            return (Criteria) this;
        }

        public Criteria andSchddetailunitGreaterThanOrEqualTo(String value) {
            addCriterion("schdDetailUnit >=", value, "schddetailunit");
            return (Criteria) this;
        }

        public Criteria andSchddetailunitLessThan(String value) {
            addCriterion("schdDetailUnit <", value, "schddetailunit");
            return (Criteria) this;
        }

        public Criteria andSchddetailunitLessThanOrEqualTo(String value) {
            addCriterion("schdDetailUnit <=", value, "schddetailunit");
            return (Criteria) this;
        }

        public Criteria andSchddetailunitLike(String value) {
            addCriterion("schdDetailUnit like", value, "schddetailunit");
            return (Criteria) this;
        }

        public Criteria andSchddetailunitNotLike(String value) {
            addCriterion("schdDetailUnit not like", value, "schddetailunit");
            return (Criteria) this;
        }

        public Criteria andSchddetailunitIn(List<String> values) {
            addCriterion("schdDetailUnit in", values, "schddetailunit");
            return (Criteria) this;
        }

        public Criteria andSchddetailunitNotIn(List<String> values) {
            addCriterion("schdDetailUnit not in", values, "schddetailunit");
            return (Criteria) this;
        }

        public Criteria andSchddetailunitBetween(String value1, String value2) {
            addCriterion("schdDetailUnit between", value1, value2, "schddetailunit");
            return (Criteria) this;
        }

        public Criteria andSchddetailunitNotBetween(String value1, String value2) {
            addCriterion("schdDetailUnit not between", value1, value2, "schddetailunit");
            return (Criteria) this;
        }

        public Criteria andSchddetailquantitiesIsNull() {
            addCriterion("schdDetailquantities is null");
            return (Criteria) this;
        }

        public Criteria andSchddetailquantitiesIsNotNull() {
            addCriterion("schdDetailquantities is not null");
            return (Criteria) this;
        }

        public Criteria andSchddetailquantitiesEqualTo(Integer value) {
            addCriterion("schdDetailquantities =", value, "schddetailquantities");
            return (Criteria) this;
        }

        public Criteria andSchddetailquantitiesNotEqualTo(Integer value) {
            addCriterion("schdDetailquantities <>", value, "schddetailquantities");
            return (Criteria) this;
        }

        public Criteria andSchddetailquantitiesGreaterThan(Integer value) {
            addCriterion("schdDetailquantities >", value, "schddetailquantities");
            return (Criteria) this;
        }

        public Criteria andSchddetailquantitiesGreaterThanOrEqualTo(Integer value) {
            addCriterion("schdDetailquantities >=", value, "schddetailquantities");
            return (Criteria) this;
        }

        public Criteria andSchddetailquantitiesLessThan(Integer value) {
            addCriterion("schdDetailquantities <", value, "schddetailquantities");
            return (Criteria) this;
        }

        public Criteria andSchddetailquantitiesLessThanOrEqualTo(Integer value) {
            addCriterion("schdDetailquantities <=", value, "schddetailquantities");
            return (Criteria) this;
        }

        public Criteria andSchddetailquantitiesIn(List<Integer> values) {
            addCriterion("schdDetailquantities in", values, "schddetailquantities");
            return (Criteria) this;
        }

        public Criteria andSchddetailquantitiesNotIn(List<Integer> values) {
            addCriterion("schdDetailquantities not in", values, "schddetailquantities");
            return (Criteria) this;
        }

        public Criteria andSchddetailquantitiesBetween(Integer value1, Integer value2) {
            addCriterion("schdDetailquantities between", value1, value2, "schddetailquantities");
            return (Criteria) this;
        }

        public Criteria andSchddetailquantitiesNotBetween(Integer value1, Integer value2) {
            addCriterion("schdDetailquantities not between", value1, value2, "schddetailquantities");
            return (Criteria) this;
        }

        public Criteria andSchddetailpriceIsNull() {
            addCriterion("schdDetailPrice is null");
            return (Criteria) this;
        }

        public Criteria andSchddetailpriceIsNotNull() {
            addCriterion("schdDetailPrice is not null");
            return (Criteria) this;
        }

        public Criteria andSchddetailpriceEqualTo(Double value) {
            addCriterion("schdDetailPrice =", value, "schddetailprice");
            return (Criteria) this;
        }

        public Criteria andSchddetailpriceNotEqualTo(Double value) {
            addCriterion("schdDetailPrice <>", value, "schddetailprice");
            return (Criteria) this;
        }

        public Criteria andSchddetailpriceGreaterThan(Double value) {
            addCriterion("schdDetailPrice >", value, "schddetailprice");
            return (Criteria) this;
        }

        public Criteria andSchddetailpriceGreaterThanOrEqualTo(Double value) {
            addCriterion("schdDetailPrice >=", value, "schddetailprice");
            return (Criteria) this;
        }

        public Criteria andSchddetailpriceLessThan(Double value) {
            addCriterion("schdDetailPrice <", value, "schddetailprice");
            return (Criteria) this;
        }

        public Criteria andSchddetailpriceLessThanOrEqualTo(Double value) {
            addCriterion("schdDetailPrice <=", value, "schddetailprice");
            return (Criteria) this;
        }

        public Criteria andSchddetailpriceIn(List<Double> values) {
            addCriterion("schdDetailPrice in", values, "schddetailprice");
            return (Criteria) this;
        }

        public Criteria andSchddetailpriceNotIn(List<Double> values) {
            addCriterion("schdDetailPrice not in", values, "schddetailprice");
            return (Criteria) this;
        }

        public Criteria andSchddetailpriceBetween(Double value1, Double value2) {
            addCriterion("schdDetailPrice between", value1, value2, "schddetailprice");
            return (Criteria) this;
        }

        public Criteria andSchddetailpriceNotBetween(Double value1, Double value2) {
            addCriterion("schdDetailPrice not between", value1, value2, "schddetailprice");
            return (Criteria) this;
        }

        public Criteria andSchddetaildoneIsNull() {
            addCriterion("schdDetailDone is null");
            return (Criteria) this;
        }

        public Criteria andSchddetaildoneIsNotNull() {
            addCriterion("schdDetailDone is not null");
            return (Criteria) this;
        }

        public Criteria andSchddetaildoneEqualTo(Integer value) {
            addCriterion("schdDetailDone =", value, "schddetaildone");
            return (Criteria) this;
        }

        public Criteria andSchddetaildoneNotEqualTo(Integer value) {
            addCriterion("schdDetailDone <>", value, "schddetaildone");
            return (Criteria) this;
        }

        public Criteria andSchddetaildoneGreaterThan(Integer value) {
            addCriterion("schdDetailDone >", value, "schddetaildone");
            return (Criteria) this;
        }

        public Criteria andSchddetaildoneGreaterThanOrEqualTo(Integer value) {
            addCriterion("schdDetailDone >=", value, "schddetaildone");
            return (Criteria) this;
        }

        public Criteria andSchddetaildoneLessThan(Integer value) {
            addCriterion("schdDetailDone <", value, "schddetaildone");
            return (Criteria) this;
        }

        public Criteria andSchddetaildoneLessThanOrEqualTo(Integer value) {
            addCriterion("schdDetailDone <=", value, "schddetaildone");
            return (Criteria) this;
        }

        public Criteria andSchddetaildoneIn(List<Integer> values) {
            addCriterion("schdDetailDone in", values, "schddetaildone");
            return (Criteria) this;
        }

        public Criteria andSchddetaildoneNotIn(List<Integer> values) {
            addCriterion("schdDetailDone not in", values, "schddetaildone");
            return (Criteria) this;
        }

        public Criteria andSchddetaildoneBetween(Integer value1, Integer value2) {
            addCriterion("schdDetailDone between", value1, value2, "schddetaildone");
            return (Criteria) this;
        }

        public Criteria andSchddetaildoneNotBetween(Integer value1, Integer value2) {
            addCriterion("schdDetailDone not between", value1, value2, "schddetaildone");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}