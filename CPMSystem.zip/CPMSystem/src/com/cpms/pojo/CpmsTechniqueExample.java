package com.cpms.pojo;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class CpmsTechniqueExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public CpmsTechniqueExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<java.sql.Date>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andTechniqueidIsNull() {
            addCriterion("techniqueId is null");
            return (Criteria) this;
        }

        public Criteria andTechniqueidIsNotNull() {
            addCriterion("techniqueId is not null");
            return (Criteria) this;
        }

        public Criteria andTechniqueidEqualTo(String value) {
            addCriterion("techniqueId =", value, "techniqueid");
            return (Criteria) this;
        }

        public Criteria andTechniqueidNotEqualTo(String value) {
            addCriterion("techniqueId <>", value, "techniqueid");
            return (Criteria) this;
        }

        public Criteria andTechniqueidGreaterThan(String value) {
            addCriterion("techniqueId >", value, "techniqueid");
            return (Criteria) this;
        }

        public Criteria andTechniqueidGreaterThanOrEqualTo(String value) {
            addCriterion("techniqueId >=", value, "techniqueid");
            return (Criteria) this;
        }

        public Criteria andTechniqueidLessThan(String value) {
            addCriterion("techniqueId <", value, "techniqueid");
            return (Criteria) this;
        }

        public Criteria andTechniqueidLessThanOrEqualTo(String value) {
            addCriterion("techniqueId <=", value, "techniqueid");
            return (Criteria) this;
        }

        public Criteria andTechniqueidLike(String value) {
            addCriterion("techniqueId like", value, "techniqueid");
            return (Criteria) this;
        }

        public Criteria andTechniqueidNotLike(String value) {
            addCriterion("techniqueId not like", value, "techniqueid");
            return (Criteria) this;
        }

        public Criteria andTechniqueidIn(List<String> values) {
            addCriterion("techniqueId in", values, "techniqueid");
            return (Criteria) this;
        }

        public Criteria andTechniqueidNotIn(List<String> values) {
            addCriterion("techniqueId not in", values, "techniqueid");
            return (Criteria) this;
        }

        public Criteria andTechniqueidBetween(String value1, String value2) {
            addCriterion("techniqueId between", value1, value2, "techniqueid");
            return (Criteria) this;
        }

        public Criteria andTechniqueidNotBetween(String value1, String value2) {
            addCriterion("techniqueId not between", value1, value2, "techniqueid");
            return (Criteria) this;
        }

        public Criteria andProjectidIsNull() {
            addCriterion("projectId is null");
            return (Criteria) this;
        }

        public Criteria andProjectidIsNotNull() {
            addCriterion("projectId is not null");
            return (Criteria) this;
        }

        public Criteria andProjectidEqualTo(String value) {
            addCriterion("projectId =", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidNotEqualTo(String value) {
            addCriterion("projectId <>", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidGreaterThan(String value) {
            addCriterion("projectId >", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidGreaterThanOrEqualTo(String value) {
            addCriterion("projectId >=", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidLessThan(String value) {
            addCriterion("projectId <", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidLessThanOrEqualTo(String value) {
            addCriterion("projectId <=", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidLike(String value) {
            addCriterion("projectId like", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidNotLike(String value) {
            addCriterion("projectId not like", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidIn(List<String> values) {
            addCriterion("projectId in", values, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidNotIn(List<String> values) {
            addCriterion("projectId not in", values, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidBetween(String value1, String value2) {
            addCriterion("projectId between", value1, value2, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidNotBetween(String value1, String value2) {
            addCriterion("projectId not between", value1, value2, "projectid");
            return (Criteria) this;
        }

        public Criteria andTechniqueeditoridIsNull() {
            addCriterion("techniqueEditorId is null");
            return (Criteria) this;
        }

        public Criteria andTechniqueeditoridIsNotNull() {
            addCriterion("techniqueEditorId is not null");
            return (Criteria) this;
        }

        public Criteria andTechniqueeditoridEqualTo(String value) {
            addCriterion("techniqueEditorId =", value, "techniqueeditorid");
            return (Criteria) this;
        }

        public Criteria andTechniqueeditoridNotEqualTo(String value) {
            addCriterion("techniqueEditorId <>", value, "techniqueeditorid");
            return (Criteria) this;
        }

        public Criteria andTechniqueeditoridGreaterThan(String value) {
            addCriterion("techniqueEditorId >", value, "techniqueeditorid");
            return (Criteria) this;
        }

        public Criteria andTechniqueeditoridGreaterThanOrEqualTo(String value) {
            addCriterion("techniqueEditorId >=", value, "techniqueeditorid");
            return (Criteria) this;
        }

        public Criteria andTechniqueeditoridLessThan(String value) {
            addCriterion("techniqueEditorId <", value, "techniqueeditorid");
            return (Criteria) this;
        }

        public Criteria andTechniqueeditoridLessThanOrEqualTo(String value) {
            addCriterion("techniqueEditorId <=", value, "techniqueeditorid");
            return (Criteria) this;
        }

        public Criteria andTechniqueeditoridLike(String value) {
            addCriterion("techniqueEditorId like", value, "techniqueeditorid");
            return (Criteria) this;
        }

        public Criteria andTechniqueeditoridNotLike(String value) {
            addCriterion("techniqueEditorId not like", value, "techniqueeditorid");
            return (Criteria) this;
        }

        public Criteria andTechniqueeditoridIn(List<String> values) {
            addCriterion("techniqueEditorId in", values, "techniqueeditorid");
            return (Criteria) this;
        }

        public Criteria andTechniqueeditoridNotIn(List<String> values) {
            addCriterion("techniqueEditorId not in", values, "techniqueeditorid");
            return (Criteria) this;
        }

        public Criteria andTechniqueeditoridBetween(String value1, String value2) {
            addCriterion("techniqueEditorId between", value1, value2, "techniqueeditorid");
            return (Criteria) this;
        }

        public Criteria andTechniqueeditoridNotBetween(String value1, String value2) {
            addCriterion("techniqueEditorId not between", value1, value2, "techniqueeditorid");
            return (Criteria) this;
        }

        public Criteria andTechniqueapproversidIsNull() {
            addCriterion("techniqueApproversId is null");
            return (Criteria) this;
        }

        public Criteria andTechniqueapproversidIsNotNull() {
            addCriterion("techniqueApproversId is not null");
            return (Criteria) this;
        }

        public Criteria andTechniqueapproversidEqualTo(String value) {
            addCriterion("techniqueApproversId =", value, "techniqueapproversid");
            return (Criteria) this;
        }

        public Criteria andTechniqueapproversidNotEqualTo(String value) {
            addCriterion("techniqueApproversId <>", value, "techniqueapproversid");
            return (Criteria) this;
        }

        public Criteria andTechniqueapproversidGreaterThan(String value) {
            addCriterion("techniqueApproversId >", value, "techniqueapproversid");
            return (Criteria) this;
        }

        public Criteria andTechniqueapproversidGreaterThanOrEqualTo(String value) {
            addCriterion("techniqueApproversId >=", value, "techniqueapproversid");
            return (Criteria) this;
        }

        public Criteria andTechniqueapproversidLessThan(String value) {
            addCriterion("techniqueApproversId <", value, "techniqueapproversid");
            return (Criteria) this;
        }

        public Criteria andTechniqueapproversidLessThanOrEqualTo(String value) {
            addCriterion("techniqueApproversId <=", value, "techniqueapproversid");
            return (Criteria) this;
        }

        public Criteria andTechniqueapproversidLike(String value) {
            addCriterion("techniqueApproversId like", value, "techniqueapproversid");
            return (Criteria) this;
        }

        public Criteria andTechniqueapproversidNotLike(String value) {
            addCriterion("techniqueApproversId not like", value, "techniqueapproversid");
            return (Criteria) this;
        }

        public Criteria andTechniqueapproversidIn(List<String> values) {
            addCriterion("techniqueApproversId in", values, "techniqueapproversid");
            return (Criteria) this;
        }

        public Criteria andTechniqueapproversidNotIn(List<String> values) {
            addCriterion("techniqueApproversId not in", values, "techniqueapproversid");
            return (Criteria) this;
        }

        public Criteria andTechniqueapproversidBetween(String value1, String value2) {
            addCriterion("techniqueApproversId between", value1, value2, "techniqueapproversid");
            return (Criteria) this;
        }

        public Criteria andTechniqueapproversidNotBetween(String value1, String value2) {
            addCriterion("techniqueApproversId not between", value1, value2, "techniqueapproversid");
            return (Criteria) this;
        }

        public Criteria andTechniquenameIsNull() {
            addCriterion("techniqueName is null");
            return (Criteria) this;
        }

        public Criteria andTechniquenameIsNotNull() {
            addCriterion("techniqueName is not null");
            return (Criteria) this;
        }

        public Criteria andTechniquenameEqualTo(String value) {
            addCriterion("techniqueName =", value, "techniquename");
            return (Criteria) this;
        }

        public Criteria andTechniquenameNotEqualTo(String value) {
            addCriterion("techniqueName <>", value, "techniquename");
            return (Criteria) this;
        }

        public Criteria andTechniquenameGreaterThan(String value) {
            addCriterion("techniqueName >", value, "techniquename");
            return (Criteria) this;
        }

        public Criteria andTechniquenameGreaterThanOrEqualTo(String value) {
            addCriterion("techniqueName >=", value, "techniquename");
            return (Criteria) this;
        }

        public Criteria andTechniquenameLessThan(String value) {
            addCriterion("techniqueName <", value, "techniquename");
            return (Criteria) this;
        }

        public Criteria andTechniquenameLessThanOrEqualTo(String value) {
            addCriterion("techniqueName <=", value, "techniquename");
            return (Criteria) this;
        }

        public Criteria andTechniquenameLike(String value) {
            addCriterion("techniqueName like", value, "techniquename");
            return (Criteria) this;
        }

        public Criteria andTechniquenameNotLike(String value) {
            addCriterion("techniqueName not like", value, "techniquename");
            return (Criteria) this;
        }

        public Criteria andTechniquenameIn(List<String> values) {
            addCriterion("techniqueName in", values, "techniquename");
            return (Criteria) this;
        }

        public Criteria andTechniquenameNotIn(List<String> values) {
            addCriterion("techniqueName not in", values, "techniquename");
            return (Criteria) this;
        }

        public Criteria andTechniquenameBetween(String value1, String value2) {
            addCriterion("techniqueName between", value1, value2, "techniquename");
            return (Criteria) this;
        }

        public Criteria andTechniquenameNotBetween(String value1, String value2) {
            addCriterion("techniqueName not between", value1, value2, "techniquename");
            return (Criteria) this;
        }

        public Criteria andTechniqueunitIsNull() {
            addCriterion("techniqueUnit is null");
            return (Criteria) this;
        }

        public Criteria andTechniqueunitIsNotNull() {
            addCriterion("techniqueUnit is not null");
            return (Criteria) this;
        }

        public Criteria andTechniqueunitEqualTo(String value) {
            addCriterion("techniqueUnit =", value, "techniqueunit");
            return (Criteria) this;
        }

        public Criteria andTechniqueunitNotEqualTo(String value) {
            addCriterion("techniqueUnit <>", value, "techniqueunit");
            return (Criteria) this;
        }

        public Criteria andTechniqueunitGreaterThan(String value) {
            addCriterion("techniqueUnit >", value, "techniqueunit");
            return (Criteria) this;
        }

        public Criteria andTechniqueunitGreaterThanOrEqualTo(String value) {
            addCriterion("techniqueUnit >=", value, "techniqueunit");
            return (Criteria) this;
        }

        public Criteria andTechniqueunitLessThan(String value) {
            addCriterion("techniqueUnit <", value, "techniqueunit");
            return (Criteria) this;
        }

        public Criteria andTechniqueunitLessThanOrEqualTo(String value) {
            addCriterion("techniqueUnit <=", value, "techniqueunit");
            return (Criteria) this;
        }

        public Criteria andTechniqueunitLike(String value) {
            addCriterion("techniqueUnit like", value, "techniqueunit");
            return (Criteria) this;
        }

        public Criteria andTechniqueunitNotLike(String value) {
            addCriterion("techniqueUnit not like", value, "techniqueunit");
            return (Criteria) this;
        }

        public Criteria andTechniqueunitIn(List<String> values) {
            addCriterion("techniqueUnit in", values, "techniqueunit");
            return (Criteria) this;
        }

        public Criteria andTechniqueunitNotIn(List<String> values) {
            addCriterion("techniqueUnit not in", values, "techniqueunit");
            return (Criteria) this;
        }

        public Criteria andTechniqueunitBetween(String value1, String value2) {
            addCriterion("techniqueUnit between", value1, value2, "techniqueunit");
            return (Criteria) this;
        }

        public Criteria andTechniqueunitNotBetween(String value1, String value2) {
            addCriterion("techniqueUnit not between", value1, value2, "techniqueunit");
            return (Criteria) this;
        }

        public Criteria andTechniquedateIsNull() {
            addCriterion("techniqueDate is null");
            return (Criteria) this;
        }

        public Criteria andTechniquedateIsNotNull() {
            addCriterion("techniqueDate is not null");
            return (Criteria) this;
        }

        public Criteria andTechniquedateEqualTo(Date value) {
            addCriterionForJDBCDate("techniqueDate =", value, "techniquedate");
            return (Criteria) this;
        }

        public Criteria andTechniquedateNotEqualTo(Date value) {
            addCriterionForJDBCDate("techniqueDate <>", value, "techniquedate");
            return (Criteria) this;
        }

        public Criteria andTechniquedateGreaterThan(Date value) {
            addCriterionForJDBCDate("techniqueDate >", value, "techniquedate");
            return (Criteria) this;
        }

        public Criteria andTechniquedateGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("techniqueDate >=", value, "techniquedate");
            return (Criteria) this;
        }

        public Criteria andTechniquedateLessThan(Date value) {
            addCriterionForJDBCDate("techniqueDate <", value, "techniquedate");
            return (Criteria) this;
        }

        public Criteria andTechniquedateLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("techniqueDate <=", value, "techniquedate");
            return (Criteria) this;
        }

        public Criteria andTechniquedateIn(List<Date> values) {
            addCriterionForJDBCDate("techniqueDate in", values, "techniquedate");
            return (Criteria) this;
        }

        public Criteria andTechniquedateNotIn(List<Date> values) {
            addCriterionForJDBCDate("techniqueDate not in", values, "techniquedate");
            return (Criteria) this;
        }

        public Criteria andTechniquedateBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("techniqueDate between", value1, value2, "techniquedate");
            return (Criteria) this;
        }

        public Criteria andTechniquedateNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("techniqueDate not between", value1, value2, "techniquedate");
            return (Criteria) this;
        }

        public Criteria andTechniqueplaceIsNull() {
            addCriterion("techniquePlace is null");
            return (Criteria) this;
        }

        public Criteria andTechniqueplaceIsNotNull() {
            addCriterion("techniquePlace is not null");
            return (Criteria) this;
        }

        public Criteria andTechniqueplaceEqualTo(String value) {
            addCriterion("techniquePlace =", value, "techniqueplace");
            return (Criteria) this;
        }

        public Criteria andTechniqueplaceNotEqualTo(String value) {
            addCriterion("techniquePlace <>", value, "techniqueplace");
            return (Criteria) this;
        }

        public Criteria andTechniqueplaceGreaterThan(String value) {
            addCriterion("techniquePlace >", value, "techniqueplace");
            return (Criteria) this;
        }

        public Criteria andTechniqueplaceGreaterThanOrEqualTo(String value) {
            addCriterion("techniquePlace >=", value, "techniqueplace");
            return (Criteria) this;
        }

        public Criteria andTechniqueplaceLessThan(String value) {
            addCriterion("techniquePlace <", value, "techniqueplace");
            return (Criteria) this;
        }

        public Criteria andTechniqueplaceLessThanOrEqualTo(String value) {
            addCriterion("techniquePlace <=", value, "techniqueplace");
            return (Criteria) this;
        }

        public Criteria andTechniqueplaceLike(String value) {
            addCriterion("techniquePlace like", value, "techniqueplace");
            return (Criteria) this;
        }

        public Criteria andTechniqueplaceNotLike(String value) {
            addCriterion("techniquePlace not like", value, "techniqueplace");
            return (Criteria) this;
        }

        public Criteria andTechniqueplaceIn(List<String> values) {
            addCriterion("techniquePlace in", values, "techniqueplace");
            return (Criteria) this;
        }

        public Criteria andTechniqueplaceNotIn(List<String> values) {
            addCriterion("techniquePlace not in", values, "techniqueplace");
            return (Criteria) this;
        }

        public Criteria andTechniqueplaceBetween(String value1, String value2) {
            addCriterion("techniquePlace between", value1, value2, "techniqueplace");
            return (Criteria) this;
        }

        public Criteria andTechniqueplaceNotBetween(String value1, String value2) {
            addCriterion("techniquePlace not between", value1, value2, "techniqueplace");
            return (Criteria) this;
        }

        public Criteria andTechniquecommitterIsNull() {
            addCriterion("techniqueCommitter is null");
            return (Criteria) this;
        }

        public Criteria andTechniquecommitterIsNotNull() {
            addCriterion("techniqueCommitter is not null");
            return (Criteria) this;
        }

        public Criteria andTechniquecommitterEqualTo(String value) {
            addCriterion("techniqueCommitter =", value, "techniquecommitter");
            return (Criteria) this;
        }

        public Criteria andTechniquecommitterNotEqualTo(String value) {
            addCriterion("techniqueCommitter <>", value, "techniquecommitter");
            return (Criteria) this;
        }

        public Criteria andTechniquecommitterGreaterThan(String value) {
            addCriterion("techniqueCommitter >", value, "techniquecommitter");
            return (Criteria) this;
        }

        public Criteria andTechniquecommitterGreaterThanOrEqualTo(String value) {
            addCriterion("techniqueCommitter >=", value, "techniquecommitter");
            return (Criteria) this;
        }

        public Criteria andTechniquecommitterLessThan(String value) {
            addCriterion("techniqueCommitter <", value, "techniquecommitter");
            return (Criteria) this;
        }

        public Criteria andTechniquecommitterLessThanOrEqualTo(String value) {
            addCriterion("techniqueCommitter <=", value, "techniquecommitter");
            return (Criteria) this;
        }

        public Criteria andTechniquecommitterLike(String value) {
            addCriterion("techniqueCommitter like", value, "techniquecommitter");
            return (Criteria) this;
        }

        public Criteria andTechniquecommitterNotLike(String value) {
            addCriterion("techniqueCommitter not like", value, "techniquecommitter");
            return (Criteria) this;
        }

        public Criteria andTechniquecommitterIn(List<String> values) {
            addCriterion("techniqueCommitter in", values, "techniquecommitter");
            return (Criteria) this;
        }

        public Criteria andTechniquecommitterNotIn(List<String> values) {
            addCriterion("techniqueCommitter not in", values, "techniquecommitter");
            return (Criteria) this;
        }

        public Criteria andTechniquecommitterBetween(String value1, String value2) {
            addCriterion("techniqueCommitter between", value1, value2, "techniquecommitter");
            return (Criteria) this;
        }

        public Criteria andTechniquecommitterNotBetween(String value1, String value2) {
            addCriterion("techniqueCommitter not between", value1, value2, "techniquecommitter");
            return (Criteria) this;
        }

        public Criteria andTechniquecommittedIsNull() {
            addCriterion("techniqueCommitted is null");
            return (Criteria) this;
        }

        public Criteria andTechniquecommittedIsNotNull() {
            addCriterion("techniqueCommitted is not null");
            return (Criteria) this;
        }

        public Criteria andTechniquecommittedEqualTo(String value) {
            addCriterion("techniqueCommitted =", value, "techniquecommitted");
            return (Criteria) this;
        }

        public Criteria andTechniquecommittedNotEqualTo(String value) {
            addCriterion("techniqueCommitted <>", value, "techniquecommitted");
            return (Criteria) this;
        }

        public Criteria andTechniquecommittedGreaterThan(String value) {
            addCriterion("techniqueCommitted >", value, "techniquecommitted");
            return (Criteria) this;
        }

        public Criteria andTechniquecommittedGreaterThanOrEqualTo(String value) {
            addCriterion("techniqueCommitted >=", value, "techniquecommitted");
            return (Criteria) this;
        }

        public Criteria andTechniquecommittedLessThan(String value) {
            addCriterion("techniqueCommitted <", value, "techniquecommitted");
            return (Criteria) this;
        }

        public Criteria andTechniquecommittedLessThanOrEqualTo(String value) {
            addCriterion("techniqueCommitted <=", value, "techniquecommitted");
            return (Criteria) this;
        }

        public Criteria andTechniquecommittedLike(String value) {
            addCriterion("techniqueCommitted like", value, "techniquecommitted");
            return (Criteria) this;
        }

        public Criteria andTechniquecommittedNotLike(String value) {
            addCriterion("techniqueCommitted not like", value, "techniquecommitted");
            return (Criteria) this;
        }

        public Criteria andTechniquecommittedIn(List<String> values) {
            addCriterion("techniqueCommitted in", values, "techniquecommitted");
            return (Criteria) this;
        }

        public Criteria andTechniquecommittedNotIn(List<String> values) {
            addCriterion("techniqueCommitted not in", values, "techniquecommitted");
            return (Criteria) this;
        }

        public Criteria andTechniquecommittedBetween(String value1, String value2) {
            addCriterion("techniqueCommitted between", value1, value2, "techniquecommitted");
            return (Criteria) this;
        }

        public Criteria andTechniquecommittedNotBetween(String value1, String value2) {
            addCriterion("techniqueCommitted not between", value1, value2, "techniquecommitted");
            return (Criteria) this;
        }

        public Criteria andTechniqueattachmentIsNull() {
            addCriterion("techniqueAttachment is null");
            return (Criteria) this;
        }

        public Criteria andTechniqueattachmentIsNotNull() {
            addCriterion("techniqueAttachment is not null");
            return (Criteria) this;
        }

        public Criteria andTechniqueattachmentEqualTo(String value) {
            addCriterion("techniqueAttachment =", value, "techniqueattachment");
            return (Criteria) this;
        }

        public Criteria andTechniqueattachmentNotEqualTo(String value) {
            addCriterion("techniqueAttachment <>", value, "techniqueattachment");
            return (Criteria) this;
        }

        public Criteria andTechniqueattachmentGreaterThan(String value) {
            addCriterion("techniqueAttachment >", value, "techniqueattachment");
            return (Criteria) this;
        }

        public Criteria andTechniqueattachmentGreaterThanOrEqualTo(String value) {
            addCriterion("techniqueAttachment >=", value, "techniqueattachment");
            return (Criteria) this;
        }

        public Criteria andTechniqueattachmentLessThan(String value) {
            addCriterion("techniqueAttachment <", value, "techniqueattachment");
            return (Criteria) this;
        }

        public Criteria andTechniqueattachmentLessThanOrEqualTo(String value) {
            addCriterion("techniqueAttachment <=", value, "techniqueattachment");
            return (Criteria) this;
        }

        public Criteria andTechniqueattachmentLike(String value) {
            addCriterion("techniqueAttachment like", value, "techniqueattachment");
            return (Criteria) this;
        }

        public Criteria andTechniqueattachmentNotLike(String value) {
            addCriterion("techniqueAttachment not like", value, "techniqueattachment");
            return (Criteria) this;
        }

        public Criteria andTechniqueattachmentIn(List<String> values) {
            addCriterion("techniqueAttachment in", values, "techniqueattachment");
            return (Criteria) this;
        }

        public Criteria andTechniqueattachmentNotIn(List<String> values) {
            addCriterion("techniqueAttachment not in", values, "techniqueattachment");
            return (Criteria) this;
        }

        public Criteria andTechniqueattachmentBetween(String value1, String value2) {
            addCriterion("techniqueAttachment between", value1, value2, "techniqueattachment");
            return (Criteria) this;
        }

        public Criteria andTechniqueattachmentNotBetween(String value1, String value2) {
            addCriterion("techniqueAttachment not between", value1, value2, "techniqueattachment");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeIsNull() {
            addCriterion("attachmentType is null");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeIsNotNull() {
            addCriterion("attachmentType is not null");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeEqualTo(String value) {
            addCriterion("attachmentType =", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeNotEqualTo(String value) {
            addCriterion("attachmentType <>", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeGreaterThan(String value) {
            addCriterion("attachmentType >", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeGreaterThanOrEqualTo(String value) {
            addCriterion("attachmentType >=", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeLessThan(String value) {
            addCriterion("attachmentType <", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeLessThanOrEqualTo(String value) {
            addCriterion("attachmentType <=", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeLike(String value) {
            addCriterion("attachmentType like", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeNotLike(String value) {
            addCriterion("attachmentType not like", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeIn(List<String> values) {
            addCriterion("attachmentType in", values, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeNotIn(List<String> values) {
            addCriterion("attachmentType not in", values, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeBetween(String value1, String value2) {
            addCriterion("attachmentType between", value1, value2, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeNotBetween(String value1, String value2) {
            addCriterion("attachmentType not between", value1, value2, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andTechniquecontentIsNull() {
            addCriterion("techniqueContent is null");
            return (Criteria) this;
        }

        public Criteria andTechniquecontentIsNotNull() {
            addCriterion("techniqueContent is not null");
            return (Criteria) this;
        }

        public Criteria andTechniquecontentEqualTo(String value) {
            addCriterion("techniqueContent =", value, "techniquecontent");
            return (Criteria) this;
        }

        public Criteria andTechniquecontentNotEqualTo(String value) {
            addCriterion("techniqueContent <>", value, "techniquecontent");
            return (Criteria) this;
        }

        public Criteria andTechniquecontentGreaterThan(String value) {
            addCriterion("techniqueContent >", value, "techniquecontent");
            return (Criteria) this;
        }

        public Criteria andTechniquecontentGreaterThanOrEqualTo(String value) {
            addCriterion("techniqueContent >=", value, "techniquecontent");
            return (Criteria) this;
        }

        public Criteria andTechniquecontentLessThan(String value) {
            addCriterion("techniqueContent <", value, "techniquecontent");
            return (Criteria) this;
        }

        public Criteria andTechniquecontentLessThanOrEqualTo(String value) {
            addCriterion("techniqueContent <=", value, "techniquecontent");
            return (Criteria) this;
        }

        public Criteria andTechniquecontentLike(String value) {
            addCriterion("techniqueContent like", value, "techniquecontent");
            return (Criteria) this;
        }

        public Criteria andTechniquecontentNotLike(String value) {
            addCriterion("techniqueContent not like", value, "techniquecontent");
            return (Criteria) this;
        }

        public Criteria andTechniquecontentIn(List<String> values) {
            addCriterion("techniqueContent in", values, "techniquecontent");
            return (Criteria) this;
        }

        public Criteria andTechniquecontentNotIn(List<String> values) {
            addCriterion("techniqueContent not in", values, "techniquecontent");
            return (Criteria) this;
        }

        public Criteria andTechniquecontentBetween(String value1, String value2) {
            addCriterion("techniqueContent between", value1, value2, "techniquecontent");
            return (Criteria) this;
        }

        public Criteria andTechniquecontentNotBetween(String value1, String value2) {
            addCriterion("techniqueContent not between", value1, value2, "techniquecontent");
            return (Criteria) this;
        }

        public Criteria andTechniqueremarkIsNull() {
            addCriterion("techniqueRemark is null");
            return (Criteria) this;
        }

        public Criteria andTechniqueremarkIsNotNull() {
            addCriterion("techniqueRemark is not null");
            return (Criteria) this;
        }

        public Criteria andTechniqueremarkEqualTo(String value) {
            addCriterion("techniqueRemark =", value, "techniqueremark");
            return (Criteria) this;
        }

        public Criteria andTechniqueremarkNotEqualTo(String value) {
            addCriterion("techniqueRemark <>", value, "techniqueremark");
            return (Criteria) this;
        }

        public Criteria andTechniqueremarkGreaterThan(String value) {
            addCriterion("techniqueRemark >", value, "techniqueremark");
            return (Criteria) this;
        }

        public Criteria andTechniqueremarkGreaterThanOrEqualTo(String value) {
            addCriterion("techniqueRemark >=", value, "techniqueremark");
            return (Criteria) this;
        }

        public Criteria andTechniqueremarkLessThan(String value) {
            addCriterion("techniqueRemark <", value, "techniqueremark");
            return (Criteria) this;
        }

        public Criteria andTechniqueremarkLessThanOrEqualTo(String value) {
            addCriterion("techniqueRemark <=", value, "techniqueremark");
            return (Criteria) this;
        }

        public Criteria andTechniqueremarkLike(String value) {
            addCriterion("techniqueRemark like", value, "techniqueremark");
            return (Criteria) this;
        }

        public Criteria andTechniqueremarkNotLike(String value) {
            addCriterion("techniqueRemark not like", value, "techniqueremark");
            return (Criteria) this;
        }

        public Criteria andTechniqueremarkIn(List<String> values) {
            addCriterion("techniqueRemark in", values, "techniqueremark");
            return (Criteria) this;
        }

        public Criteria andTechniqueremarkNotIn(List<String> values) {
            addCriterion("techniqueRemark not in", values, "techniqueremark");
            return (Criteria) this;
        }

        public Criteria andTechniqueremarkBetween(String value1, String value2) {
            addCriterion("techniqueRemark between", value1, value2, "techniqueremark");
            return (Criteria) this;
        }

        public Criteria andTechniqueremarkNotBetween(String value1, String value2) {
            addCriterion("techniqueRemark not between", value1, value2, "techniqueremark");
            return (Criteria) this;
        }

        public Criteria andTechniquestatusIsNull() {
            addCriterion("techniqueStatus is null");
            return (Criteria) this;
        }

        public Criteria andTechniquestatusIsNotNull() {
            addCriterion("techniqueStatus is not null");
            return (Criteria) this;
        }

        public Criteria andTechniquestatusEqualTo(Integer value) {
            addCriterion("techniqueStatus =", value, "techniquestatus");
            return (Criteria) this;
        }

        public Criteria andTechniquestatusNotEqualTo(Integer value) {
            addCriterion("techniqueStatus <>", value, "techniquestatus");
            return (Criteria) this;
        }

        public Criteria andTechniquestatusGreaterThan(Integer value) {
            addCriterion("techniqueStatus >", value, "techniquestatus");
            return (Criteria) this;
        }

        public Criteria andTechniquestatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("techniqueStatus >=", value, "techniquestatus");
            return (Criteria) this;
        }

        public Criteria andTechniquestatusLessThan(Integer value) {
            addCriterion("techniqueStatus <", value, "techniquestatus");
            return (Criteria) this;
        }

        public Criteria andTechniquestatusLessThanOrEqualTo(Integer value) {
            addCriterion("techniqueStatus <=", value, "techniquestatus");
            return (Criteria) this;
        }

        public Criteria andTechniquestatusIn(List<Integer> values) {
            addCriterion("techniqueStatus in", values, "techniquestatus");
            return (Criteria) this;
        }

        public Criteria andTechniquestatusNotIn(List<Integer> values) {
            addCriterion("techniqueStatus not in", values, "techniquestatus");
            return (Criteria) this;
        }

        public Criteria andTechniquestatusBetween(Integer value1, Integer value2) {
            addCriterion("techniqueStatus between", value1, value2, "techniquestatus");
            return (Criteria) this;
        }

        public Criteria andTechniquestatusNotBetween(Integer value1, Integer value2) {
            addCriterion("techniqueStatus not between", value1, value2, "techniquestatus");
            return (Criteria) this;
        }

        public Criteria andApprovedateIsNull() {
            addCriterion("approveDate is null");
            return (Criteria) this;
        }

        public Criteria andApprovedateIsNotNull() {
            addCriterion("approveDate is not null");
            return (Criteria) this;
        }

        public Criteria andApprovedateEqualTo(Date value) {
            addCriterion("approveDate =", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateNotEqualTo(Date value) {
            addCriterion("approveDate <>", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateGreaterThan(Date value) {
            addCriterion("approveDate >", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateGreaterThanOrEqualTo(Date value) {
            addCriterion("approveDate >=", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateLessThan(Date value) {
            addCriterion("approveDate <", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateLessThanOrEqualTo(Date value) {
            addCriterion("approveDate <=", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateIn(List<Date> values) {
            addCriterion("approveDate in", values, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateNotIn(List<Date> values) {
            addCriterion("approveDate not in", values, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateBetween(Date value1, Date value2) {
            addCriterion("approveDate between", value1, value2, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateNotBetween(Date value1, Date value2) {
            addCriterion("approveDate not between", value1, value2, "approvedate");
            return (Criteria) this;
        }

        public Criteria andTechniquecommentIsNull() {
            addCriterion("techniqueComment is null");
            return (Criteria) this;
        }

        public Criteria andTechniquecommentIsNotNull() {
            addCriterion("techniqueComment is not null");
            return (Criteria) this;
        }

        public Criteria andTechniquecommentEqualTo(String value) {
            addCriterion("techniqueComment =", value, "techniquecomment");
            return (Criteria) this;
        }

        public Criteria andTechniquecommentNotEqualTo(String value) {
            addCriterion("techniqueComment <>", value, "techniquecomment");
            return (Criteria) this;
        }

        public Criteria andTechniquecommentGreaterThan(String value) {
            addCriterion("techniqueComment >", value, "techniquecomment");
            return (Criteria) this;
        }

        public Criteria andTechniquecommentGreaterThanOrEqualTo(String value) {
            addCriterion("techniqueComment >=", value, "techniquecomment");
            return (Criteria) this;
        }

        public Criteria andTechniquecommentLessThan(String value) {
            addCriterion("techniqueComment <", value, "techniquecomment");
            return (Criteria) this;
        }

        public Criteria andTechniquecommentLessThanOrEqualTo(String value) {
            addCriterion("techniqueComment <=", value, "techniquecomment");
            return (Criteria) this;
        }

        public Criteria andTechniquecommentLike(String value) {
            addCriterion("techniqueComment like", value, "techniquecomment");
            return (Criteria) this;
        }

        public Criteria andTechniquecommentNotLike(String value) {
            addCriterion("techniqueComment not like", value, "techniquecomment");
            return (Criteria) this;
        }

        public Criteria andTechniquecommentIn(List<String> values) {
            addCriterion("techniqueComment in", values, "techniquecomment");
            return (Criteria) this;
        }

        public Criteria andTechniquecommentNotIn(List<String> values) {
            addCriterion("techniqueComment not in", values, "techniquecomment");
            return (Criteria) this;
        }

        public Criteria andTechniquecommentBetween(String value1, String value2) {
            addCriterion("techniqueComment between", value1, value2, "techniquecomment");
            return (Criteria) this;
        }

        public Criteria andTechniquecommentNotBetween(String value1, String value2) {
            addCriterion("techniqueComment not between", value1, value2, "techniquecomment");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}