package com.cpms.pojo;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class CpmsCheckExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public CpmsCheckExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<java.sql.Date>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andCheckidIsNull() {
            addCriterion("checkId is null");
            return (Criteria) this;
        }

        public Criteria andCheckidIsNotNull() {
            addCriterion("checkId is not null");
            return (Criteria) this;
        }

        public Criteria andCheckidEqualTo(String value) {
            addCriterion("checkId =", value, "checkid");
            return (Criteria) this;
        }

        public Criteria andCheckidNotEqualTo(String value) {
            addCriterion("checkId <>", value, "checkid");
            return (Criteria) this;
        }

        public Criteria andCheckidGreaterThan(String value) {
            addCriterion("checkId >", value, "checkid");
            return (Criteria) this;
        }

        public Criteria andCheckidGreaterThanOrEqualTo(String value) {
            addCriterion("checkId >=", value, "checkid");
            return (Criteria) this;
        }

        public Criteria andCheckidLessThan(String value) {
            addCriterion("checkId <", value, "checkid");
            return (Criteria) this;
        }

        public Criteria andCheckidLessThanOrEqualTo(String value) {
            addCriterion("checkId <=", value, "checkid");
            return (Criteria) this;
        }

        public Criteria andCheckidLike(String value) {
            addCriterion("checkId like", value, "checkid");
            return (Criteria) this;
        }

        public Criteria andCheckidNotLike(String value) {
            addCriterion("checkId not like", value, "checkid");
            return (Criteria) this;
        }

        public Criteria andCheckidIn(List<String> values) {
            addCriterion("checkId in", values, "checkid");
            return (Criteria) this;
        }

        public Criteria andCheckidNotIn(List<String> values) {
            addCriterion("checkId not in", values, "checkid");
            return (Criteria) this;
        }

        public Criteria andCheckidBetween(String value1, String value2) {
            addCriterion("checkId between", value1, value2, "checkid");
            return (Criteria) this;
        }

        public Criteria andCheckidNotBetween(String value1, String value2) {
            addCriterion("checkId not between", value1, value2, "checkid");
            return (Criteria) this;
        }

        public Criteria andProjectidIsNull() {
            addCriterion("projectId is null");
            return (Criteria) this;
        }

        public Criteria andProjectidIsNotNull() {
            addCriterion("projectId is not null");
            return (Criteria) this;
        }

        public Criteria andProjectidEqualTo(String value) {
            addCriterion("projectId =", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidNotEqualTo(String value) {
            addCriterion("projectId <>", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidGreaterThan(String value) {
            addCriterion("projectId >", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidGreaterThanOrEqualTo(String value) {
            addCriterion("projectId >=", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidLessThan(String value) {
            addCriterion("projectId <", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidLessThanOrEqualTo(String value) {
            addCriterion("projectId <=", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidLike(String value) {
            addCriterion("projectId like", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidNotLike(String value) {
            addCriterion("projectId not like", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidIn(List<String> values) {
            addCriterion("projectId in", values, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidNotIn(List<String> values) {
            addCriterion("projectId not in", values, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidBetween(String value1, String value2) {
            addCriterion("projectId between", value1, value2, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidNotBetween(String value1, String value2) {
            addCriterion("projectId not between", value1, value2, "projectid");
            return (Criteria) this;
        }

        public Criteria andCheckapproversidIsNull() {
            addCriterion("checkApproversId is null");
            return (Criteria) this;
        }

        public Criteria andCheckapproversidIsNotNull() {
            addCriterion("checkApproversId is not null");
            return (Criteria) this;
        }

        public Criteria andCheckapproversidEqualTo(String value) {
            addCriterion("checkApproversId =", value, "checkapproversid");
            return (Criteria) this;
        }

        public Criteria andCheckapproversidNotEqualTo(String value) {
            addCriterion("checkApproversId <>", value, "checkapproversid");
            return (Criteria) this;
        }

        public Criteria andCheckapproversidGreaterThan(String value) {
            addCriterion("checkApproversId >", value, "checkapproversid");
            return (Criteria) this;
        }

        public Criteria andCheckapproversidGreaterThanOrEqualTo(String value) {
            addCriterion("checkApproversId >=", value, "checkapproversid");
            return (Criteria) this;
        }

        public Criteria andCheckapproversidLessThan(String value) {
            addCriterion("checkApproversId <", value, "checkapproversid");
            return (Criteria) this;
        }

        public Criteria andCheckapproversidLessThanOrEqualTo(String value) {
            addCriterion("checkApproversId <=", value, "checkapproversid");
            return (Criteria) this;
        }

        public Criteria andCheckapproversidLike(String value) {
            addCriterion("checkApproversId like", value, "checkapproversid");
            return (Criteria) this;
        }

        public Criteria andCheckapproversidNotLike(String value) {
            addCriterion("checkApproversId not like", value, "checkapproversid");
            return (Criteria) this;
        }

        public Criteria andCheckapproversidIn(List<String> values) {
            addCriterion("checkApproversId in", values, "checkapproversid");
            return (Criteria) this;
        }

        public Criteria andCheckapproversidNotIn(List<String> values) {
            addCriterion("checkApproversId not in", values, "checkapproversid");
            return (Criteria) this;
        }

        public Criteria andCheckapproversidBetween(String value1, String value2) {
            addCriterion("checkApproversId between", value1, value2, "checkapproversid");
            return (Criteria) this;
        }

        public Criteria andCheckapproversidNotBetween(String value1, String value2) {
            addCriterion("checkApproversId not between", value1, value2, "checkapproversid");
            return (Criteria) this;
        }

        public Criteria andCheckinspectorIsNull() {
            addCriterion("checkInspector is null");
            return (Criteria) this;
        }

        public Criteria andCheckinspectorIsNotNull() {
            addCriterion("checkInspector is not null");
            return (Criteria) this;
        }

        public Criteria andCheckinspectorEqualTo(String value) {
            addCriterion("checkInspector =", value, "checkinspector");
            return (Criteria) this;
        }

        public Criteria andCheckinspectorNotEqualTo(String value) {
            addCriterion("checkInspector <>", value, "checkinspector");
            return (Criteria) this;
        }

        public Criteria andCheckinspectorGreaterThan(String value) {
            addCriterion("checkInspector >", value, "checkinspector");
            return (Criteria) this;
        }

        public Criteria andCheckinspectorGreaterThanOrEqualTo(String value) {
            addCriterion("checkInspector >=", value, "checkinspector");
            return (Criteria) this;
        }

        public Criteria andCheckinspectorLessThan(String value) {
            addCriterion("checkInspector <", value, "checkinspector");
            return (Criteria) this;
        }

        public Criteria andCheckinspectorLessThanOrEqualTo(String value) {
            addCriterion("checkInspector <=", value, "checkinspector");
            return (Criteria) this;
        }

        public Criteria andCheckinspectorLike(String value) {
            addCriterion("checkInspector like", value, "checkinspector");
            return (Criteria) this;
        }

        public Criteria andCheckinspectorNotLike(String value) {
            addCriterion("checkInspector not like", value, "checkinspector");
            return (Criteria) this;
        }

        public Criteria andCheckinspectorIn(List<String> values) {
            addCriterion("checkInspector in", values, "checkinspector");
            return (Criteria) this;
        }

        public Criteria andCheckinspectorNotIn(List<String> values) {
            addCriterion("checkInspector not in", values, "checkinspector");
            return (Criteria) this;
        }

        public Criteria andCheckinspectorBetween(String value1, String value2) {
            addCriterion("checkInspector between", value1, value2, "checkinspector");
            return (Criteria) this;
        }

        public Criteria andCheckinspectorNotBetween(String value1, String value2) {
            addCriterion("checkInspector not between", value1, value2, "checkinspector");
            return (Criteria) this;
        }

        public Criteria andCheckdateIsNull() {
            addCriterion("checkDate is null");
            return (Criteria) this;
        }

        public Criteria andCheckdateIsNotNull() {
            addCriterion("checkDate is not null");
            return (Criteria) this;
        }

        public Criteria andCheckdateEqualTo(Date value) {
            addCriterionForJDBCDate("checkDate =", value, "checkdate");
            return (Criteria) this;
        }

        public Criteria andCheckdateNotEqualTo(Date value) {
            addCriterionForJDBCDate("checkDate <>", value, "checkdate");
            return (Criteria) this;
        }

        public Criteria andCheckdateGreaterThan(Date value) {
            addCriterionForJDBCDate("checkDate >", value, "checkdate");
            return (Criteria) this;
        }

        public Criteria andCheckdateGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("checkDate >=", value, "checkdate");
            return (Criteria) this;
        }

        public Criteria andCheckdateLessThan(Date value) {
            addCriterionForJDBCDate("checkDate <", value, "checkdate");
            return (Criteria) this;
        }

        public Criteria andCheckdateLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("checkDate <=", value, "checkdate");
            return (Criteria) this;
        }

        public Criteria andCheckdateIn(List<Date> values) {
            addCriterionForJDBCDate("checkDate in", values, "checkdate");
            return (Criteria) this;
        }

        public Criteria andCheckdateNotIn(List<Date> values) {
            addCriterionForJDBCDate("checkDate not in", values, "checkdate");
            return (Criteria) this;
        }

        public Criteria andCheckdateBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("checkDate between", value1, value2, "checkdate");
            return (Criteria) this;
        }

        public Criteria andCheckdateNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("checkDate not between", value1, value2, "checkdate");
            return (Criteria) this;
        }

        public Criteria andCheckpartIsNull() {
            addCriterion("checkPart is null");
            return (Criteria) this;
        }

        public Criteria andCheckpartIsNotNull() {
            addCriterion("checkPart is not null");
            return (Criteria) this;
        }

        public Criteria andCheckpartEqualTo(String value) {
            addCriterion("checkPart =", value, "checkpart");
            return (Criteria) this;
        }

        public Criteria andCheckpartNotEqualTo(String value) {
            addCriterion("checkPart <>", value, "checkpart");
            return (Criteria) this;
        }

        public Criteria andCheckpartGreaterThan(String value) {
            addCriterion("checkPart >", value, "checkpart");
            return (Criteria) this;
        }

        public Criteria andCheckpartGreaterThanOrEqualTo(String value) {
            addCriterion("checkPart >=", value, "checkpart");
            return (Criteria) this;
        }

        public Criteria andCheckpartLessThan(String value) {
            addCriterion("checkPart <", value, "checkpart");
            return (Criteria) this;
        }

        public Criteria andCheckpartLessThanOrEqualTo(String value) {
            addCriterion("checkPart <=", value, "checkpart");
            return (Criteria) this;
        }

        public Criteria andCheckpartLike(String value) {
            addCriterion("checkPart like", value, "checkpart");
            return (Criteria) this;
        }

        public Criteria andCheckpartNotLike(String value) {
            addCriterion("checkPart not like", value, "checkpart");
            return (Criteria) this;
        }

        public Criteria andCheckpartIn(List<String> values) {
            addCriterion("checkPart in", values, "checkpart");
            return (Criteria) this;
        }

        public Criteria andCheckpartNotIn(List<String> values) {
            addCriterion("checkPart not in", values, "checkpart");
            return (Criteria) this;
        }

        public Criteria andCheckpartBetween(String value1, String value2) {
            addCriterion("checkPart between", value1, value2, "checkpart");
            return (Criteria) this;
        }

        public Criteria andCheckpartNotBetween(String value1, String value2) {
            addCriterion("checkPart not between", value1, value2, "checkpart");
            return (Criteria) this;
        }

        public Criteria andCheckconditionIsNull() {
            addCriterion("checkCondition is null");
            return (Criteria) this;
        }

        public Criteria andCheckconditionIsNotNull() {
            addCriterion("checkCondition is not null");
            return (Criteria) this;
        }

        public Criteria andCheckconditionEqualTo(String value) {
            addCriterion("checkCondition =", value, "checkcondition");
            return (Criteria) this;
        }

        public Criteria andCheckconditionNotEqualTo(String value) {
            addCriterion("checkCondition <>", value, "checkcondition");
            return (Criteria) this;
        }

        public Criteria andCheckconditionGreaterThan(String value) {
            addCriterion("checkCondition >", value, "checkcondition");
            return (Criteria) this;
        }

        public Criteria andCheckconditionGreaterThanOrEqualTo(String value) {
            addCriterion("checkCondition >=", value, "checkcondition");
            return (Criteria) this;
        }

        public Criteria andCheckconditionLessThan(String value) {
            addCriterion("checkCondition <", value, "checkcondition");
            return (Criteria) this;
        }

        public Criteria andCheckconditionLessThanOrEqualTo(String value) {
            addCriterion("checkCondition <=", value, "checkcondition");
            return (Criteria) this;
        }

        public Criteria andCheckconditionLike(String value) {
            addCriterion("checkCondition like", value, "checkcondition");
            return (Criteria) this;
        }

        public Criteria andCheckconditionNotLike(String value) {
            addCriterion("checkCondition not like", value, "checkcondition");
            return (Criteria) this;
        }

        public Criteria andCheckconditionIn(List<String> values) {
            addCriterion("checkCondition in", values, "checkcondition");
            return (Criteria) this;
        }

        public Criteria andCheckconditionNotIn(List<String> values) {
            addCriterion("checkCondition not in", values, "checkcondition");
            return (Criteria) this;
        }

        public Criteria andCheckconditionBetween(String value1, String value2) {
            addCriterion("checkCondition between", value1, value2, "checkcondition");
            return (Criteria) this;
        }

        public Criteria andCheckconditionNotBetween(String value1, String value2) {
            addCriterion("checkCondition not between", value1, value2, "checkcondition");
            return (Criteria) this;
        }

        public Criteria andCheckmeasureIsNull() {
            addCriterion("checkMeasure is null");
            return (Criteria) this;
        }

        public Criteria andCheckmeasureIsNotNull() {
            addCriterion("checkMeasure is not null");
            return (Criteria) this;
        }

        public Criteria andCheckmeasureEqualTo(String value) {
            addCriterion("checkMeasure =", value, "checkmeasure");
            return (Criteria) this;
        }

        public Criteria andCheckmeasureNotEqualTo(String value) {
            addCriterion("checkMeasure <>", value, "checkmeasure");
            return (Criteria) this;
        }

        public Criteria andCheckmeasureGreaterThan(String value) {
            addCriterion("checkMeasure >", value, "checkmeasure");
            return (Criteria) this;
        }

        public Criteria andCheckmeasureGreaterThanOrEqualTo(String value) {
            addCriterion("checkMeasure >=", value, "checkmeasure");
            return (Criteria) this;
        }

        public Criteria andCheckmeasureLessThan(String value) {
            addCriterion("checkMeasure <", value, "checkmeasure");
            return (Criteria) this;
        }

        public Criteria andCheckmeasureLessThanOrEqualTo(String value) {
            addCriterion("checkMeasure <=", value, "checkmeasure");
            return (Criteria) this;
        }

        public Criteria andCheckmeasureLike(String value) {
            addCriterion("checkMeasure like", value, "checkmeasure");
            return (Criteria) this;
        }

        public Criteria andCheckmeasureNotLike(String value) {
            addCriterion("checkMeasure not like", value, "checkmeasure");
            return (Criteria) this;
        }

        public Criteria andCheckmeasureIn(List<String> values) {
            addCriterion("checkMeasure in", values, "checkmeasure");
            return (Criteria) this;
        }

        public Criteria andCheckmeasureNotIn(List<String> values) {
            addCriterion("checkMeasure not in", values, "checkmeasure");
            return (Criteria) this;
        }

        public Criteria andCheckmeasureBetween(String value1, String value2) {
            addCriterion("checkMeasure between", value1, value2, "checkmeasure");
            return (Criteria) this;
        }

        public Criteria andCheckmeasureNotBetween(String value1, String value2) {
            addCriterion("checkMeasure not between", value1, value2, "checkmeasure");
            return (Criteria) this;
        }

        public Criteria andCheckattachmentIsNull() {
            addCriterion("checkAttachment is null");
            return (Criteria) this;
        }

        public Criteria andCheckattachmentIsNotNull() {
            addCriterion("checkAttachment is not null");
            return (Criteria) this;
        }

        public Criteria andCheckattachmentEqualTo(String value) {
            addCriterion("checkAttachment =", value, "checkattachment");
            return (Criteria) this;
        }

        public Criteria andCheckattachmentNotEqualTo(String value) {
            addCriterion("checkAttachment <>", value, "checkattachment");
            return (Criteria) this;
        }

        public Criteria andCheckattachmentGreaterThan(String value) {
            addCriterion("checkAttachment >", value, "checkattachment");
            return (Criteria) this;
        }

        public Criteria andCheckattachmentGreaterThanOrEqualTo(String value) {
            addCriterion("checkAttachment >=", value, "checkattachment");
            return (Criteria) this;
        }

        public Criteria andCheckattachmentLessThan(String value) {
            addCriterion("checkAttachment <", value, "checkattachment");
            return (Criteria) this;
        }

        public Criteria andCheckattachmentLessThanOrEqualTo(String value) {
            addCriterion("checkAttachment <=", value, "checkattachment");
            return (Criteria) this;
        }

        public Criteria andCheckattachmentLike(String value) {
            addCriterion("checkAttachment like", value, "checkattachment");
            return (Criteria) this;
        }

        public Criteria andCheckattachmentNotLike(String value) {
            addCriterion("checkAttachment not like", value, "checkattachment");
            return (Criteria) this;
        }

        public Criteria andCheckattachmentIn(List<String> values) {
            addCriterion("checkAttachment in", values, "checkattachment");
            return (Criteria) this;
        }

        public Criteria andCheckattachmentNotIn(List<String> values) {
            addCriterion("checkAttachment not in", values, "checkattachment");
            return (Criteria) this;
        }

        public Criteria andCheckattachmentBetween(String value1, String value2) {
            addCriterion("checkAttachment between", value1, value2, "checkattachment");
            return (Criteria) this;
        }

        public Criteria andCheckattachmentNotBetween(String value1, String value2) {
            addCriterion("checkAttachment not between", value1, value2, "checkattachment");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeIsNull() {
            addCriterion("attachmentType is null");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeIsNotNull() {
            addCriterion("attachmentType is not null");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeEqualTo(String value) {
            addCriterion("attachmentType =", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeNotEqualTo(String value) {
            addCriterion("attachmentType <>", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeGreaterThan(String value) {
            addCriterion("attachmentType >", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeGreaterThanOrEqualTo(String value) {
            addCriterion("attachmentType >=", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeLessThan(String value) {
            addCriterion("attachmentType <", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeLessThanOrEqualTo(String value) {
            addCriterion("attachmentType <=", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeLike(String value) {
            addCriterion("attachmentType like", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeNotLike(String value) {
            addCriterion("attachmentType not like", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeIn(List<String> values) {
            addCriterion("attachmentType in", values, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeNotIn(List<String> values) {
            addCriterion("attachmentType not in", values, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeBetween(String value1, String value2) {
            addCriterion("attachmentType between", value1, value2, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeNotBetween(String value1, String value2) {
            addCriterion("attachmentType not between", value1, value2, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andCheckremarkIsNull() {
            addCriterion("checkRemark is null");
            return (Criteria) this;
        }

        public Criteria andCheckremarkIsNotNull() {
            addCriterion("checkRemark is not null");
            return (Criteria) this;
        }

        public Criteria andCheckremarkEqualTo(String value) {
            addCriterion("checkRemark =", value, "checkremark");
            return (Criteria) this;
        }

        public Criteria andCheckremarkNotEqualTo(String value) {
            addCriterion("checkRemark <>", value, "checkremark");
            return (Criteria) this;
        }

        public Criteria andCheckremarkGreaterThan(String value) {
            addCriterion("checkRemark >", value, "checkremark");
            return (Criteria) this;
        }

        public Criteria andCheckremarkGreaterThanOrEqualTo(String value) {
            addCriterion("checkRemark >=", value, "checkremark");
            return (Criteria) this;
        }

        public Criteria andCheckremarkLessThan(String value) {
            addCriterion("checkRemark <", value, "checkremark");
            return (Criteria) this;
        }

        public Criteria andCheckremarkLessThanOrEqualTo(String value) {
            addCriterion("checkRemark <=", value, "checkremark");
            return (Criteria) this;
        }

        public Criteria andCheckremarkLike(String value) {
            addCriterion("checkRemark like", value, "checkremark");
            return (Criteria) this;
        }

        public Criteria andCheckremarkNotLike(String value) {
            addCriterion("checkRemark not like", value, "checkremark");
            return (Criteria) this;
        }

        public Criteria andCheckremarkIn(List<String> values) {
            addCriterion("checkRemark in", values, "checkremark");
            return (Criteria) this;
        }

        public Criteria andCheckremarkNotIn(List<String> values) {
            addCriterion("checkRemark not in", values, "checkremark");
            return (Criteria) this;
        }

        public Criteria andCheckremarkBetween(String value1, String value2) {
            addCriterion("checkRemark between", value1, value2, "checkremark");
            return (Criteria) this;
        }

        public Criteria andCheckremarkNotBetween(String value1, String value2) {
            addCriterion("checkRemark not between", value1, value2, "checkremark");
            return (Criteria) this;
        }

        public Criteria andCheckstatusIsNull() {
            addCriterion("checkStatus is null");
            return (Criteria) this;
        }

        public Criteria andCheckstatusIsNotNull() {
            addCriterion("checkStatus is not null");
            return (Criteria) this;
        }

        public Criteria andCheckstatusEqualTo(Integer value) {
            addCriterion("checkStatus =", value, "checkstatus");
            return (Criteria) this;
        }

        public Criteria andCheckstatusNotEqualTo(Integer value) {
            addCriterion("checkStatus <>", value, "checkstatus");
            return (Criteria) this;
        }

        public Criteria andCheckstatusGreaterThan(Integer value) {
            addCriterion("checkStatus >", value, "checkstatus");
            return (Criteria) this;
        }

        public Criteria andCheckstatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("checkStatus >=", value, "checkstatus");
            return (Criteria) this;
        }

        public Criteria andCheckstatusLessThan(Integer value) {
            addCriterion("checkStatus <", value, "checkstatus");
            return (Criteria) this;
        }

        public Criteria andCheckstatusLessThanOrEqualTo(Integer value) {
            addCriterion("checkStatus <=", value, "checkstatus");
            return (Criteria) this;
        }

        public Criteria andCheckstatusIn(List<Integer> values) {
            addCriterion("checkStatus in", values, "checkstatus");
            return (Criteria) this;
        }

        public Criteria andCheckstatusNotIn(List<Integer> values) {
            addCriterion("checkStatus not in", values, "checkstatus");
            return (Criteria) this;
        }

        public Criteria andCheckstatusBetween(Integer value1, Integer value2) {
            addCriterion("checkStatus between", value1, value2, "checkstatus");
            return (Criteria) this;
        }

        public Criteria andCheckstatusNotBetween(Integer value1, Integer value2) {
            addCriterion("checkStatus not between", value1, value2, "checkstatus");
            return (Criteria) this;
        }

        public Criteria andApprovedateIsNull() {
            addCriterion("approveDate is null");
            return (Criteria) this;
        }

        public Criteria andApprovedateIsNotNull() {
            addCriterion("approveDate is not null");
            return (Criteria) this;
        }

        public Criteria andApprovedateEqualTo(Date value) {
            addCriterion("approveDate =", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateNotEqualTo(Date value) {
            addCriterion("approveDate <>", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateGreaterThan(Date value) {
            addCriterion("approveDate >", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateGreaterThanOrEqualTo(Date value) {
            addCriterion("approveDate >=", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateLessThan(Date value) {
            addCriterion("approveDate <", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateLessThanOrEqualTo(Date value) {
            addCriterion("approveDate <=", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateIn(List<Date> values) {
            addCriterion("approveDate in", values, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateNotIn(List<Date> values) {
            addCriterion("approveDate not in", values, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateBetween(Date value1, Date value2) {
            addCriterion("approveDate between", value1, value2, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateNotBetween(Date value1, Date value2) {
            addCriterion("approveDate not between", value1, value2, "approvedate");
            return (Criteria) this;
        }

        public Criteria andCheckcommentIsNull() {
            addCriterion("checkComment is null");
            return (Criteria) this;
        }

        public Criteria andCheckcommentIsNotNull() {
            addCriterion("checkComment is not null");
            return (Criteria) this;
        }

        public Criteria andCheckcommentEqualTo(String value) {
            addCriterion("checkComment =", value, "checkcomment");
            return (Criteria) this;
        }

        public Criteria andCheckcommentNotEqualTo(String value) {
            addCriterion("checkComment <>", value, "checkcomment");
            return (Criteria) this;
        }

        public Criteria andCheckcommentGreaterThan(String value) {
            addCriterion("checkComment >", value, "checkcomment");
            return (Criteria) this;
        }

        public Criteria andCheckcommentGreaterThanOrEqualTo(String value) {
            addCriterion("checkComment >=", value, "checkcomment");
            return (Criteria) this;
        }

        public Criteria andCheckcommentLessThan(String value) {
            addCriterion("checkComment <", value, "checkcomment");
            return (Criteria) this;
        }

        public Criteria andCheckcommentLessThanOrEqualTo(String value) {
            addCriterion("checkComment <=", value, "checkcomment");
            return (Criteria) this;
        }

        public Criteria andCheckcommentLike(String value) {
            addCriterion("checkComment like", value, "checkcomment");
            return (Criteria) this;
        }

        public Criteria andCheckcommentNotLike(String value) {
            addCriterion("checkComment not like", value, "checkcomment");
            return (Criteria) this;
        }

        public Criteria andCheckcommentIn(List<String> values) {
            addCriterion("checkComment in", values, "checkcomment");
            return (Criteria) this;
        }

        public Criteria andCheckcommentNotIn(List<String> values) {
            addCriterion("checkComment not in", values, "checkcomment");
            return (Criteria) this;
        }

        public Criteria andCheckcommentBetween(String value1, String value2) {
            addCriterion("checkComment between", value1, value2, "checkcomment");
            return (Criteria) this;
        }

        public Criteria andCheckcommentNotBetween(String value1, String value2) {
            addCriterion("checkComment not between", value1, value2, "checkcomment");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}