package com.cpms.pojo;

import java.util.Date;

public class CpmsChange {
    private String changeid;

    private String projectid;

    private String changeeditorid;

    private String changeapproversid;

    private String changename;

    private Date changedate;

    private Double changeamount;

    private String changeunit;

    private String changeolddesign;

    private String changeoldtype;

    private String changenewdesign;

    private String changenewtype;

    private String changereason;

    private String changecontent;

    private String changeremark;

    private Integer changestatus;

    private Date approvedate;

    private String changecomment;

    public String getChangeid() {
        return changeid;
    }

    public void setChangeid(String changeid) {
        this.changeid = changeid == null ? null : changeid.trim();
    }

    public String getProjectid() {
        return projectid;
    }

    public void setProjectid(String projectid) {
        this.projectid = projectid == null ? null : projectid.trim();
    }

    public String getChangeeditorid() {
        return changeeditorid;
    }

    public void setChangeeditorid(String changeeditorid) {
        this.changeeditorid = changeeditorid == null ? null : changeeditorid.trim();
    }

    public String getChangeapproversid() {
        return changeapproversid;
    }

    public void setChangeapproversid(String changeapproversid) {
        this.changeapproversid = changeapproversid == null ? null : changeapproversid.trim();
    }

    public String getChangename() {
        return changename;
    }

    public void setChangename(String changename) {
        this.changename = changename == null ? null : changename.trim();
    }

    public Date getChangedate() {
        return changedate;
    }

    public void setChangedate(Date changedate) {
        this.changedate = changedate;
    }

    public Double getChangeamount() {
        return changeamount;
    }

    public void setChangeamount(Double changeamount) {
        this.changeamount = changeamount;
    }

    public String getChangeunit() {
        return changeunit;
    }

    public void setChangeunit(String changeunit) {
        this.changeunit = changeunit == null ? null : changeunit.trim();
    }

    public String getChangeolddesign() {
        return changeolddesign;
    }

    public void setChangeolddesign(String changeolddesign) {
        this.changeolddesign = changeolddesign == null ? null : changeolddesign.trim();
    }

    public String getChangeoldtype() {
        return changeoldtype;
    }

    public void setChangeoldtype(String changeoldtype) {
        this.changeoldtype = changeoldtype == null ? null : changeoldtype.trim();
    }

    public String getChangenewdesign() {
        return changenewdesign;
    }

    public void setChangenewdesign(String changenewdesign) {
        this.changenewdesign = changenewdesign == null ? null : changenewdesign.trim();
    }

    public String getChangenewtype() {
        return changenewtype;
    }

    public void setChangenewtype(String changenewtype) {
        this.changenewtype = changenewtype == null ? null : changenewtype.trim();
    }

    public String getChangereason() {
        return changereason;
    }

    public void setChangereason(String changereason) {
        this.changereason = changereason == null ? null : changereason.trim();
    }

    public String getChangecontent() {
        return changecontent;
    }

    public void setChangecontent(String changecontent) {
        this.changecontent = changecontent == null ? null : changecontent.trim();
    }

    public String getChangeremark() {
        return changeremark;
    }

    public void setChangeremark(String changeremark) {
        this.changeremark = changeremark == null ? null : changeremark.trim();
    }

    public Integer getChangestatus() {
        return changestatus;
    }

    public void setChangestatus(Integer changestatus) {
        this.changestatus = changestatus;
    }

    public Date getApprovedate() {
        return approvedate;
    }

    public void setApprovedate(Date approvedate) {
        this.approvedate = approvedate;
    }

    public String getChangecomment() {
        return changecomment;
    }

    public void setChangecomment(String changecomment) {
        this.changecomment = changecomment == null ? null : changecomment.trim();
    }
}