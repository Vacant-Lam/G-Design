package com.cpms.pojo;

import java.util.ArrayList;
import java.util.List;

public class CpmsCostDetailExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public CpmsCostDetailExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andCostdetailidIsNull() {
            addCriterion("costDetailId is null");
            return (Criteria) this;
        }

        public Criteria andCostdetailidIsNotNull() {
            addCriterion("costDetailId is not null");
            return (Criteria) this;
        }

        public Criteria andCostdetailidEqualTo(Integer value) {
            addCriterion("costDetailId =", value, "costdetailid");
            return (Criteria) this;
        }

        public Criteria andCostdetailidNotEqualTo(Integer value) {
            addCriterion("costDetailId <>", value, "costdetailid");
            return (Criteria) this;
        }

        public Criteria andCostdetailidGreaterThan(Integer value) {
            addCriterion("costDetailId >", value, "costdetailid");
            return (Criteria) this;
        }

        public Criteria andCostdetailidGreaterThanOrEqualTo(Integer value) {
            addCriterion("costDetailId >=", value, "costdetailid");
            return (Criteria) this;
        }

        public Criteria andCostdetailidLessThan(Integer value) {
            addCriterion("costDetailId <", value, "costdetailid");
            return (Criteria) this;
        }

        public Criteria andCostdetailidLessThanOrEqualTo(Integer value) {
            addCriterion("costDetailId <=", value, "costdetailid");
            return (Criteria) this;
        }

        public Criteria andCostdetailidIn(List<Integer> values) {
            addCriterion("costDetailId in", values, "costdetailid");
            return (Criteria) this;
        }

        public Criteria andCostdetailidNotIn(List<Integer> values) {
            addCriterion("costDetailId not in", values, "costdetailid");
            return (Criteria) this;
        }

        public Criteria andCostdetailidBetween(Integer value1, Integer value2) {
            addCriterion("costDetailId between", value1, value2, "costdetailid");
            return (Criteria) this;
        }

        public Criteria andCostdetailidNotBetween(Integer value1, Integer value2) {
            addCriterion("costDetailId not between", value1, value2, "costdetailid");
            return (Criteria) this;
        }

        public Criteria andCostidIsNull() {
            addCriterion("costId is null");
            return (Criteria) this;
        }

        public Criteria andCostidIsNotNull() {
            addCriterion("costId is not null");
            return (Criteria) this;
        }

        public Criteria andCostidEqualTo(String value) {
            addCriterion("costId =", value, "costid");
            return (Criteria) this;
        }

        public Criteria andCostidNotEqualTo(String value) {
            addCriterion("costId <>", value, "costid");
            return (Criteria) this;
        }

        public Criteria andCostidGreaterThan(String value) {
            addCriterion("costId >", value, "costid");
            return (Criteria) this;
        }

        public Criteria andCostidGreaterThanOrEqualTo(String value) {
            addCriterion("costId >=", value, "costid");
            return (Criteria) this;
        }

        public Criteria andCostidLessThan(String value) {
            addCriterion("costId <", value, "costid");
            return (Criteria) this;
        }

        public Criteria andCostidLessThanOrEqualTo(String value) {
            addCriterion("costId <=", value, "costid");
            return (Criteria) this;
        }

        public Criteria andCostidLike(String value) {
            addCriterion("costId like", value, "costid");
            return (Criteria) this;
        }

        public Criteria andCostidNotLike(String value) {
            addCriterion("costId not like", value, "costid");
            return (Criteria) this;
        }

        public Criteria andCostidIn(List<String> values) {
            addCriterion("costId in", values, "costid");
            return (Criteria) this;
        }

        public Criteria andCostidNotIn(List<String> values) {
            addCriterion("costId not in", values, "costid");
            return (Criteria) this;
        }

        public Criteria andCostidBetween(String value1, String value2) {
            addCriterion("costId between", value1, value2, "costid");
            return (Criteria) this;
        }

        public Criteria andCostidNotBetween(String value1, String value2) {
            addCriterion("costId not between", value1, value2, "costid");
            return (Criteria) this;
        }

        public Criteria andCostsubjectIsNull() {
            addCriterion("costSubject is null");
            return (Criteria) this;
        }

        public Criteria andCostsubjectIsNotNull() {
            addCriterion("costSubject is not null");
            return (Criteria) this;
        }

        public Criteria andCostsubjectEqualTo(String value) {
            addCriterion("costSubject =", value, "costsubject");
            return (Criteria) this;
        }

        public Criteria andCostsubjectNotEqualTo(String value) {
            addCriterion("costSubject <>", value, "costsubject");
            return (Criteria) this;
        }

        public Criteria andCostsubjectGreaterThan(String value) {
            addCriterion("costSubject >", value, "costsubject");
            return (Criteria) this;
        }

        public Criteria andCostsubjectGreaterThanOrEqualTo(String value) {
            addCriterion("costSubject >=", value, "costsubject");
            return (Criteria) this;
        }

        public Criteria andCostsubjectLessThan(String value) {
            addCriterion("costSubject <", value, "costsubject");
            return (Criteria) this;
        }

        public Criteria andCostsubjectLessThanOrEqualTo(String value) {
            addCriterion("costSubject <=", value, "costsubject");
            return (Criteria) this;
        }

        public Criteria andCostsubjectLike(String value) {
            addCriterion("costSubject like", value, "costsubject");
            return (Criteria) this;
        }

        public Criteria andCostsubjectNotLike(String value) {
            addCriterion("costSubject not like", value, "costsubject");
            return (Criteria) this;
        }

        public Criteria andCostsubjectIn(List<String> values) {
            addCriterion("costSubject in", values, "costsubject");
            return (Criteria) this;
        }

        public Criteria andCostsubjectNotIn(List<String> values) {
            addCriterion("costSubject not in", values, "costsubject");
            return (Criteria) this;
        }

        public Criteria andCostsubjectBetween(String value1, String value2) {
            addCriterion("costSubject between", value1, value2, "costsubject");
            return (Criteria) this;
        }

        public Criteria andCostsubjectNotBetween(String value1, String value2) {
            addCriterion("costSubject not between", value1, value2, "costsubject");
            return (Criteria) this;
        }

        public Criteria andCostaccountIsNull() {
            addCriterion("costAccount is null");
            return (Criteria) this;
        }

        public Criteria andCostaccountIsNotNull() {
            addCriterion("costAccount is not null");
            return (Criteria) this;
        }

        public Criteria andCostaccountEqualTo(Double value) {
            addCriterion("costAccount =", value, "costaccount");
            return (Criteria) this;
        }

        public Criteria andCostaccountNotEqualTo(Double value) {
            addCriterion("costAccount <>", value, "costaccount");
            return (Criteria) this;
        }

        public Criteria andCostaccountGreaterThan(Double value) {
            addCriterion("costAccount >", value, "costaccount");
            return (Criteria) this;
        }

        public Criteria andCostaccountGreaterThanOrEqualTo(Double value) {
            addCriterion("costAccount >=", value, "costaccount");
            return (Criteria) this;
        }

        public Criteria andCostaccountLessThan(Double value) {
            addCriterion("costAccount <", value, "costaccount");
            return (Criteria) this;
        }

        public Criteria andCostaccountLessThanOrEqualTo(Double value) {
            addCriterion("costAccount <=", value, "costaccount");
            return (Criteria) this;
        }

        public Criteria andCostaccountIn(List<Double> values) {
            addCriterion("costAccount in", values, "costaccount");
            return (Criteria) this;
        }

        public Criteria andCostaccountNotIn(List<Double> values) {
            addCriterion("costAccount not in", values, "costaccount");
            return (Criteria) this;
        }

        public Criteria andCostaccountBetween(Double value1, Double value2) {
            addCriterion("costAccount between", value1, value2, "costaccount");
            return (Criteria) this;
        }

        public Criteria andCostaccountNotBetween(Double value1, Double value2) {
            addCriterion("costAccount not between", value1, value2, "costaccount");
            return (Criteria) this;
        }

        public Criteria andCostdetailIsNull() {
            addCriterion("costDetail is null");
            return (Criteria) this;
        }

        public Criteria andCostdetailIsNotNull() {
            addCriterion("costDetail is not null");
            return (Criteria) this;
        }

        public Criteria andCostdetailEqualTo(String value) {
            addCriterion("costDetail =", value, "costdetail");
            return (Criteria) this;
        }

        public Criteria andCostdetailNotEqualTo(String value) {
            addCriterion("costDetail <>", value, "costdetail");
            return (Criteria) this;
        }

        public Criteria andCostdetailGreaterThan(String value) {
            addCriterion("costDetail >", value, "costdetail");
            return (Criteria) this;
        }

        public Criteria andCostdetailGreaterThanOrEqualTo(String value) {
            addCriterion("costDetail >=", value, "costdetail");
            return (Criteria) this;
        }

        public Criteria andCostdetailLessThan(String value) {
            addCriterion("costDetail <", value, "costdetail");
            return (Criteria) this;
        }

        public Criteria andCostdetailLessThanOrEqualTo(String value) {
            addCriterion("costDetail <=", value, "costdetail");
            return (Criteria) this;
        }

        public Criteria andCostdetailLike(String value) {
            addCriterion("costDetail like", value, "costdetail");
            return (Criteria) this;
        }

        public Criteria andCostdetailNotLike(String value) {
            addCriterion("costDetail not like", value, "costdetail");
            return (Criteria) this;
        }

        public Criteria andCostdetailIn(List<String> values) {
            addCriterion("costDetail in", values, "costdetail");
            return (Criteria) this;
        }

        public Criteria andCostdetailNotIn(List<String> values) {
            addCriterion("costDetail not in", values, "costdetail");
            return (Criteria) this;
        }

        public Criteria andCostdetailBetween(String value1, String value2) {
            addCriterion("costDetail between", value1, value2, "costdetail");
            return (Criteria) this;
        }

        public Criteria andCostdetailNotBetween(String value1, String value2) {
            addCriterion("costDetail not between", value1, value2, "costdetail");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}