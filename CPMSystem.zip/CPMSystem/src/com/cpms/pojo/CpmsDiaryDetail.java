package com.cpms.pojo;

public class CpmsDiaryDetail {
    private Integer diarydetailid;

    private String diaryid;

    private String detailteam;

    private Integer detailworkernum;

    private String detailcontent;

    private String detailremark;

    private String detailprogress;

    private String detailmainwork;

    private String detailother;

    public Integer getDiarydetailid() {
        return diarydetailid;
    }

    public void setDiarydetailid(Integer diarydetailid) {
        this.diarydetailid = diarydetailid;
    }

    public String getDiaryid() {
        return diaryid;
    }

    public void setDiaryid(String diaryid) {
        this.diaryid = diaryid == null ? null : diaryid.trim();
    }

    public String getDetailteam() {
        return detailteam;
    }

    public void setDetailteam(String detailteam) {
        this.detailteam = detailteam == null ? null : detailteam.trim();
    }

    public Integer getDetailworkernum() {
        return detailworkernum;
    }

    public void setDetailworkernum(Integer detailworkernum) {
        this.detailworkernum = detailworkernum;
    }

    public String getDetailcontent() {
        return detailcontent;
    }

    public void setDetailcontent(String detailcontent) {
        this.detailcontent = detailcontent == null ? null : detailcontent.trim();
    }

    public String getDetailremark() {
        return detailremark;
    }

    public void setDetailremark(String detailremark) {
        this.detailremark = detailremark == null ? null : detailremark.trim();
    }

    public String getDetailprogress() {
        return detailprogress;
    }

    public void setDetailprogress(String detailprogress) {
        this.detailprogress = detailprogress == null ? null : detailprogress.trim();
    }

    public String getDetailmainwork() {
        return detailmainwork;
    }

    public void setDetailmainwork(String detailmainwork) {
        this.detailmainwork = detailmainwork == null ? null : detailmainwork.trim();
    }

    public String getDetailother() {
        return detailother;
    }

    public void setDetailother(String detailother) {
        this.detailother = detailother == null ? null : detailother.trim();
    }
}