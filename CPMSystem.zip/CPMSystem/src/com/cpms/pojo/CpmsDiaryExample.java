package com.cpms.pojo;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class CpmsDiaryExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public CpmsDiaryExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<java.sql.Date>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andDiaryidIsNull() {
            addCriterion("diaryId is null");
            return (Criteria) this;
        }

        public Criteria andDiaryidIsNotNull() {
            addCriterion("diaryId is not null");
            return (Criteria) this;
        }

        public Criteria andDiaryidEqualTo(String value) {
            addCriterion("diaryId =", value, "diaryid");
            return (Criteria) this;
        }

        public Criteria andDiaryidNotEqualTo(String value) {
            addCriterion("diaryId <>", value, "diaryid");
            return (Criteria) this;
        }

        public Criteria andDiaryidGreaterThan(String value) {
            addCriterion("diaryId >", value, "diaryid");
            return (Criteria) this;
        }

        public Criteria andDiaryidGreaterThanOrEqualTo(String value) {
            addCriterion("diaryId >=", value, "diaryid");
            return (Criteria) this;
        }

        public Criteria andDiaryidLessThan(String value) {
            addCriterion("diaryId <", value, "diaryid");
            return (Criteria) this;
        }

        public Criteria andDiaryidLessThanOrEqualTo(String value) {
            addCriterion("diaryId <=", value, "diaryid");
            return (Criteria) this;
        }

        public Criteria andDiaryidLike(String value) {
            addCriterion("diaryId like", value, "diaryid");
            return (Criteria) this;
        }

        public Criteria andDiaryidNotLike(String value) {
            addCriterion("diaryId not like", value, "diaryid");
            return (Criteria) this;
        }

        public Criteria andDiaryidIn(List<String> values) {
            addCriterion("diaryId in", values, "diaryid");
            return (Criteria) this;
        }

        public Criteria andDiaryidNotIn(List<String> values) {
            addCriterion("diaryId not in", values, "diaryid");
            return (Criteria) this;
        }

        public Criteria andDiaryidBetween(String value1, String value2) {
            addCriterion("diaryId between", value1, value2, "diaryid");
            return (Criteria) this;
        }

        public Criteria andDiaryidNotBetween(String value1, String value2) {
            addCriterion("diaryId not between", value1, value2, "diaryid");
            return (Criteria) this;
        }

        public Criteria andProjectidIsNull() {
            addCriterion("projectId is null");
            return (Criteria) this;
        }

        public Criteria andProjectidIsNotNull() {
            addCriterion("projectId is not null");
            return (Criteria) this;
        }

        public Criteria andProjectidEqualTo(String value) {
            addCriterion("projectId =", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidNotEqualTo(String value) {
            addCriterion("projectId <>", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidGreaterThan(String value) {
            addCriterion("projectId >", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidGreaterThanOrEqualTo(String value) {
            addCriterion("projectId >=", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidLessThan(String value) {
            addCriterion("projectId <", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidLessThanOrEqualTo(String value) {
            addCriterion("projectId <=", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidLike(String value) {
            addCriterion("projectId like", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidNotLike(String value) {
            addCriterion("projectId not like", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidIn(List<String> values) {
            addCriterion("projectId in", values, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidNotIn(List<String> values) {
            addCriterion("projectId not in", values, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidBetween(String value1, String value2) {
            addCriterion("projectId between", value1, value2, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidNotBetween(String value1, String value2) {
            addCriterion("projectId not between", value1, value2, "projectid");
            return (Criteria) this;
        }

        public Criteria andDiaryeditoridIsNull() {
            addCriterion("diaryEditorId is null");
            return (Criteria) this;
        }

        public Criteria andDiaryeditoridIsNotNull() {
            addCriterion("diaryEditorId is not null");
            return (Criteria) this;
        }

        public Criteria andDiaryeditoridEqualTo(String value) {
            addCriterion("diaryEditorId =", value, "diaryeditorid");
            return (Criteria) this;
        }

        public Criteria andDiaryeditoridNotEqualTo(String value) {
            addCriterion("diaryEditorId <>", value, "diaryeditorid");
            return (Criteria) this;
        }

        public Criteria andDiaryeditoridGreaterThan(String value) {
            addCriterion("diaryEditorId >", value, "diaryeditorid");
            return (Criteria) this;
        }

        public Criteria andDiaryeditoridGreaterThanOrEqualTo(String value) {
            addCriterion("diaryEditorId >=", value, "diaryeditorid");
            return (Criteria) this;
        }

        public Criteria andDiaryeditoridLessThan(String value) {
            addCriterion("diaryEditorId <", value, "diaryeditorid");
            return (Criteria) this;
        }

        public Criteria andDiaryeditoridLessThanOrEqualTo(String value) {
            addCriterion("diaryEditorId <=", value, "diaryeditorid");
            return (Criteria) this;
        }

        public Criteria andDiaryeditoridLike(String value) {
            addCriterion("diaryEditorId like", value, "diaryeditorid");
            return (Criteria) this;
        }

        public Criteria andDiaryeditoridNotLike(String value) {
            addCriterion("diaryEditorId not like", value, "diaryeditorid");
            return (Criteria) this;
        }

        public Criteria andDiaryeditoridIn(List<String> values) {
            addCriterion("diaryEditorId in", values, "diaryeditorid");
            return (Criteria) this;
        }

        public Criteria andDiaryeditoridNotIn(List<String> values) {
            addCriterion("diaryEditorId not in", values, "diaryeditorid");
            return (Criteria) this;
        }

        public Criteria andDiaryeditoridBetween(String value1, String value2) {
            addCriterion("diaryEditorId between", value1, value2, "diaryeditorid");
            return (Criteria) this;
        }

        public Criteria andDiaryeditoridNotBetween(String value1, String value2) {
            addCriterion("diaryEditorId not between", value1, value2, "diaryeditorid");
            return (Criteria) this;
        }

        public Criteria andDiaryapproversidIsNull() {
            addCriterion("diaryApproversId is null");
            return (Criteria) this;
        }

        public Criteria andDiaryapproversidIsNotNull() {
            addCriterion("diaryApproversId is not null");
            return (Criteria) this;
        }

        public Criteria andDiaryapproversidEqualTo(String value) {
            addCriterion("diaryApproversId =", value, "diaryapproversid");
            return (Criteria) this;
        }

        public Criteria andDiaryapproversidNotEqualTo(String value) {
            addCriterion("diaryApproversId <>", value, "diaryapproversid");
            return (Criteria) this;
        }

        public Criteria andDiaryapproversidGreaterThan(String value) {
            addCriterion("diaryApproversId >", value, "diaryapproversid");
            return (Criteria) this;
        }

        public Criteria andDiaryapproversidGreaterThanOrEqualTo(String value) {
            addCriterion("diaryApproversId >=", value, "diaryapproversid");
            return (Criteria) this;
        }

        public Criteria andDiaryapproversidLessThan(String value) {
            addCriterion("diaryApproversId <", value, "diaryapproversid");
            return (Criteria) this;
        }

        public Criteria andDiaryapproversidLessThanOrEqualTo(String value) {
            addCriterion("diaryApproversId <=", value, "diaryapproversid");
            return (Criteria) this;
        }

        public Criteria andDiaryapproversidLike(String value) {
            addCriterion("diaryApproversId like", value, "diaryapproversid");
            return (Criteria) this;
        }

        public Criteria andDiaryapproversidNotLike(String value) {
            addCriterion("diaryApproversId not like", value, "diaryapproversid");
            return (Criteria) this;
        }

        public Criteria andDiaryapproversidIn(List<String> values) {
            addCriterion("diaryApproversId in", values, "diaryapproversid");
            return (Criteria) this;
        }

        public Criteria andDiaryapproversidNotIn(List<String> values) {
            addCriterion("diaryApproversId not in", values, "diaryapproversid");
            return (Criteria) this;
        }

        public Criteria andDiaryapproversidBetween(String value1, String value2) {
            addCriterion("diaryApproversId between", value1, value2, "diaryapproversid");
            return (Criteria) this;
        }

        public Criteria andDiaryapproversidNotBetween(String value1, String value2) {
            addCriterion("diaryApproversId not between", value1, value2, "diaryapproversid");
            return (Criteria) this;
        }

        public Criteria andDiarydateIsNull() {
            addCriterion("diaryDate is null");
            return (Criteria) this;
        }

        public Criteria andDiarydateIsNotNull() {
            addCriterion("diaryDate is not null");
            return (Criteria) this;
        }

        public Criteria andDiarydateEqualTo(Date value) {
            addCriterionForJDBCDate("diaryDate =", value, "diarydate");
            return (Criteria) this;
        }

        public Criteria andDiarydateNotEqualTo(Date value) {
            addCriterionForJDBCDate("diaryDate <>", value, "diarydate");
            return (Criteria) this;
        }

        public Criteria andDiarydateGreaterThan(Date value) {
            addCriterionForJDBCDate("diaryDate >", value, "diarydate");
            return (Criteria) this;
        }

        public Criteria andDiarydateGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("diaryDate >=", value, "diarydate");
            return (Criteria) this;
        }

        public Criteria andDiarydateLessThan(Date value) {
            addCriterionForJDBCDate("diaryDate <", value, "diarydate");
            return (Criteria) this;
        }

        public Criteria andDiarydateLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("diaryDate <=", value, "diarydate");
            return (Criteria) this;
        }

        public Criteria andDiarydateIn(List<Date> values) {
            addCriterionForJDBCDate("diaryDate in", values, "diarydate");
            return (Criteria) this;
        }

        public Criteria andDiarydateNotIn(List<Date> values) {
            addCriterionForJDBCDate("diaryDate not in", values, "diarydate");
            return (Criteria) this;
        }

        public Criteria andDiarydateBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("diaryDate between", value1, value2, "diarydate");
            return (Criteria) this;
        }

        public Criteria andDiarydateNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("diaryDate not between", value1, value2, "diarydate");
            return (Criteria) this;
        }

        public Criteria andDiaryamweatherIsNull() {
            addCriterion("diaryAmWeather is null");
            return (Criteria) this;
        }

        public Criteria andDiaryamweatherIsNotNull() {
            addCriterion("diaryAmWeather is not null");
            return (Criteria) this;
        }

        public Criteria andDiaryamweatherEqualTo(String value) {
            addCriterion("diaryAmWeather =", value, "diaryamweather");
            return (Criteria) this;
        }

        public Criteria andDiaryamweatherNotEqualTo(String value) {
            addCriterion("diaryAmWeather <>", value, "diaryamweather");
            return (Criteria) this;
        }

        public Criteria andDiaryamweatherGreaterThan(String value) {
            addCriterion("diaryAmWeather >", value, "diaryamweather");
            return (Criteria) this;
        }

        public Criteria andDiaryamweatherGreaterThanOrEqualTo(String value) {
            addCriterion("diaryAmWeather >=", value, "diaryamweather");
            return (Criteria) this;
        }

        public Criteria andDiaryamweatherLessThan(String value) {
            addCriterion("diaryAmWeather <", value, "diaryamweather");
            return (Criteria) this;
        }

        public Criteria andDiaryamweatherLessThanOrEqualTo(String value) {
            addCriterion("diaryAmWeather <=", value, "diaryamweather");
            return (Criteria) this;
        }

        public Criteria andDiaryamweatherLike(String value) {
            addCriterion("diaryAmWeather like", value, "diaryamweather");
            return (Criteria) this;
        }

        public Criteria andDiaryamweatherNotLike(String value) {
            addCriterion("diaryAmWeather not like", value, "diaryamweather");
            return (Criteria) this;
        }

        public Criteria andDiaryamweatherIn(List<String> values) {
            addCriterion("diaryAmWeather in", values, "diaryamweather");
            return (Criteria) this;
        }

        public Criteria andDiaryamweatherNotIn(List<String> values) {
            addCriterion("diaryAmWeather not in", values, "diaryamweather");
            return (Criteria) this;
        }

        public Criteria andDiaryamweatherBetween(String value1, String value2) {
            addCriterion("diaryAmWeather between", value1, value2, "diaryamweather");
            return (Criteria) this;
        }

        public Criteria andDiaryamweatherNotBetween(String value1, String value2) {
            addCriterion("diaryAmWeather not between", value1, value2, "diaryamweather");
            return (Criteria) this;
        }

        public Criteria andDiarypmweatherIsNull() {
            addCriterion("diaryPmWeather is null");
            return (Criteria) this;
        }

        public Criteria andDiarypmweatherIsNotNull() {
            addCriterion("diaryPmWeather is not null");
            return (Criteria) this;
        }

        public Criteria andDiarypmweatherEqualTo(String value) {
            addCriterion("diaryPmWeather =", value, "diarypmweather");
            return (Criteria) this;
        }

        public Criteria andDiarypmweatherNotEqualTo(String value) {
            addCriterion("diaryPmWeather <>", value, "diarypmweather");
            return (Criteria) this;
        }

        public Criteria andDiarypmweatherGreaterThan(String value) {
            addCriterion("diaryPmWeather >", value, "diarypmweather");
            return (Criteria) this;
        }

        public Criteria andDiarypmweatherGreaterThanOrEqualTo(String value) {
            addCriterion("diaryPmWeather >=", value, "diarypmweather");
            return (Criteria) this;
        }

        public Criteria andDiarypmweatherLessThan(String value) {
            addCriterion("diaryPmWeather <", value, "diarypmweather");
            return (Criteria) this;
        }

        public Criteria andDiarypmweatherLessThanOrEqualTo(String value) {
            addCriterion("diaryPmWeather <=", value, "diarypmweather");
            return (Criteria) this;
        }

        public Criteria andDiarypmweatherLike(String value) {
            addCriterion("diaryPmWeather like", value, "diarypmweather");
            return (Criteria) this;
        }

        public Criteria andDiarypmweatherNotLike(String value) {
            addCriterion("diaryPmWeather not like", value, "diarypmweather");
            return (Criteria) this;
        }

        public Criteria andDiarypmweatherIn(List<String> values) {
            addCriterion("diaryPmWeather in", values, "diarypmweather");
            return (Criteria) this;
        }

        public Criteria andDiarypmweatherNotIn(List<String> values) {
            addCriterion("diaryPmWeather not in", values, "diarypmweather");
            return (Criteria) this;
        }

        public Criteria andDiarypmweatherBetween(String value1, String value2) {
            addCriterion("diaryPmWeather between", value1, value2, "diarypmweather");
            return (Criteria) this;
        }

        public Criteria andDiarypmweatherNotBetween(String value1, String value2) {
            addCriterion("diaryPmWeather not between", value1, value2, "diarypmweather");
            return (Criteria) this;
        }

        public Criteria andDiaryhighesttempIsNull() {
            addCriterion("diaryHighestTemp is null");
            return (Criteria) this;
        }

        public Criteria andDiaryhighesttempIsNotNull() {
            addCriterion("diaryHighestTemp is not null");
            return (Criteria) this;
        }

        public Criteria andDiaryhighesttempEqualTo(Integer value) {
            addCriterion("diaryHighestTemp =", value, "diaryhighesttemp");
            return (Criteria) this;
        }

        public Criteria andDiaryhighesttempNotEqualTo(Integer value) {
            addCriterion("diaryHighestTemp <>", value, "diaryhighesttemp");
            return (Criteria) this;
        }

        public Criteria andDiaryhighesttempGreaterThan(Integer value) {
            addCriterion("diaryHighestTemp >", value, "diaryhighesttemp");
            return (Criteria) this;
        }

        public Criteria andDiaryhighesttempGreaterThanOrEqualTo(Integer value) {
            addCriterion("diaryHighestTemp >=", value, "diaryhighesttemp");
            return (Criteria) this;
        }

        public Criteria andDiaryhighesttempLessThan(Integer value) {
            addCriterion("diaryHighestTemp <", value, "diaryhighesttemp");
            return (Criteria) this;
        }

        public Criteria andDiaryhighesttempLessThanOrEqualTo(Integer value) {
            addCriterion("diaryHighestTemp <=", value, "diaryhighesttemp");
            return (Criteria) this;
        }

        public Criteria andDiaryhighesttempIn(List<Integer> values) {
            addCriterion("diaryHighestTemp in", values, "diaryhighesttemp");
            return (Criteria) this;
        }

        public Criteria andDiaryhighesttempNotIn(List<Integer> values) {
            addCriterion("diaryHighestTemp not in", values, "diaryhighesttemp");
            return (Criteria) this;
        }

        public Criteria andDiaryhighesttempBetween(Integer value1, Integer value2) {
            addCriterion("diaryHighestTemp between", value1, value2, "diaryhighesttemp");
            return (Criteria) this;
        }

        public Criteria andDiaryhighesttempNotBetween(Integer value1, Integer value2) {
            addCriterion("diaryHighestTemp not between", value1, value2, "diaryhighesttemp");
            return (Criteria) this;
        }

        public Criteria andDiarylowesttempIsNull() {
            addCriterion("diaryLowestTemp is null");
            return (Criteria) this;
        }

        public Criteria andDiarylowesttempIsNotNull() {
            addCriterion("diaryLowestTemp is not null");
            return (Criteria) this;
        }

        public Criteria andDiarylowesttempEqualTo(Integer value) {
            addCriterion("diaryLowestTemp =", value, "diarylowesttemp");
            return (Criteria) this;
        }

        public Criteria andDiarylowesttempNotEqualTo(Integer value) {
            addCriterion("diaryLowestTemp <>", value, "diarylowesttemp");
            return (Criteria) this;
        }

        public Criteria andDiarylowesttempGreaterThan(Integer value) {
            addCriterion("diaryLowestTemp >", value, "diarylowesttemp");
            return (Criteria) this;
        }

        public Criteria andDiarylowesttempGreaterThanOrEqualTo(Integer value) {
            addCriterion("diaryLowestTemp >=", value, "diarylowesttemp");
            return (Criteria) this;
        }

        public Criteria andDiarylowesttempLessThan(Integer value) {
            addCriterion("diaryLowestTemp <", value, "diarylowesttemp");
            return (Criteria) this;
        }

        public Criteria andDiarylowesttempLessThanOrEqualTo(Integer value) {
            addCriterion("diaryLowestTemp <=", value, "diarylowesttemp");
            return (Criteria) this;
        }

        public Criteria andDiarylowesttempIn(List<Integer> values) {
            addCriterion("diaryLowestTemp in", values, "diarylowesttemp");
            return (Criteria) this;
        }

        public Criteria andDiarylowesttempNotIn(List<Integer> values) {
            addCriterion("diaryLowestTemp not in", values, "diarylowesttemp");
            return (Criteria) this;
        }

        public Criteria andDiarylowesttempBetween(Integer value1, Integer value2) {
            addCriterion("diaryLowestTemp between", value1, value2, "diarylowesttemp");
            return (Criteria) this;
        }

        public Criteria andDiarylowesttempNotBetween(Integer value1, Integer value2) {
            addCriterion("diaryLowestTemp not between", value1, value2, "diarylowesttemp");
            return (Criteria) this;
        }

        public Criteria andDiaryattachmentIsNull() {
            addCriterion("diaryAttachment is null");
            return (Criteria) this;
        }

        public Criteria andDiaryattachmentIsNotNull() {
            addCriterion("diaryAttachment is not null");
            return (Criteria) this;
        }

        public Criteria andDiaryattachmentEqualTo(String value) {
            addCriterion("diaryAttachment =", value, "diaryattachment");
            return (Criteria) this;
        }

        public Criteria andDiaryattachmentNotEqualTo(String value) {
            addCriterion("diaryAttachment <>", value, "diaryattachment");
            return (Criteria) this;
        }

        public Criteria andDiaryattachmentGreaterThan(String value) {
            addCriterion("diaryAttachment >", value, "diaryattachment");
            return (Criteria) this;
        }

        public Criteria andDiaryattachmentGreaterThanOrEqualTo(String value) {
            addCriterion("diaryAttachment >=", value, "diaryattachment");
            return (Criteria) this;
        }

        public Criteria andDiaryattachmentLessThan(String value) {
            addCriterion("diaryAttachment <", value, "diaryattachment");
            return (Criteria) this;
        }

        public Criteria andDiaryattachmentLessThanOrEqualTo(String value) {
            addCriterion("diaryAttachment <=", value, "diaryattachment");
            return (Criteria) this;
        }

        public Criteria andDiaryattachmentLike(String value) {
            addCriterion("diaryAttachment like", value, "diaryattachment");
            return (Criteria) this;
        }

        public Criteria andDiaryattachmentNotLike(String value) {
            addCriterion("diaryAttachment not like", value, "diaryattachment");
            return (Criteria) this;
        }

        public Criteria andDiaryattachmentIn(List<String> values) {
            addCriterion("diaryAttachment in", values, "diaryattachment");
            return (Criteria) this;
        }

        public Criteria andDiaryattachmentNotIn(List<String> values) {
            addCriterion("diaryAttachment not in", values, "diaryattachment");
            return (Criteria) this;
        }

        public Criteria andDiaryattachmentBetween(String value1, String value2) {
            addCriterion("diaryAttachment between", value1, value2, "diaryattachment");
            return (Criteria) this;
        }

        public Criteria andDiaryattachmentNotBetween(String value1, String value2) {
            addCriterion("diaryAttachment not between", value1, value2, "diaryattachment");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeIsNull() {
            addCriterion("attachmentType is null");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeIsNotNull() {
            addCriterion("attachmentType is not null");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeEqualTo(String value) {
            addCriterion("attachmentType =", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeNotEqualTo(String value) {
            addCriterion("attachmentType <>", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeGreaterThan(String value) {
            addCriterion("attachmentType >", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeGreaterThanOrEqualTo(String value) {
            addCriterion("attachmentType >=", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeLessThan(String value) {
            addCriterion("attachmentType <", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeLessThanOrEqualTo(String value) {
            addCriterion("attachmentType <=", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeLike(String value) {
            addCriterion("attachmentType like", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeNotLike(String value) {
            addCriterion("attachmentType not like", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeIn(List<String> values) {
            addCriterion("attachmentType in", values, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeNotIn(List<String> values) {
            addCriterion("attachmentType not in", values, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeBetween(String value1, String value2) {
            addCriterion("attachmentType between", value1, value2, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeNotBetween(String value1, String value2) {
            addCriterion("attachmentType not between", value1, value2, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andDiarypicIsNull() {
            addCriterion("diaryPic is null");
            return (Criteria) this;
        }

        public Criteria andDiarypicIsNotNull() {
            addCriterion("diaryPic is not null");
            return (Criteria) this;
        }

        public Criteria andDiarypicEqualTo(String value) {
            addCriterion("diaryPic =", value, "diarypic");
            return (Criteria) this;
        }

        public Criteria andDiarypicNotEqualTo(String value) {
            addCriterion("diaryPic <>", value, "diarypic");
            return (Criteria) this;
        }

        public Criteria andDiarypicGreaterThan(String value) {
            addCriterion("diaryPic >", value, "diarypic");
            return (Criteria) this;
        }

        public Criteria andDiarypicGreaterThanOrEqualTo(String value) {
            addCriterion("diaryPic >=", value, "diarypic");
            return (Criteria) this;
        }

        public Criteria andDiarypicLessThan(String value) {
            addCriterion("diaryPic <", value, "diarypic");
            return (Criteria) this;
        }

        public Criteria andDiarypicLessThanOrEqualTo(String value) {
            addCriterion("diaryPic <=", value, "diarypic");
            return (Criteria) this;
        }

        public Criteria andDiarypicLike(String value) {
            addCriterion("diaryPic like", value, "diarypic");
            return (Criteria) this;
        }

        public Criteria andDiarypicNotLike(String value) {
            addCriterion("diaryPic not like", value, "diarypic");
            return (Criteria) this;
        }

        public Criteria andDiarypicIn(List<String> values) {
            addCriterion("diaryPic in", values, "diarypic");
            return (Criteria) this;
        }

        public Criteria andDiarypicNotIn(List<String> values) {
            addCriterion("diaryPic not in", values, "diarypic");
            return (Criteria) this;
        }

        public Criteria andDiarypicBetween(String value1, String value2) {
            addCriterion("diaryPic between", value1, value2, "diarypic");
            return (Criteria) this;
        }

        public Criteria andDiarypicNotBetween(String value1, String value2) {
            addCriterion("diaryPic not between", value1, value2, "diarypic");
            return (Criteria) this;
        }

        public Criteria andDiarypictypeIsNull() {
            addCriterion("diaryPicType is null");
            return (Criteria) this;
        }

        public Criteria andDiarypictypeIsNotNull() {
            addCriterion("diaryPicType is not null");
            return (Criteria) this;
        }

        public Criteria andDiarypictypeEqualTo(String value) {
            addCriterion("diaryPicType =", value, "diarypictype");
            return (Criteria) this;
        }

        public Criteria andDiarypictypeNotEqualTo(String value) {
            addCriterion("diaryPicType <>", value, "diarypictype");
            return (Criteria) this;
        }

        public Criteria andDiarypictypeGreaterThan(String value) {
            addCriterion("diaryPicType >", value, "diarypictype");
            return (Criteria) this;
        }

        public Criteria andDiarypictypeGreaterThanOrEqualTo(String value) {
            addCriterion("diaryPicType >=", value, "diarypictype");
            return (Criteria) this;
        }

        public Criteria andDiarypictypeLessThan(String value) {
            addCriterion("diaryPicType <", value, "diarypictype");
            return (Criteria) this;
        }

        public Criteria andDiarypictypeLessThanOrEqualTo(String value) {
            addCriterion("diaryPicType <=", value, "diarypictype");
            return (Criteria) this;
        }

        public Criteria andDiarypictypeLike(String value) {
            addCriterion("diaryPicType like", value, "diarypictype");
            return (Criteria) this;
        }

        public Criteria andDiarypictypeNotLike(String value) {
            addCriterion("diaryPicType not like", value, "diarypictype");
            return (Criteria) this;
        }

        public Criteria andDiarypictypeIn(List<String> values) {
            addCriterion("diaryPicType in", values, "diarypictype");
            return (Criteria) this;
        }

        public Criteria andDiarypictypeNotIn(List<String> values) {
            addCriterion("diaryPicType not in", values, "diarypictype");
            return (Criteria) this;
        }

        public Criteria andDiarypictypeBetween(String value1, String value2) {
            addCriterion("diaryPicType between", value1, value2, "diarypictype");
            return (Criteria) this;
        }

        public Criteria andDiarypictypeNotBetween(String value1, String value2) {
            addCriterion("diaryPicType not between", value1, value2, "diarypictype");
            return (Criteria) this;
        }

        public Criteria andDiarystatusIsNull() {
            addCriterion("diaryStatus is null");
            return (Criteria) this;
        }

        public Criteria andDiarystatusIsNotNull() {
            addCriterion("diaryStatus is not null");
            return (Criteria) this;
        }

        public Criteria andDiarystatusEqualTo(Integer value) {
            addCriterion("diaryStatus =", value, "diarystatus");
            return (Criteria) this;
        }

        public Criteria andDiarystatusNotEqualTo(Integer value) {
            addCriterion("diaryStatus <>", value, "diarystatus");
            return (Criteria) this;
        }

        public Criteria andDiarystatusGreaterThan(Integer value) {
            addCriterion("diaryStatus >", value, "diarystatus");
            return (Criteria) this;
        }

        public Criteria andDiarystatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("diaryStatus >=", value, "diarystatus");
            return (Criteria) this;
        }

        public Criteria andDiarystatusLessThan(Integer value) {
            addCriterion("diaryStatus <", value, "diarystatus");
            return (Criteria) this;
        }

        public Criteria andDiarystatusLessThanOrEqualTo(Integer value) {
            addCriterion("diaryStatus <=", value, "diarystatus");
            return (Criteria) this;
        }

        public Criteria andDiarystatusIn(List<Integer> values) {
            addCriterion("diaryStatus in", values, "diarystatus");
            return (Criteria) this;
        }

        public Criteria andDiarystatusNotIn(List<Integer> values) {
            addCriterion("diaryStatus not in", values, "diarystatus");
            return (Criteria) this;
        }

        public Criteria andDiarystatusBetween(Integer value1, Integer value2) {
            addCriterion("diaryStatus between", value1, value2, "diarystatus");
            return (Criteria) this;
        }

        public Criteria andDiarystatusNotBetween(Integer value1, Integer value2) {
            addCriterion("diaryStatus not between", value1, value2, "diarystatus");
            return (Criteria) this;
        }

        public Criteria andApprovedateIsNull() {
            addCriterion("approveDate is null");
            return (Criteria) this;
        }

        public Criteria andApprovedateIsNotNull() {
            addCriterion("approveDate is not null");
            return (Criteria) this;
        }

        public Criteria andApprovedateEqualTo(Date value) {
            addCriterion("approveDate =", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateNotEqualTo(Date value) {
            addCriterion("approveDate <>", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateGreaterThan(Date value) {
            addCriterion("approveDate >", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateGreaterThanOrEqualTo(Date value) {
            addCriterion("approveDate >=", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateLessThan(Date value) {
            addCriterion("approveDate <", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateLessThanOrEqualTo(Date value) {
            addCriterion("approveDate <=", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateIn(List<Date> values) {
            addCriterion("approveDate in", values, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateNotIn(List<Date> values) {
            addCriterion("approveDate not in", values, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateBetween(Date value1, Date value2) {
            addCriterion("approveDate between", value1, value2, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateNotBetween(Date value1, Date value2) {
            addCriterion("approveDate not between", value1, value2, "approvedate");
            return (Criteria) this;
        }

        public Criteria andDiarycommentIsNull() {
            addCriterion("diaryComment is null");
            return (Criteria) this;
        }

        public Criteria andDiarycommentIsNotNull() {
            addCriterion("diaryComment is not null");
            return (Criteria) this;
        }

        public Criteria andDiarycommentEqualTo(String value) {
            addCriterion("diaryComment =", value, "diarycomment");
            return (Criteria) this;
        }

        public Criteria andDiarycommentNotEqualTo(String value) {
            addCriterion("diaryComment <>", value, "diarycomment");
            return (Criteria) this;
        }

        public Criteria andDiarycommentGreaterThan(String value) {
            addCriterion("diaryComment >", value, "diarycomment");
            return (Criteria) this;
        }

        public Criteria andDiarycommentGreaterThanOrEqualTo(String value) {
            addCriterion("diaryComment >=", value, "diarycomment");
            return (Criteria) this;
        }

        public Criteria andDiarycommentLessThan(String value) {
            addCriterion("diaryComment <", value, "diarycomment");
            return (Criteria) this;
        }

        public Criteria andDiarycommentLessThanOrEqualTo(String value) {
            addCriterion("diaryComment <=", value, "diarycomment");
            return (Criteria) this;
        }

        public Criteria andDiarycommentLike(String value) {
            addCriterion("diaryComment like", value, "diarycomment");
            return (Criteria) this;
        }

        public Criteria andDiarycommentNotLike(String value) {
            addCriterion("diaryComment not like", value, "diarycomment");
            return (Criteria) this;
        }

        public Criteria andDiarycommentIn(List<String> values) {
            addCriterion("diaryComment in", values, "diarycomment");
            return (Criteria) this;
        }

        public Criteria andDiarycommentNotIn(List<String> values) {
            addCriterion("diaryComment not in", values, "diarycomment");
            return (Criteria) this;
        }

        public Criteria andDiarycommentBetween(String value1, String value2) {
            addCriterion("diaryComment between", value1, value2, "diarycomment");
            return (Criteria) this;
        }

        public Criteria andDiarycommentNotBetween(String value1, String value2) {
            addCriterion("diaryComment not between", value1, value2, "diarycomment");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}