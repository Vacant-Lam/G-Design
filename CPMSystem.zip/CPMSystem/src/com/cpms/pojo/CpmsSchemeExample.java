package com.cpms.pojo;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class CpmsSchemeExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public CpmsSchemeExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<java.sql.Date>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andSchemeidIsNull() {
            addCriterion("schemeId is null");
            return (Criteria) this;
        }

        public Criteria andSchemeidIsNotNull() {
            addCriterion("schemeId is not null");
            return (Criteria) this;
        }

        public Criteria andSchemeidEqualTo(String value) {
            addCriterion("schemeId =", value, "schemeid");
            return (Criteria) this;
        }

        public Criteria andSchemeidNotEqualTo(String value) {
            addCriterion("schemeId <>", value, "schemeid");
            return (Criteria) this;
        }

        public Criteria andSchemeidGreaterThan(String value) {
            addCriterion("schemeId >", value, "schemeid");
            return (Criteria) this;
        }

        public Criteria andSchemeidGreaterThanOrEqualTo(String value) {
            addCriterion("schemeId >=", value, "schemeid");
            return (Criteria) this;
        }

        public Criteria andSchemeidLessThan(String value) {
            addCriterion("schemeId <", value, "schemeid");
            return (Criteria) this;
        }

        public Criteria andSchemeidLessThanOrEqualTo(String value) {
            addCriterion("schemeId <=", value, "schemeid");
            return (Criteria) this;
        }

        public Criteria andSchemeidLike(String value) {
            addCriterion("schemeId like", value, "schemeid");
            return (Criteria) this;
        }

        public Criteria andSchemeidNotLike(String value) {
            addCriterion("schemeId not like", value, "schemeid");
            return (Criteria) this;
        }

        public Criteria andSchemeidIn(List<String> values) {
            addCriterion("schemeId in", values, "schemeid");
            return (Criteria) this;
        }

        public Criteria andSchemeidNotIn(List<String> values) {
            addCriterion("schemeId not in", values, "schemeid");
            return (Criteria) this;
        }

        public Criteria andSchemeidBetween(String value1, String value2) {
            addCriterion("schemeId between", value1, value2, "schemeid");
            return (Criteria) this;
        }

        public Criteria andSchemeidNotBetween(String value1, String value2) {
            addCriterion("schemeId not between", value1, value2, "schemeid");
            return (Criteria) this;
        }

        public Criteria andProjectidIsNull() {
            addCriterion("projectId is null");
            return (Criteria) this;
        }

        public Criteria andProjectidIsNotNull() {
            addCriterion("projectId is not null");
            return (Criteria) this;
        }

        public Criteria andProjectidEqualTo(String value) {
            addCriterion("projectId =", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidNotEqualTo(String value) {
            addCriterion("projectId <>", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidGreaterThan(String value) {
            addCriterion("projectId >", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidGreaterThanOrEqualTo(String value) {
            addCriterion("projectId >=", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidLessThan(String value) {
            addCriterion("projectId <", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidLessThanOrEqualTo(String value) {
            addCriterion("projectId <=", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidLike(String value) {
            addCriterion("projectId like", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidNotLike(String value) {
            addCriterion("projectId not like", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidIn(List<String> values) {
            addCriterion("projectId in", values, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidNotIn(List<String> values) {
            addCriterion("projectId not in", values, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidBetween(String value1, String value2) {
            addCriterion("projectId between", value1, value2, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidNotBetween(String value1, String value2) {
            addCriterion("projectId not between", value1, value2, "projectid");
            return (Criteria) this;
        }

        public Criteria andSchemeeditoridIsNull() {
            addCriterion("schemeEditorId is null");
            return (Criteria) this;
        }

        public Criteria andSchemeeditoridIsNotNull() {
            addCriterion("schemeEditorId is not null");
            return (Criteria) this;
        }

        public Criteria andSchemeeditoridEqualTo(String value) {
            addCriterion("schemeEditorId =", value, "schemeeditorid");
            return (Criteria) this;
        }

        public Criteria andSchemeeditoridNotEqualTo(String value) {
            addCriterion("schemeEditorId <>", value, "schemeeditorid");
            return (Criteria) this;
        }

        public Criteria andSchemeeditoridGreaterThan(String value) {
            addCriterion("schemeEditorId >", value, "schemeeditorid");
            return (Criteria) this;
        }

        public Criteria andSchemeeditoridGreaterThanOrEqualTo(String value) {
            addCriterion("schemeEditorId >=", value, "schemeeditorid");
            return (Criteria) this;
        }

        public Criteria andSchemeeditoridLessThan(String value) {
            addCriterion("schemeEditorId <", value, "schemeeditorid");
            return (Criteria) this;
        }

        public Criteria andSchemeeditoridLessThanOrEqualTo(String value) {
            addCriterion("schemeEditorId <=", value, "schemeeditorid");
            return (Criteria) this;
        }

        public Criteria andSchemeeditoridLike(String value) {
            addCriterion("schemeEditorId like", value, "schemeeditorid");
            return (Criteria) this;
        }

        public Criteria andSchemeeditoridNotLike(String value) {
            addCriterion("schemeEditorId not like", value, "schemeeditorid");
            return (Criteria) this;
        }

        public Criteria andSchemeeditoridIn(List<String> values) {
            addCriterion("schemeEditorId in", values, "schemeeditorid");
            return (Criteria) this;
        }

        public Criteria andSchemeeditoridNotIn(List<String> values) {
            addCriterion("schemeEditorId not in", values, "schemeeditorid");
            return (Criteria) this;
        }

        public Criteria andSchemeeditoridBetween(String value1, String value2) {
            addCriterion("schemeEditorId between", value1, value2, "schemeeditorid");
            return (Criteria) this;
        }

        public Criteria andSchemeeditoridNotBetween(String value1, String value2) {
            addCriterion("schemeEditorId not between", value1, value2, "schemeeditorid");
            return (Criteria) this;
        }

        public Criteria andSchemeapproversidIsNull() {
            addCriterion("schemeApproversId is null");
            return (Criteria) this;
        }

        public Criteria andSchemeapproversidIsNotNull() {
            addCriterion("schemeApproversId is not null");
            return (Criteria) this;
        }

        public Criteria andSchemeapproversidEqualTo(String value) {
            addCriterion("schemeApproversId =", value, "schemeapproversid");
            return (Criteria) this;
        }

        public Criteria andSchemeapproversidNotEqualTo(String value) {
            addCriterion("schemeApproversId <>", value, "schemeapproversid");
            return (Criteria) this;
        }

        public Criteria andSchemeapproversidGreaterThan(String value) {
            addCriterion("schemeApproversId >", value, "schemeapproversid");
            return (Criteria) this;
        }

        public Criteria andSchemeapproversidGreaterThanOrEqualTo(String value) {
            addCriterion("schemeApproversId >=", value, "schemeapproversid");
            return (Criteria) this;
        }

        public Criteria andSchemeapproversidLessThan(String value) {
            addCriterion("schemeApproversId <", value, "schemeapproversid");
            return (Criteria) this;
        }

        public Criteria andSchemeapproversidLessThanOrEqualTo(String value) {
            addCriterion("schemeApproversId <=", value, "schemeapproversid");
            return (Criteria) this;
        }

        public Criteria andSchemeapproversidLike(String value) {
            addCriterion("schemeApproversId like", value, "schemeapproversid");
            return (Criteria) this;
        }

        public Criteria andSchemeapproversidNotLike(String value) {
            addCriterion("schemeApproversId not like", value, "schemeapproversid");
            return (Criteria) this;
        }

        public Criteria andSchemeapproversidIn(List<String> values) {
            addCriterion("schemeApproversId in", values, "schemeapproversid");
            return (Criteria) this;
        }

        public Criteria andSchemeapproversidNotIn(List<String> values) {
            addCriterion("schemeApproversId not in", values, "schemeapproversid");
            return (Criteria) this;
        }

        public Criteria andSchemeapproversidBetween(String value1, String value2) {
            addCriterion("schemeApproversId between", value1, value2, "schemeapproversid");
            return (Criteria) this;
        }

        public Criteria andSchemeapproversidNotBetween(String value1, String value2) {
            addCriterion("schemeApproversId not between", value1, value2, "schemeapproversid");
            return (Criteria) this;
        }

        public Criteria andSchemenameIsNull() {
            addCriterion("schemeName is null");
            return (Criteria) this;
        }

        public Criteria andSchemenameIsNotNull() {
            addCriterion("schemeName is not null");
            return (Criteria) this;
        }

        public Criteria andSchemenameEqualTo(String value) {
            addCriterion("schemeName =", value, "schemename");
            return (Criteria) this;
        }

        public Criteria andSchemenameNotEqualTo(String value) {
            addCriterion("schemeName <>", value, "schemename");
            return (Criteria) this;
        }

        public Criteria andSchemenameGreaterThan(String value) {
            addCriterion("schemeName >", value, "schemename");
            return (Criteria) this;
        }

        public Criteria andSchemenameGreaterThanOrEqualTo(String value) {
            addCriterion("schemeName >=", value, "schemename");
            return (Criteria) this;
        }

        public Criteria andSchemenameLessThan(String value) {
            addCriterion("schemeName <", value, "schemename");
            return (Criteria) this;
        }

        public Criteria andSchemenameLessThanOrEqualTo(String value) {
            addCriterion("schemeName <=", value, "schemename");
            return (Criteria) this;
        }

        public Criteria andSchemenameLike(String value) {
            addCriterion("schemeName like", value, "schemename");
            return (Criteria) this;
        }

        public Criteria andSchemenameNotLike(String value) {
            addCriterion("schemeName not like", value, "schemename");
            return (Criteria) this;
        }

        public Criteria andSchemenameIn(List<String> values) {
            addCriterion("schemeName in", values, "schemename");
            return (Criteria) this;
        }

        public Criteria andSchemenameNotIn(List<String> values) {
            addCriterion("schemeName not in", values, "schemename");
            return (Criteria) this;
        }

        public Criteria andSchemenameBetween(String value1, String value2) {
            addCriterion("schemeName between", value1, value2, "schemename");
            return (Criteria) this;
        }

        public Criteria andSchemenameNotBetween(String value1, String value2) {
            addCriterion("schemeName not between", value1, value2, "schemename");
            return (Criteria) this;
        }

        public Criteria andSchemedateIsNull() {
            addCriterion("schemeDate is null");
            return (Criteria) this;
        }

        public Criteria andSchemedateIsNotNull() {
            addCriterion("schemeDate is not null");
            return (Criteria) this;
        }

        public Criteria andSchemedateEqualTo(Date value) {
            addCriterionForJDBCDate("schemeDate =", value, "schemedate");
            return (Criteria) this;
        }

        public Criteria andSchemedateNotEqualTo(Date value) {
            addCriterionForJDBCDate("schemeDate <>", value, "schemedate");
            return (Criteria) this;
        }

        public Criteria andSchemedateGreaterThan(Date value) {
            addCriterionForJDBCDate("schemeDate >", value, "schemedate");
            return (Criteria) this;
        }

        public Criteria andSchemedateGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("schemeDate >=", value, "schemedate");
            return (Criteria) this;
        }

        public Criteria andSchemedateLessThan(Date value) {
            addCriterionForJDBCDate("schemeDate <", value, "schemedate");
            return (Criteria) this;
        }

        public Criteria andSchemedateLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("schemeDate <=", value, "schemedate");
            return (Criteria) this;
        }

        public Criteria andSchemedateIn(List<Date> values) {
            addCriterionForJDBCDate("schemeDate in", values, "schemedate");
            return (Criteria) this;
        }

        public Criteria andSchemedateNotIn(List<Date> values) {
            addCriterionForJDBCDate("schemeDate not in", values, "schemedate");
            return (Criteria) this;
        }

        public Criteria andSchemedateBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("schemeDate between", value1, value2, "schemedate");
            return (Criteria) this;
        }

        public Criteria andSchemedateNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("schemeDate not between", value1, value2, "schemedate");
            return (Criteria) this;
        }

        public Criteria andSchemeattachmentIsNull() {
            addCriterion("schemeAttachment is null");
            return (Criteria) this;
        }

        public Criteria andSchemeattachmentIsNotNull() {
            addCriterion("schemeAttachment is not null");
            return (Criteria) this;
        }

        public Criteria andSchemeattachmentEqualTo(String value) {
            addCriterion("schemeAttachment =", value, "schemeattachment");
            return (Criteria) this;
        }

        public Criteria andSchemeattachmentNotEqualTo(String value) {
            addCriterion("schemeAttachment <>", value, "schemeattachment");
            return (Criteria) this;
        }

        public Criteria andSchemeattachmentGreaterThan(String value) {
            addCriterion("schemeAttachment >", value, "schemeattachment");
            return (Criteria) this;
        }

        public Criteria andSchemeattachmentGreaterThanOrEqualTo(String value) {
            addCriterion("schemeAttachment >=", value, "schemeattachment");
            return (Criteria) this;
        }

        public Criteria andSchemeattachmentLessThan(String value) {
            addCriterion("schemeAttachment <", value, "schemeattachment");
            return (Criteria) this;
        }

        public Criteria andSchemeattachmentLessThanOrEqualTo(String value) {
            addCriterion("schemeAttachment <=", value, "schemeattachment");
            return (Criteria) this;
        }

        public Criteria andSchemeattachmentLike(String value) {
            addCriterion("schemeAttachment like", value, "schemeattachment");
            return (Criteria) this;
        }

        public Criteria andSchemeattachmentNotLike(String value) {
            addCriterion("schemeAttachment not like", value, "schemeattachment");
            return (Criteria) this;
        }

        public Criteria andSchemeattachmentIn(List<String> values) {
            addCriterion("schemeAttachment in", values, "schemeattachment");
            return (Criteria) this;
        }

        public Criteria andSchemeattachmentNotIn(List<String> values) {
            addCriterion("schemeAttachment not in", values, "schemeattachment");
            return (Criteria) this;
        }

        public Criteria andSchemeattachmentBetween(String value1, String value2) {
            addCriterion("schemeAttachment between", value1, value2, "schemeattachment");
            return (Criteria) this;
        }

        public Criteria andSchemeattachmentNotBetween(String value1, String value2) {
            addCriterion("schemeAttachment not between", value1, value2, "schemeattachment");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeIsNull() {
            addCriterion("attachmentType is null");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeIsNotNull() {
            addCriterion("attachmentType is not null");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeEqualTo(String value) {
            addCriterion("attachmentType =", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeNotEqualTo(String value) {
            addCriterion("attachmentType <>", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeGreaterThan(String value) {
            addCriterion("attachmentType >", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeGreaterThanOrEqualTo(String value) {
            addCriterion("attachmentType >=", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeLessThan(String value) {
            addCriterion("attachmentType <", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeLessThanOrEqualTo(String value) {
            addCriterion("attachmentType <=", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeLike(String value) {
            addCriterion("attachmentType like", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeNotLike(String value) {
            addCriterion("attachmentType not like", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeIn(List<String> values) {
            addCriterion("attachmentType in", values, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeNotIn(List<String> values) {
            addCriterion("attachmentType not in", values, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeBetween(String value1, String value2) {
            addCriterion("attachmentType between", value1, value2, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeNotBetween(String value1, String value2) {
            addCriterion("attachmentType not between", value1, value2, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andSchemecontentIsNull() {
            addCriterion("schemeContent is null");
            return (Criteria) this;
        }

        public Criteria andSchemecontentIsNotNull() {
            addCriterion("schemeContent is not null");
            return (Criteria) this;
        }

        public Criteria andSchemecontentEqualTo(String value) {
            addCriterion("schemeContent =", value, "schemecontent");
            return (Criteria) this;
        }

        public Criteria andSchemecontentNotEqualTo(String value) {
            addCriterion("schemeContent <>", value, "schemecontent");
            return (Criteria) this;
        }

        public Criteria andSchemecontentGreaterThan(String value) {
            addCriterion("schemeContent >", value, "schemecontent");
            return (Criteria) this;
        }

        public Criteria andSchemecontentGreaterThanOrEqualTo(String value) {
            addCriterion("schemeContent >=", value, "schemecontent");
            return (Criteria) this;
        }

        public Criteria andSchemecontentLessThan(String value) {
            addCriterion("schemeContent <", value, "schemecontent");
            return (Criteria) this;
        }

        public Criteria andSchemecontentLessThanOrEqualTo(String value) {
            addCriterion("schemeContent <=", value, "schemecontent");
            return (Criteria) this;
        }

        public Criteria andSchemecontentLike(String value) {
            addCriterion("schemeContent like", value, "schemecontent");
            return (Criteria) this;
        }

        public Criteria andSchemecontentNotLike(String value) {
            addCriterion("schemeContent not like", value, "schemecontent");
            return (Criteria) this;
        }

        public Criteria andSchemecontentIn(List<String> values) {
            addCriterion("schemeContent in", values, "schemecontent");
            return (Criteria) this;
        }

        public Criteria andSchemecontentNotIn(List<String> values) {
            addCriterion("schemeContent not in", values, "schemecontent");
            return (Criteria) this;
        }

        public Criteria andSchemecontentBetween(String value1, String value2) {
            addCriterion("schemeContent between", value1, value2, "schemecontent");
            return (Criteria) this;
        }

        public Criteria andSchemecontentNotBetween(String value1, String value2) {
            addCriterion("schemeContent not between", value1, value2, "schemecontent");
            return (Criteria) this;
        }

        public Criteria andSchemeremarkIsNull() {
            addCriterion("schemeRemark is null");
            return (Criteria) this;
        }

        public Criteria andSchemeremarkIsNotNull() {
            addCriterion("schemeRemark is not null");
            return (Criteria) this;
        }

        public Criteria andSchemeremarkEqualTo(String value) {
            addCriterion("schemeRemark =", value, "schemeremark");
            return (Criteria) this;
        }

        public Criteria andSchemeremarkNotEqualTo(String value) {
            addCriterion("schemeRemark <>", value, "schemeremark");
            return (Criteria) this;
        }

        public Criteria andSchemeremarkGreaterThan(String value) {
            addCriterion("schemeRemark >", value, "schemeremark");
            return (Criteria) this;
        }

        public Criteria andSchemeremarkGreaterThanOrEqualTo(String value) {
            addCriterion("schemeRemark >=", value, "schemeremark");
            return (Criteria) this;
        }

        public Criteria andSchemeremarkLessThan(String value) {
            addCriterion("schemeRemark <", value, "schemeremark");
            return (Criteria) this;
        }

        public Criteria andSchemeremarkLessThanOrEqualTo(String value) {
            addCriterion("schemeRemark <=", value, "schemeremark");
            return (Criteria) this;
        }

        public Criteria andSchemeremarkLike(String value) {
            addCriterion("schemeRemark like", value, "schemeremark");
            return (Criteria) this;
        }

        public Criteria andSchemeremarkNotLike(String value) {
            addCriterion("schemeRemark not like", value, "schemeremark");
            return (Criteria) this;
        }

        public Criteria andSchemeremarkIn(List<String> values) {
            addCriterion("schemeRemark in", values, "schemeremark");
            return (Criteria) this;
        }

        public Criteria andSchemeremarkNotIn(List<String> values) {
            addCriterion("schemeRemark not in", values, "schemeremark");
            return (Criteria) this;
        }

        public Criteria andSchemeremarkBetween(String value1, String value2) {
            addCriterion("schemeRemark between", value1, value2, "schemeremark");
            return (Criteria) this;
        }

        public Criteria andSchemeremarkNotBetween(String value1, String value2) {
            addCriterion("schemeRemark not between", value1, value2, "schemeremark");
            return (Criteria) this;
        }

        public Criteria andSchemestatusIsNull() {
            addCriterion("schemeStatus is null");
            return (Criteria) this;
        }

        public Criteria andSchemestatusIsNotNull() {
            addCriterion("schemeStatus is not null");
            return (Criteria) this;
        }

        public Criteria andSchemestatusEqualTo(Integer value) {
            addCriterion("schemeStatus =", value, "schemestatus");
            return (Criteria) this;
        }

        public Criteria andSchemestatusNotEqualTo(Integer value) {
            addCriterion("schemeStatus <>", value, "schemestatus");
            return (Criteria) this;
        }

        public Criteria andSchemestatusGreaterThan(Integer value) {
            addCriterion("schemeStatus >", value, "schemestatus");
            return (Criteria) this;
        }

        public Criteria andSchemestatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("schemeStatus >=", value, "schemestatus");
            return (Criteria) this;
        }

        public Criteria andSchemestatusLessThan(Integer value) {
            addCriterion("schemeStatus <", value, "schemestatus");
            return (Criteria) this;
        }

        public Criteria andSchemestatusLessThanOrEqualTo(Integer value) {
            addCriterion("schemeStatus <=", value, "schemestatus");
            return (Criteria) this;
        }

        public Criteria andSchemestatusIn(List<Integer> values) {
            addCriterion("schemeStatus in", values, "schemestatus");
            return (Criteria) this;
        }

        public Criteria andSchemestatusNotIn(List<Integer> values) {
            addCriterion("schemeStatus not in", values, "schemestatus");
            return (Criteria) this;
        }

        public Criteria andSchemestatusBetween(Integer value1, Integer value2) {
            addCriterion("schemeStatus between", value1, value2, "schemestatus");
            return (Criteria) this;
        }

        public Criteria andSchemestatusNotBetween(Integer value1, Integer value2) {
            addCriterion("schemeStatus not between", value1, value2, "schemestatus");
            return (Criteria) this;
        }

        public Criteria andApprovedateIsNull() {
            addCriterion("approveDate is null");
            return (Criteria) this;
        }

        public Criteria andApprovedateIsNotNull() {
            addCriterion("approveDate is not null");
            return (Criteria) this;
        }

        public Criteria andApprovedateEqualTo(Date value) {
            addCriterion("approveDate =", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateNotEqualTo(Date value) {
            addCriterion("approveDate <>", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateGreaterThan(Date value) {
            addCriterion("approveDate >", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateGreaterThanOrEqualTo(Date value) {
            addCriterion("approveDate >=", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateLessThan(Date value) {
            addCriterion("approveDate <", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateLessThanOrEqualTo(Date value) {
            addCriterion("approveDate <=", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateIn(List<Date> values) {
            addCriterion("approveDate in", values, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateNotIn(List<Date> values) {
            addCriterion("approveDate not in", values, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateBetween(Date value1, Date value2) {
            addCriterion("approveDate between", value1, value2, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateNotBetween(Date value1, Date value2) {
            addCriterion("approveDate not between", value1, value2, "approvedate");
            return (Criteria) this;
        }

        public Criteria andSchemecommentIsNull() {
            addCriterion("schemeComment is null");
            return (Criteria) this;
        }

        public Criteria andSchemecommentIsNotNull() {
            addCriterion("schemeComment is not null");
            return (Criteria) this;
        }

        public Criteria andSchemecommentEqualTo(String value) {
            addCriterion("schemeComment =", value, "schemecomment");
            return (Criteria) this;
        }

        public Criteria andSchemecommentNotEqualTo(String value) {
            addCriterion("schemeComment <>", value, "schemecomment");
            return (Criteria) this;
        }

        public Criteria andSchemecommentGreaterThan(String value) {
            addCriterion("schemeComment >", value, "schemecomment");
            return (Criteria) this;
        }

        public Criteria andSchemecommentGreaterThanOrEqualTo(String value) {
            addCriterion("schemeComment >=", value, "schemecomment");
            return (Criteria) this;
        }

        public Criteria andSchemecommentLessThan(String value) {
            addCriterion("schemeComment <", value, "schemecomment");
            return (Criteria) this;
        }

        public Criteria andSchemecommentLessThanOrEqualTo(String value) {
            addCriterion("schemeComment <=", value, "schemecomment");
            return (Criteria) this;
        }

        public Criteria andSchemecommentLike(String value) {
            addCriterion("schemeComment like", value, "schemecomment");
            return (Criteria) this;
        }

        public Criteria andSchemecommentNotLike(String value) {
            addCriterion("schemeComment not like", value, "schemecomment");
            return (Criteria) this;
        }

        public Criteria andSchemecommentIn(List<String> values) {
            addCriterion("schemeComment in", values, "schemecomment");
            return (Criteria) this;
        }

        public Criteria andSchemecommentNotIn(List<String> values) {
            addCriterion("schemeComment not in", values, "schemecomment");
            return (Criteria) this;
        }

        public Criteria andSchemecommentBetween(String value1, String value2) {
            addCriterion("schemeComment between", value1, value2, "schemecomment");
            return (Criteria) this;
        }

        public Criteria andSchemecommentNotBetween(String value1, String value2) {
            addCriterion("schemeComment not between", value1, value2, "schemecomment");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}