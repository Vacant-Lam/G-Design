package com.cpms.pojo;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class CpmsSafetyExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public CpmsSafetyExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<java.sql.Date>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andSafetyidIsNull() {
            addCriterion("safetyId is null");
            return (Criteria) this;
        }

        public Criteria andSafetyidIsNotNull() {
            addCriterion("safetyId is not null");
            return (Criteria) this;
        }

        public Criteria andSafetyidEqualTo(String value) {
            addCriterion("safetyId =", value, "safetyid");
            return (Criteria) this;
        }

        public Criteria andSafetyidNotEqualTo(String value) {
            addCriterion("safetyId <>", value, "safetyid");
            return (Criteria) this;
        }

        public Criteria andSafetyidGreaterThan(String value) {
            addCriterion("safetyId >", value, "safetyid");
            return (Criteria) this;
        }

        public Criteria andSafetyidGreaterThanOrEqualTo(String value) {
            addCriterion("safetyId >=", value, "safetyid");
            return (Criteria) this;
        }

        public Criteria andSafetyidLessThan(String value) {
            addCriterion("safetyId <", value, "safetyid");
            return (Criteria) this;
        }

        public Criteria andSafetyidLessThanOrEqualTo(String value) {
            addCriterion("safetyId <=", value, "safetyid");
            return (Criteria) this;
        }

        public Criteria andSafetyidLike(String value) {
            addCriterion("safetyId like", value, "safetyid");
            return (Criteria) this;
        }

        public Criteria andSafetyidNotLike(String value) {
            addCriterion("safetyId not like", value, "safetyid");
            return (Criteria) this;
        }

        public Criteria andSafetyidIn(List<String> values) {
            addCriterion("safetyId in", values, "safetyid");
            return (Criteria) this;
        }

        public Criteria andSafetyidNotIn(List<String> values) {
            addCriterion("safetyId not in", values, "safetyid");
            return (Criteria) this;
        }

        public Criteria andSafetyidBetween(String value1, String value2) {
            addCriterion("safetyId between", value1, value2, "safetyid");
            return (Criteria) this;
        }

        public Criteria andSafetyidNotBetween(String value1, String value2) {
            addCriterion("safetyId not between", value1, value2, "safetyid");
            return (Criteria) this;
        }

        public Criteria andProjectidIsNull() {
            addCriterion("projectId is null");
            return (Criteria) this;
        }

        public Criteria andProjectidIsNotNull() {
            addCriterion("projectId is not null");
            return (Criteria) this;
        }

        public Criteria andProjectidEqualTo(String value) {
            addCriterion("projectId =", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidNotEqualTo(String value) {
            addCriterion("projectId <>", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidGreaterThan(String value) {
            addCriterion("projectId >", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidGreaterThanOrEqualTo(String value) {
            addCriterion("projectId >=", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidLessThan(String value) {
            addCriterion("projectId <", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidLessThanOrEqualTo(String value) {
            addCriterion("projectId <=", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidLike(String value) {
            addCriterion("projectId like", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidNotLike(String value) {
            addCriterion("projectId not like", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidIn(List<String> values) {
            addCriterion("projectId in", values, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidNotIn(List<String> values) {
            addCriterion("projectId not in", values, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidBetween(String value1, String value2) {
            addCriterion("projectId between", value1, value2, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidNotBetween(String value1, String value2) {
            addCriterion("projectId not between", value1, value2, "projectid");
            return (Criteria) this;
        }

        public Criteria andSafetyeditoridIsNull() {
            addCriterion("safetyEditorId is null");
            return (Criteria) this;
        }

        public Criteria andSafetyeditoridIsNotNull() {
            addCriterion("safetyEditorId is not null");
            return (Criteria) this;
        }

        public Criteria andSafetyeditoridEqualTo(String value) {
            addCriterion("safetyEditorId =", value, "safetyeditorid");
            return (Criteria) this;
        }

        public Criteria andSafetyeditoridNotEqualTo(String value) {
            addCriterion("safetyEditorId <>", value, "safetyeditorid");
            return (Criteria) this;
        }

        public Criteria andSafetyeditoridGreaterThan(String value) {
            addCriterion("safetyEditorId >", value, "safetyeditorid");
            return (Criteria) this;
        }

        public Criteria andSafetyeditoridGreaterThanOrEqualTo(String value) {
            addCriterion("safetyEditorId >=", value, "safetyeditorid");
            return (Criteria) this;
        }

        public Criteria andSafetyeditoridLessThan(String value) {
            addCriterion("safetyEditorId <", value, "safetyeditorid");
            return (Criteria) this;
        }

        public Criteria andSafetyeditoridLessThanOrEqualTo(String value) {
            addCriterion("safetyEditorId <=", value, "safetyeditorid");
            return (Criteria) this;
        }

        public Criteria andSafetyeditoridLike(String value) {
            addCriterion("safetyEditorId like", value, "safetyeditorid");
            return (Criteria) this;
        }

        public Criteria andSafetyeditoridNotLike(String value) {
            addCriterion("safetyEditorId not like", value, "safetyeditorid");
            return (Criteria) this;
        }

        public Criteria andSafetyeditoridIn(List<String> values) {
            addCriterion("safetyEditorId in", values, "safetyeditorid");
            return (Criteria) this;
        }

        public Criteria andSafetyeditoridNotIn(List<String> values) {
            addCriterion("safetyEditorId not in", values, "safetyeditorid");
            return (Criteria) this;
        }

        public Criteria andSafetyeditoridBetween(String value1, String value2) {
            addCriterion("safetyEditorId between", value1, value2, "safetyeditorid");
            return (Criteria) this;
        }

        public Criteria andSafetyeditoridNotBetween(String value1, String value2) {
            addCriterion("safetyEditorId not between", value1, value2, "safetyeditorid");
            return (Criteria) this;
        }

        public Criteria andSafetyapproversidIsNull() {
            addCriterion("safetyApproversId is null");
            return (Criteria) this;
        }

        public Criteria andSafetyapproversidIsNotNull() {
            addCriterion("safetyApproversId is not null");
            return (Criteria) this;
        }

        public Criteria andSafetyapproversidEqualTo(String value) {
            addCriterion("safetyApproversId =", value, "safetyapproversid");
            return (Criteria) this;
        }

        public Criteria andSafetyapproversidNotEqualTo(String value) {
            addCriterion("safetyApproversId <>", value, "safetyapproversid");
            return (Criteria) this;
        }

        public Criteria andSafetyapproversidGreaterThan(String value) {
            addCriterion("safetyApproversId >", value, "safetyapproversid");
            return (Criteria) this;
        }

        public Criteria andSafetyapproversidGreaterThanOrEqualTo(String value) {
            addCriterion("safetyApproversId >=", value, "safetyapproversid");
            return (Criteria) this;
        }

        public Criteria andSafetyapproversidLessThan(String value) {
            addCriterion("safetyApproversId <", value, "safetyapproversid");
            return (Criteria) this;
        }

        public Criteria andSafetyapproversidLessThanOrEqualTo(String value) {
            addCriterion("safetyApproversId <=", value, "safetyapproversid");
            return (Criteria) this;
        }

        public Criteria andSafetyapproversidLike(String value) {
            addCriterion("safetyApproversId like", value, "safetyapproversid");
            return (Criteria) this;
        }

        public Criteria andSafetyapproversidNotLike(String value) {
            addCriterion("safetyApproversId not like", value, "safetyapproversid");
            return (Criteria) this;
        }

        public Criteria andSafetyapproversidIn(List<String> values) {
            addCriterion("safetyApproversId in", values, "safetyapproversid");
            return (Criteria) this;
        }

        public Criteria andSafetyapproversidNotIn(List<String> values) {
            addCriterion("safetyApproversId not in", values, "safetyapproversid");
            return (Criteria) this;
        }

        public Criteria andSafetyapproversidBetween(String value1, String value2) {
            addCriterion("safetyApproversId between", value1, value2, "safetyapproversid");
            return (Criteria) this;
        }

        public Criteria andSafetyapproversidNotBetween(String value1, String value2) {
            addCriterion("safetyApproversId not between", value1, value2, "safetyapproversid");
            return (Criteria) this;
        }

        public Criteria andSafetyattendanceIsNull() {
            addCriterion("safetyAttendance is null");
            return (Criteria) this;
        }

        public Criteria andSafetyattendanceIsNotNull() {
            addCriterion("safetyAttendance is not null");
            return (Criteria) this;
        }

        public Criteria andSafetyattendanceEqualTo(Integer value) {
            addCriterion("safetyAttendance =", value, "safetyattendance");
            return (Criteria) this;
        }

        public Criteria andSafetyattendanceNotEqualTo(Integer value) {
            addCriterion("safetyAttendance <>", value, "safetyattendance");
            return (Criteria) this;
        }

        public Criteria andSafetyattendanceGreaterThan(Integer value) {
            addCriterion("safetyAttendance >", value, "safetyattendance");
            return (Criteria) this;
        }

        public Criteria andSafetyattendanceGreaterThanOrEqualTo(Integer value) {
            addCriterion("safetyAttendance >=", value, "safetyattendance");
            return (Criteria) this;
        }

        public Criteria andSafetyattendanceLessThan(Integer value) {
            addCriterion("safetyAttendance <", value, "safetyattendance");
            return (Criteria) this;
        }

        public Criteria andSafetyattendanceLessThanOrEqualTo(Integer value) {
            addCriterion("safetyAttendance <=", value, "safetyattendance");
            return (Criteria) this;
        }

        public Criteria andSafetyattendanceIn(List<Integer> values) {
            addCriterion("safetyAttendance in", values, "safetyattendance");
            return (Criteria) this;
        }

        public Criteria andSafetyattendanceNotIn(List<Integer> values) {
            addCriterion("safetyAttendance not in", values, "safetyattendance");
            return (Criteria) this;
        }

        public Criteria andSafetyattendanceBetween(Integer value1, Integer value2) {
            addCriterion("safetyAttendance between", value1, value2, "safetyattendance");
            return (Criteria) this;
        }

        public Criteria andSafetyattendanceNotBetween(Integer value1, Integer value2) {
            addCriterion("safetyAttendance not between", value1, value2, "safetyattendance");
            return (Criteria) this;
        }

        public Criteria andSafetydeptIsNull() {
            addCriterion("safetyDept is null");
            return (Criteria) this;
        }

        public Criteria andSafetydeptIsNotNull() {
            addCriterion("safetyDept is not null");
            return (Criteria) this;
        }

        public Criteria andSafetydeptEqualTo(String value) {
            addCriterion("safetyDept =", value, "safetydept");
            return (Criteria) this;
        }

        public Criteria andSafetydeptNotEqualTo(String value) {
            addCriterion("safetyDept <>", value, "safetydept");
            return (Criteria) this;
        }

        public Criteria andSafetydeptGreaterThan(String value) {
            addCriterion("safetyDept >", value, "safetydept");
            return (Criteria) this;
        }

        public Criteria andSafetydeptGreaterThanOrEqualTo(String value) {
            addCriterion("safetyDept >=", value, "safetydept");
            return (Criteria) this;
        }

        public Criteria andSafetydeptLessThan(String value) {
            addCriterion("safetyDept <", value, "safetydept");
            return (Criteria) this;
        }

        public Criteria andSafetydeptLessThanOrEqualTo(String value) {
            addCriterion("safetyDept <=", value, "safetydept");
            return (Criteria) this;
        }

        public Criteria andSafetydeptLike(String value) {
            addCriterion("safetyDept like", value, "safetydept");
            return (Criteria) this;
        }

        public Criteria andSafetydeptNotLike(String value) {
            addCriterion("safetyDept not like", value, "safetydept");
            return (Criteria) this;
        }

        public Criteria andSafetydeptIn(List<String> values) {
            addCriterion("safetyDept in", values, "safetydept");
            return (Criteria) this;
        }

        public Criteria andSafetydeptNotIn(List<String> values) {
            addCriterion("safetyDept not in", values, "safetydept");
            return (Criteria) this;
        }

        public Criteria andSafetydeptBetween(String value1, String value2) {
            addCriterion("safetyDept between", value1, value2, "safetydept");
            return (Criteria) this;
        }

        public Criteria andSafetydeptNotBetween(String value1, String value2) {
            addCriterion("safetyDept not between", value1, value2, "safetydept");
            return (Criteria) this;
        }

        public Criteria andSafetytemperatureIsNull() {
            addCriterion("safetyTemperature is null");
            return (Criteria) this;
        }

        public Criteria andSafetytemperatureIsNotNull() {
            addCriterion("safetyTemperature is not null");
            return (Criteria) this;
        }

        public Criteria andSafetytemperatureEqualTo(Integer value) {
            addCriterion("safetyTemperature =", value, "safetytemperature");
            return (Criteria) this;
        }

        public Criteria andSafetytemperatureNotEqualTo(Integer value) {
            addCriterion("safetyTemperature <>", value, "safetytemperature");
            return (Criteria) this;
        }

        public Criteria andSafetytemperatureGreaterThan(Integer value) {
            addCriterion("safetyTemperature >", value, "safetytemperature");
            return (Criteria) this;
        }

        public Criteria andSafetytemperatureGreaterThanOrEqualTo(Integer value) {
            addCriterion("safetyTemperature >=", value, "safetytemperature");
            return (Criteria) this;
        }

        public Criteria andSafetytemperatureLessThan(Integer value) {
            addCriterion("safetyTemperature <", value, "safetytemperature");
            return (Criteria) this;
        }

        public Criteria andSafetytemperatureLessThanOrEqualTo(Integer value) {
            addCriterion("safetyTemperature <=", value, "safetytemperature");
            return (Criteria) this;
        }

        public Criteria andSafetytemperatureIn(List<Integer> values) {
            addCriterion("safetyTemperature in", values, "safetytemperature");
            return (Criteria) this;
        }

        public Criteria andSafetytemperatureNotIn(List<Integer> values) {
            addCriterion("safetyTemperature not in", values, "safetytemperature");
            return (Criteria) this;
        }

        public Criteria andSafetytemperatureBetween(Integer value1, Integer value2) {
            addCriterion("safetyTemperature between", value1, value2, "safetytemperature");
            return (Criteria) this;
        }

        public Criteria andSafetytemperatureNotBetween(Integer value1, Integer value2) {
            addCriterion("safetyTemperature not between", value1, value2, "safetytemperature");
            return (Criteria) this;
        }

        public Criteria andSafetydateIsNull() {
            addCriterion("safetyDate is null");
            return (Criteria) this;
        }

        public Criteria andSafetydateIsNotNull() {
            addCriterion("safetyDate is not null");
            return (Criteria) this;
        }

        public Criteria andSafetydateEqualTo(Date value) {
            addCriterionForJDBCDate("safetyDate =", value, "safetydate");
            return (Criteria) this;
        }

        public Criteria andSafetydateNotEqualTo(Date value) {
            addCriterionForJDBCDate("safetyDate <>", value, "safetydate");
            return (Criteria) this;
        }

        public Criteria andSafetydateGreaterThan(Date value) {
            addCriterionForJDBCDate("safetyDate >", value, "safetydate");
            return (Criteria) this;
        }

        public Criteria andSafetydateGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("safetyDate >=", value, "safetydate");
            return (Criteria) this;
        }

        public Criteria andSafetydateLessThan(Date value) {
            addCriterionForJDBCDate("safetyDate <", value, "safetydate");
            return (Criteria) this;
        }

        public Criteria andSafetydateLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("safetyDate <=", value, "safetydate");
            return (Criteria) this;
        }

        public Criteria andSafetydateIn(List<Date> values) {
            addCriterionForJDBCDate("safetyDate in", values, "safetydate");
            return (Criteria) this;
        }

        public Criteria andSafetydateNotIn(List<Date> values) {
            addCriterionForJDBCDate("safetyDate not in", values, "safetydate");
            return (Criteria) this;
        }

        public Criteria andSafetydateBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("safetyDate between", value1, value2, "safetydate");
            return (Criteria) this;
        }

        public Criteria andSafetydateNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("safetyDate not between", value1, value2, "safetydate");
            return (Criteria) this;
        }

        public Criteria andSafetypartIsNull() {
            addCriterion("safetyPart is null");
            return (Criteria) this;
        }

        public Criteria andSafetypartIsNotNull() {
            addCriterion("safetyPart is not null");
            return (Criteria) this;
        }

        public Criteria andSafetypartEqualTo(String value) {
            addCriterion("safetyPart =", value, "safetypart");
            return (Criteria) this;
        }

        public Criteria andSafetypartNotEqualTo(String value) {
            addCriterion("safetyPart <>", value, "safetypart");
            return (Criteria) this;
        }

        public Criteria andSafetypartGreaterThan(String value) {
            addCriterion("safetyPart >", value, "safetypart");
            return (Criteria) this;
        }

        public Criteria andSafetypartGreaterThanOrEqualTo(String value) {
            addCriterion("safetyPart >=", value, "safetypart");
            return (Criteria) this;
        }

        public Criteria andSafetypartLessThan(String value) {
            addCriterion("safetyPart <", value, "safetypart");
            return (Criteria) this;
        }

        public Criteria andSafetypartLessThanOrEqualTo(String value) {
            addCriterion("safetyPart <=", value, "safetypart");
            return (Criteria) this;
        }

        public Criteria andSafetypartLike(String value) {
            addCriterion("safetyPart like", value, "safetypart");
            return (Criteria) this;
        }

        public Criteria andSafetypartNotLike(String value) {
            addCriterion("safetyPart not like", value, "safetypart");
            return (Criteria) this;
        }

        public Criteria andSafetypartIn(List<String> values) {
            addCriterion("safetyPart in", values, "safetypart");
            return (Criteria) this;
        }

        public Criteria andSafetypartNotIn(List<String> values) {
            addCriterion("safetyPart not in", values, "safetypart");
            return (Criteria) this;
        }

        public Criteria andSafetypartBetween(String value1, String value2) {
            addCriterion("safetyPart between", value1, value2, "safetypart");
            return (Criteria) this;
        }

        public Criteria andSafetypartNotBetween(String value1, String value2) {
            addCriterion("safetyPart not between", value1, value2, "safetypart");
            return (Criteria) this;
        }

        public Criteria andSafetyconditionIsNull() {
            addCriterion("safetyCondition is null");
            return (Criteria) this;
        }

        public Criteria andSafetyconditionIsNotNull() {
            addCriterion("safetyCondition is not null");
            return (Criteria) this;
        }

        public Criteria andSafetyconditionEqualTo(String value) {
            addCriterion("safetyCondition =", value, "safetycondition");
            return (Criteria) this;
        }

        public Criteria andSafetyconditionNotEqualTo(String value) {
            addCriterion("safetyCondition <>", value, "safetycondition");
            return (Criteria) this;
        }

        public Criteria andSafetyconditionGreaterThan(String value) {
            addCriterion("safetyCondition >", value, "safetycondition");
            return (Criteria) this;
        }

        public Criteria andSafetyconditionGreaterThanOrEqualTo(String value) {
            addCriterion("safetyCondition >=", value, "safetycondition");
            return (Criteria) this;
        }

        public Criteria andSafetyconditionLessThan(String value) {
            addCriterion("safetyCondition <", value, "safetycondition");
            return (Criteria) this;
        }

        public Criteria andSafetyconditionLessThanOrEqualTo(String value) {
            addCriterion("safetyCondition <=", value, "safetycondition");
            return (Criteria) this;
        }

        public Criteria andSafetyconditionLike(String value) {
            addCriterion("safetyCondition like", value, "safetycondition");
            return (Criteria) this;
        }

        public Criteria andSafetyconditionNotLike(String value) {
            addCriterion("safetyCondition not like", value, "safetycondition");
            return (Criteria) this;
        }

        public Criteria andSafetyconditionIn(List<String> values) {
            addCriterion("safetyCondition in", values, "safetycondition");
            return (Criteria) this;
        }

        public Criteria andSafetyconditionNotIn(List<String> values) {
            addCriterion("safetyCondition not in", values, "safetycondition");
            return (Criteria) this;
        }

        public Criteria andSafetyconditionBetween(String value1, String value2) {
            addCriterion("safetyCondition between", value1, value2, "safetycondition");
            return (Criteria) this;
        }

        public Criteria andSafetyconditionNotBetween(String value1, String value2) {
            addCriterion("safetyCondition not between", value1, value2, "safetycondition");
            return (Criteria) this;
        }

        public Criteria andSafetyeducationIsNull() {
            addCriterion("safetyEducation is null");
            return (Criteria) this;
        }

        public Criteria andSafetyeducationIsNotNull() {
            addCriterion("safetyEducation is not null");
            return (Criteria) this;
        }

        public Criteria andSafetyeducationEqualTo(String value) {
            addCriterion("safetyEducation =", value, "safetyeducation");
            return (Criteria) this;
        }

        public Criteria andSafetyeducationNotEqualTo(String value) {
            addCriterion("safetyEducation <>", value, "safetyeducation");
            return (Criteria) this;
        }

        public Criteria andSafetyeducationGreaterThan(String value) {
            addCriterion("safetyEducation >", value, "safetyeducation");
            return (Criteria) this;
        }

        public Criteria andSafetyeducationGreaterThanOrEqualTo(String value) {
            addCriterion("safetyEducation >=", value, "safetyeducation");
            return (Criteria) this;
        }

        public Criteria andSafetyeducationLessThan(String value) {
            addCriterion("safetyEducation <", value, "safetyeducation");
            return (Criteria) this;
        }

        public Criteria andSafetyeducationLessThanOrEqualTo(String value) {
            addCriterion("safetyEducation <=", value, "safetyeducation");
            return (Criteria) this;
        }

        public Criteria andSafetyeducationLike(String value) {
            addCriterion("safetyEducation like", value, "safetyeducation");
            return (Criteria) this;
        }

        public Criteria andSafetyeducationNotLike(String value) {
            addCriterion("safetyEducation not like", value, "safetyeducation");
            return (Criteria) this;
        }

        public Criteria andSafetyeducationIn(List<String> values) {
            addCriterion("safetyEducation in", values, "safetyeducation");
            return (Criteria) this;
        }

        public Criteria andSafetyeducationNotIn(List<String> values) {
            addCriterion("safetyEducation not in", values, "safetyeducation");
            return (Criteria) this;
        }

        public Criteria andSafetyeducationBetween(String value1, String value2) {
            addCriterion("safetyEducation between", value1, value2, "safetyeducation");
            return (Criteria) this;
        }

        public Criteria andSafetyeducationNotBetween(String value1, String value2) {
            addCriterion("safetyEducation not between", value1, value2, "safetyeducation");
            return (Criteria) this;
        }

        public Criteria andSafetyappealIsNull() {
            addCriterion("safetyAppeal is null");
            return (Criteria) this;
        }

        public Criteria andSafetyappealIsNotNull() {
            addCriterion("safetyAppeal is not null");
            return (Criteria) this;
        }

        public Criteria andSafetyappealEqualTo(String value) {
            addCriterion("safetyAppeal =", value, "safetyappeal");
            return (Criteria) this;
        }

        public Criteria andSafetyappealNotEqualTo(String value) {
            addCriterion("safetyAppeal <>", value, "safetyappeal");
            return (Criteria) this;
        }

        public Criteria andSafetyappealGreaterThan(String value) {
            addCriterion("safetyAppeal >", value, "safetyappeal");
            return (Criteria) this;
        }

        public Criteria andSafetyappealGreaterThanOrEqualTo(String value) {
            addCriterion("safetyAppeal >=", value, "safetyappeal");
            return (Criteria) this;
        }

        public Criteria andSafetyappealLessThan(String value) {
            addCriterion("safetyAppeal <", value, "safetyappeal");
            return (Criteria) this;
        }

        public Criteria andSafetyappealLessThanOrEqualTo(String value) {
            addCriterion("safetyAppeal <=", value, "safetyappeal");
            return (Criteria) this;
        }

        public Criteria andSafetyappealLike(String value) {
            addCriterion("safetyAppeal like", value, "safetyappeal");
            return (Criteria) this;
        }

        public Criteria andSafetyappealNotLike(String value) {
            addCriterion("safetyAppeal not like", value, "safetyappeal");
            return (Criteria) this;
        }

        public Criteria andSafetyappealIn(List<String> values) {
            addCriterion("safetyAppeal in", values, "safetyappeal");
            return (Criteria) this;
        }

        public Criteria andSafetyappealNotIn(List<String> values) {
            addCriterion("safetyAppeal not in", values, "safetyappeal");
            return (Criteria) this;
        }

        public Criteria andSafetyappealBetween(String value1, String value2) {
            addCriterion("safetyAppeal between", value1, value2, "safetyappeal");
            return (Criteria) this;
        }

        public Criteria andSafetyappealNotBetween(String value1, String value2) {
            addCriterion("safetyAppeal not between", value1, value2, "safetyappeal");
            return (Criteria) this;
        }

        public Criteria andSafetyacceptIsNull() {
            addCriterion("safetyAccept is null");
            return (Criteria) this;
        }

        public Criteria andSafetyacceptIsNotNull() {
            addCriterion("safetyAccept is not null");
            return (Criteria) this;
        }

        public Criteria andSafetyacceptEqualTo(String value) {
            addCriterion("safetyAccept =", value, "safetyaccept");
            return (Criteria) this;
        }

        public Criteria andSafetyacceptNotEqualTo(String value) {
            addCriterion("safetyAccept <>", value, "safetyaccept");
            return (Criteria) this;
        }

        public Criteria andSafetyacceptGreaterThan(String value) {
            addCriterion("safetyAccept >", value, "safetyaccept");
            return (Criteria) this;
        }

        public Criteria andSafetyacceptGreaterThanOrEqualTo(String value) {
            addCriterion("safetyAccept >=", value, "safetyaccept");
            return (Criteria) this;
        }

        public Criteria andSafetyacceptLessThan(String value) {
            addCriterion("safetyAccept <", value, "safetyaccept");
            return (Criteria) this;
        }

        public Criteria andSafetyacceptLessThanOrEqualTo(String value) {
            addCriterion("safetyAccept <=", value, "safetyaccept");
            return (Criteria) this;
        }

        public Criteria andSafetyacceptLike(String value) {
            addCriterion("safetyAccept like", value, "safetyaccept");
            return (Criteria) this;
        }

        public Criteria andSafetyacceptNotLike(String value) {
            addCriterion("safetyAccept not like", value, "safetyaccept");
            return (Criteria) this;
        }

        public Criteria andSafetyacceptIn(List<String> values) {
            addCriterion("safetyAccept in", values, "safetyaccept");
            return (Criteria) this;
        }

        public Criteria andSafetyacceptNotIn(List<String> values) {
            addCriterion("safetyAccept not in", values, "safetyaccept");
            return (Criteria) this;
        }

        public Criteria andSafetyacceptBetween(String value1, String value2) {
            addCriterion("safetyAccept between", value1, value2, "safetyaccept");
            return (Criteria) this;
        }

        public Criteria andSafetyacceptNotBetween(String value1, String value2) {
            addCriterion("safetyAccept not between", value1, value2, "safetyaccept");
            return (Criteria) this;
        }

        public Criteria andSafetycheckIsNull() {
            addCriterion("safetyCheck is null");
            return (Criteria) this;
        }

        public Criteria andSafetycheckIsNotNull() {
            addCriterion("safetyCheck is not null");
            return (Criteria) this;
        }

        public Criteria andSafetycheckEqualTo(String value) {
            addCriterion("safetyCheck =", value, "safetycheck");
            return (Criteria) this;
        }

        public Criteria andSafetycheckNotEqualTo(String value) {
            addCriterion("safetyCheck <>", value, "safetycheck");
            return (Criteria) this;
        }

        public Criteria andSafetycheckGreaterThan(String value) {
            addCriterion("safetyCheck >", value, "safetycheck");
            return (Criteria) this;
        }

        public Criteria andSafetycheckGreaterThanOrEqualTo(String value) {
            addCriterion("safetyCheck >=", value, "safetycheck");
            return (Criteria) this;
        }

        public Criteria andSafetycheckLessThan(String value) {
            addCriterion("safetyCheck <", value, "safetycheck");
            return (Criteria) this;
        }

        public Criteria andSafetycheckLessThanOrEqualTo(String value) {
            addCriterion("safetyCheck <=", value, "safetycheck");
            return (Criteria) this;
        }

        public Criteria andSafetycheckLike(String value) {
            addCriterion("safetyCheck like", value, "safetycheck");
            return (Criteria) this;
        }

        public Criteria andSafetycheckNotLike(String value) {
            addCriterion("safetyCheck not like", value, "safetycheck");
            return (Criteria) this;
        }

        public Criteria andSafetycheckIn(List<String> values) {
            addCriterion("safetyCheck in", values, "safetycheck");
            return (Criteria) this;
        }

        public Criteria andSafetycheckNotIn(List<String> values) {
            addCriterion("safetyCheck not in", values, "safetycheck");
            return (Criteria) this;
        }

        public Criteria andSafetycheckBetween(String value1, String value2) {
            addCriterion("safetyCheck between", value1, value2, "safetycheck");
            return (Criteria) this;
        }

        public Criteria andSafetycheckNotBetween(String value1, String value2) {
            addCriterion("safetyCheck not between", value1, value2, "safetycheck");
            return (Criteria) this;
        }

        public Criteria andSafetynoteIsNull() {
            addCriterion("safetyNote is null");
            return (Criteria) this;
        }

        public Criteria andSafetynoteIsNotNull() {
            addCriterion("safetyNote is not null");
            return (Criteria) this;
        }

        public Criteria andSafetynoteEqualTo(String value) {
            addCriterion("safetyNote =", value, "safetynote");
            return (Criteria) this;
        }

        public Criteria andSafetynoteNotEqualTo(String value) {
            addCriterion("safetyNote <>", value, "safetynote");
            return (Criteria) this;
        }

        public Criteria andSafetynoteGreaterThan(String value) {
            addCriterion("safetyNote >", value, "safetynote");
            return (Criteria) this;
        }

        public Criteria andSafetynoteGreaterThanOrEqualTo(String value) {
            addCriterion("safetyNote >=", value, "safetynote");
            return (Criteria) this;
        }

        public Criteria andSafetynoteLessThan(String value) {
            addCriterion("safetyNote <", value, "safetynote");
            return (Criteria) this;
        }

        public Criteria andSafetynoteLessThanOrEqualTo(String value) {
            addCriterion("safetyNote <=", value, "safetynote");
            return (Criteria) this;
        }

        public Criteria andSafetynoteLike(String value) {
            addCriterion("safetyNote like", value, "safetynote");
            return (Criteria) this;
        }

        public Criteria andSafetynoteNotLike(String value) {
            addCriterion("safetyNote not like", value, "safetynote");
            return (Criteria) this;
        }

        public Criteria andSafetynoteIn(List<String> values) {
            addCriterion("safetyNote in", values, "safetynote");
            return (Criteria) this;
        }

        public Criteria andSafetynoteNotIn(List<String> values) {
            addCriterion("safetyNote not in", values, "safetynote");
            return (Criteria) this;
        }

        public Criteria andSafetynoteBetween(String value1, String value2) {
            addCriterion("safetyNote between", value1, value2, "safetynote");
            return (Criteria) this;
        }

        public Criteria andSafetynoteNotBetween(String value1, String value2) {
            addCriterion("safetyNote not between", value1, value2, "safetynote");
            return (Criteria) this;
        }

        public Criteria andSafetyotherIsNull() {
            addCriterion("safetyOther is null");
            return (Criteria) this;
        }

        public Criteria andSafetyotherIsNotNull() {
            addCriterion("safetyOther is not null");
            return (Criteria) this;
        }

        public Criteria andSafetyotherEqualTo(String value) {
            addCriterion("safetyOther =", value, "safetyother");
            return (Criteria) this;
        }

        public Criteria andSafetyotherNotEqualTo(String value) {
            addCriterion("safetyOther <>", value, "safetyother");
            return (Criteria) this;
        }

        public Criteria andSafetyotherGreaterThan(String value) {
            addCriterion("safetyOther >", value, "safetyother");
            return (Criteria) this;
        }

        public Criteria andSafetyotherGreaterThanOrEqualTo(String value) {
            addCriterion("safetyOther >=", value, "safetyother");
            return (Criteria) this;
        }

        public Criteria andSafetyotherLessThan(String value) {
            addCriterion("safetyOther <", value, "safetyother");
            return (Criteria) this;
        }

        public Criteria andSafetyotherLessThanOrEqualTo(String value) {
            addCriterion("safetyOther <=", value, "safetyother");
            return (Criteria) this;
        }

        public Criteria andSafetyotherLike(String value) {
            addCriterion("safetyOther like", value, "safetyother");
            return (Criteria) this;
        }

        public Criteria andSafetyotherNotLike(String value) {
            addCriterion("safetyOther not like", value, "safetyother");
            return (Criteria) this;
        }

        public Criteria andSafetyotherIn(List<String> values) {
            addCriterion("safetyOther in", values, "safetyother");
            return (Criteria) this;
        }

        public Criteria andSafetyotherNotIn(List<String> values) {
            addCriterion("safetyOther not in", values, "safetyother");
            return (Criteria) this;
        }

        public Criteria andSafetyotherBetween(String value1, String value2) {
            addCriterion("safetyOther between", value1, value2, "safetyother");
            return (Criteria) this;
        }

        public Criteria andSafetyotherNotBetween(String value1, String value2) {
            addCriterion("safetyOther not between", value1, value2, "safetyother");
            return (Criteria) this;
        }

        public Criteria andSafetystatusIsNull() {
            addCriterion("safetyStatus is null");
            return (Criteria) this;
        }

        public Criteria andSafetystatusIsNotNull() {
            addCriterion("safetyStatus is not null");
            return (Criteria) this;
        }

        public Criteria andSafetystatusEqualTo(Integer value) {
            addCriterion("safetyStatus =", value, "safetystatus");
            return (Criteria) this;
        }

        public Criteria andSafetystatusNotEqualTo(Integer value) {
            addCriterion("safetyStatus <>", value, "safetystatus");
            return (Criteria) this;
        }

        public Criteria andSafetystatusGreaterThan(Integer value) {
            addCriterion("safetyStatus >", value, "safetystatus");
            return (Criteria) this;
        }

        public Criteria andSafetystatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("safetyStatus >=", value, "safetystatus");
            return (Criteria) this;
        }

        public Criteria andSafetystatusLessThan(Integer value) {
            addCriterion("safetyStatus <", value, "safetystatus");
            return (Criteria) this;
        }

        public Criteria andSafetystatusLessThanOrEqualTo(Integer value) {
            addCriterion("safetyStatus <=", value, "safetystatus");
            return (Criteria) this;
        }

        public Criteria andSafetystatusIn(List<Integer> values) {
            addCriterion("safetyStatus in", values, "safetystatus");
            return (Criteria) this;
        }

        public Criteria andSafetystatusNotIn(List<Integer> values) {
            addCriterion("safetyStatus not in", values, "safetystatus");
            return (Criteria) this;
        }

        public Criteria andSafetystatusBetween(Integer value1, Integer value2) {
            addCriterion("safetyStatus between", value1, value2, "safetystatus");
            return (Criteria) this;
        }

        public Criteria andSafetystatusNotBetween(Integer value1, Integer value2) {
            addCriterion("safetyStatus not between", value1, value2, "safetystatus");
            return (Criteria) this;
        }

        public Criteria andApprovedateIsNull() {
            addCriterion("approveDate is null");
            return (Criteria) this;
        }

        public Criteria andApprovedateIsNotNull() {
            addCriterion("approveDate is not null");
            return (Criteria) this;
        }

        public Criteria andApprovedateEqualTo(Date value) {
            addCriterion("approveDate =", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateNotEqualTo(Date value) {
            addCriterion("approveDate <>", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateGreaterThan(Date value) {
            addCriterion("approveDate >", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateGreaterThanOrEqualTo(Date value) {
            addCriterion("approveDate >=", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateLessThan(Date value) {
            addCriterion("approveDate <", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateLessThanOrEqualTo(Date value) {
            addCriterion("approveDate <=", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateIn(List<Date> values) {
            addCriterion("approveDate in", values, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateNotIn(List<Date> values) {
            addCriterion("approveDate not in", values, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateBetween(Date value1, Date value2) {
            addCriterion("approveDate between", value1, value2, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateNotBetween(Date value1, Date value2) {
            addCriterion("approveDate not between", value1, value2, "approvedate");
            return (Criteria) this;
        }

        public Criteria andSafetycommentIsNull() {
            addCriterion("safetyComment is null");
            return (Criteria) this;
        }

        public Criteria andSafetycommentIsNotNull() {
            addCriterion("safetyComment is not null");
            return (Criteria) this;
        }

        public Criteria andSafetycommentEqualTo(String value) {
            addCriterion("safetyComment =", value, "safetycomment");
            return (Criteria) this;
        }

        public Criteria andSafetycommentNotEqualTo(String value) {
            addCriterion("safetyComment <>", value, "safetycomment");
            return (Criteria) this;
        }

        public Criteria andSafetycommentGreaterThan(String value) {
            addCriterion("safetyComment >", value, "safetycomment");
            return (Criteria) this;
        }

        public Criteria andSafetycommentGreaterThanOrEqualTo(String value) {
            addCriterion("safetyComment >=", value, "safetycomment");
            return (Criteria) this;
        }

        public Criteria andSafetycommentLessThan(String value) {
            addCriterion("safetyComment <", value, "safetycomment");
            return (Criteria) this;
        }

        public Criteria andSafetycommentLessThanOrEqualTo(String value) {
            addCriterion("safetyComment <=", value, "safetycomment");
            return (Criteria) this;
        }

        public Criteria andSafetycommentLike(String value) {
            addCriterion("safetyComment like", value, "safetycomment");
            return (Criteria) this;
        }

        public Criteria andSafetycommentNotLike(String value) {
            addCriterion("safetyComment not like", value, "safetycomment");
            return (Criteria) this;
        }

        public Criteria andSafetycommentIn(List<String> values) {
            addCriterion("safetyComment in", values, "safetycomment");
            return (Criteria) this;
        }

        public Criteria andSafetycommentNotIn(List<String> values) {
            addCriterion("safetyComment not in", values, "safetycomment");
            return (Criteria) this;
        }

        public Criteria andSafetycommentBetween(String value1, String value2) {
            addCriterion("safetyComment between", value1, value2, "safetycomment");
            return (Criteria) this;
        }

        public Criteria andSafetycommentNotBetween(String value1, String value2) {
            addCriterion("safetyComment not between", value1, value2, "safetycomment");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}