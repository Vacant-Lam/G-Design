package com.cpms.pojo;

import java.util.Date;

public class CpmsMission {
    private Integer missionid;

    private String projectid;

    private String missiontrackerid;

    private String missionname;

    private Date missionstarttime;

    private Date missionendtime;

    private String missioncontent;

    private Date missiondate;

    private Integer missionstatus;

    public Integer getMissionid() {
        return missionid;
    }

    public void setMissionid(Integer missionid) {
        this.missionid = missionid;
    }

    public String getProjectid() {
        return projectid;
    }

    public void setProjectid(String projectid) {
        this.projectid = projectid == null ? null : projectid.trim();
    }

    public String getMissiontrackerid() {
        return missiontrackerid;
    }

    public void setMissiontrackerid(String missiontrackerid) {
        this.missiontrackerid = missiontrackerid == null ? null : missiontrackerid.trim();
    }

    public String getMissionname() {
        return missionname;
    }

    public void setMissionname(String missionname) {
        this.missionname = missionname == null ? null : missionname.trim();
    }

    public Date getMissionstarttime() {
        return missionstarttime;
    }

    public void setMissionstarttime(Date missionstarttime) {
        this.missionstarttime = missionstarttime;
    }

    public Date getMissionendtime() {
        return missionendtime;
    }

    public void setMissionendtime(Date missionendtime) {
        this.missionendtime = missionendtime;
    }

    public String getMissioncontent() {
        return missioncontent;
    }

    public void setMissioncontent(String missioncontent) {
        this.missioncontent = missioncontent == null ? null : missioncontent.trim();
    }

    public Date getMissiondate() {
        return missiondate;
    }

    public void setMissiondate(Date missiondate) {
        this.missiondate = missiondate;
    }

    public Integer getMissionstatus() {
        return missionstatus;
    }

    public void setMissionstatus(Integer missionstatus) {
        this.missionstatus = missionstatus;
    }
}