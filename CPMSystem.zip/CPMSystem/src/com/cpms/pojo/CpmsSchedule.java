package com.cpms.pojo;

import java.util.Date;

public class CpmsSchedule {
    private String scheduleid;

    private String scheduleeditorid;

    private String scheduleapproversid;

    private String schedulename;

    private Date scheduledate;

    private Integer schedulestatus;

    private Date approvedate;

    private String schedulecomment;

    private String scheduleattachment;

    private String attachmenttype;

    private String scheduleremark;

    public String getScheduleid() {
        return scheduleid;
    }

    public void setScheduleid(String scheduleid) {
        this.scheduleid = scheduleid == null ? null : scheduleid.trim();
    }

    public String getScheduleeditorid() {
        return scheduleeditorid;
    }

    public void setScheduleeditorid(String scheduleeditorid) {
        this.scheduleeditorid = scheduleeditorid == null ? null : scheduleeditorid.trim();
    }

    public String getScheduleapproversid() {
        return scheduleapproversid;
    }

    public void setScheduleapproversid(String scheduleapproversid) {
        this.scheduleapproversid = scheduleapproversid == null ? null : scheduleapproversid.trim();
    }

    public String getSchedulename() {
        return schedulename;
    }

    public void setSchedulename(String schedulename) {
        this.schedulename = schedulename == null ? null : schedulename.trim();
    }

    public Date getScheduledate() {
        return scheduledate;
    }

    public void setScheduledate(Date scheduledate) {
        this.scheduledate = scheduledate;
    }

    public Integer getSchedulestatus() {
        return schedulestatus;
    }

    public void setSchedulestatus(Integer schedulestatus) {
        this.schedulestatus = schedulestatus;
    }

    public Date getApprovedate() {
        return approvedate;
    }

    public void setApprovedate(Date approvedate) {
        this.approvedate = approvedate;
    }

    public String getSchedulecomment() {
        return schedulecomment;
    }

    public void setSchedulecomment(String schedulecomment) {
        this.schedulecomment = schedulecomment == null ? null : schedulecomment.trim();
    }

    public String getScheduleattachment() {
        return scheduleattachment;
    }

    public void setScheduleattachment(String scheduleattachment) {
        this.scheduleattachment = scheduleattachment == null ? null : scheduleattachment.trim();
    }

    public String getAttachmenttype() {
        return attachmenttype;
    }

    public void setAttachmenttype(String attachmenttype) {
        this.attachmenttype = attachmenttype == null ? null : attachmenttype.trim();
    }

    public String getScheduleremark() {
        return scheduleremark;
    }

    public void setScheduleremark(String scheduleremark) {
        this.scheduleremark = scheduleremark == null ? null : scheduleremark.trim();
    }
}