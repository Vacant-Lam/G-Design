package com.cpms.pojo;

import java.util.Date;

public class CpmsCost {
    private String costid;

    private String projectid;

    private String costeditorid;

    private String costapproversid;

    private String costname;

    private Date costdate;

    private String costdept;

    private String costattachment;

    private String attachmenttype;

    private String costremark;

    private Double costsum;

    private Integer coststatus;

    private Date approvedate;

    private String costcomment;

    public String getCostid() {
        return costid;
    }

    public void setCostid(String costid) {
        this.costid = costid == null ? null : costid.trim();
    }

    public String getProjectid() {
        return projectid;
    }

    public void setProjectid(String projectid) {
        this.projectid = projectid == null ? null : projectid.trim();
    }

    public String getCosteditorid() {
        return costeditorid;
    }

    public void setCosteditorid(String costeditorid) {
        this.costeditorid = costeditorid == null ? null : costeditorid.trim();
    }

    public String getCostapproversid() {
        return costapproversid;
    }

    public void setCostapproversid(String costapproversid) {
        this.costapproversid = costapproversid == null ? null : costapproversid.trim();
    }

    public String getCostname() {
        return costname;
    }

    public void setCostname(String costname) {
        this.costname = costname == null ? null : costname.trim();
    }

    public Date getCostdate() {
        return costdate;
    }

    public void setCostdate(Date costdate) {
        this.costdate = costdate;
    }

    public String getCostdept() {
        return costdept;
    }

    public void setCostdept(String costdept) {
        this.costdept = costdept == null ? null : costdept.trim();
    }

    public String getCostattachment() {
        return costattachment;
    }

    public void setCostattachment(String costattachment) {
        this.costattachment = costattachment == null ? null : costattachment.trim();
    }

    public String getAttachmenttype() {
        return attachmenttype;
    }

    public void setAttachmenttype(String attachmenttype) {
        this.attachmenttype = attachmenttype == null ? null : attachmenttype.trim();
    }

    public String getCostremark() {
        return costremark;
    }

    public void setCostremark(String costremark) {
        this.costremark = costremark == null ? null : costremark.trim();
    }

    public Double getCostsum() {
        return costsum;
    }

    public void setCostsum(Double costsum) {
        this.costsum = costsum;
    }

    public Integer getCoststatus() {
        return coststatus;
    }

    public void setCoststatus(Integer coststatus) {
        this.coststatus = coststatus;
    }

    public Date getApprovedate() {
        return approvedate;
    }

    public void setApprovedate(Date approvedate) {
        this.approvedate = approvedate;
    }

    public String getCostcomment() {
        return costcomment;
    }

    public void setCostcomment(String costcomment) {
        this.costcomment = costcomment == null ? null : costcomment.trim();
    }
}