package com.cpms.pojo;

import java.util.Date;

public class CpmsSafety {
    private String safetyid;

    private String projectid;

    private String safetyeditorid;

    private String safetyapproversid;

    private Integer safetyattendance;

    private String safetydept;

    private Integer safetytemperature;

    private Date safetydate;

    private String safetypart;

    private String safetycondition;

    private String safetyeducation;

    private String safetyappeal;

    private String safetyaccept;

    private String safetycheck;

    private String safetynote;

    private String safetyother;

    private Integer safetystatus;

    private Date approvedate;

    private String safetycomment;

    public String getSafetyid() {
        return safetyid;
    }

    public void setSafetyid(String safetyid) {
        this.safetyid = safetyid == null ? null : safetyid.trim();
    }

    public String getProjectid() {
        return projectid;
    }

    public void setProjectid(String projectid) {
        this.projectid = projectid == null ? null : projectid.trim();
    }

    public String getSafetyeditorid() {
        return safetyeditorid;
    }

    public void setSafetyeditorid(String safetyeditorid) {
        this.safetyeditorid = safetyeditorid == null ? null : safetyeditorid.trim();
    }

    public String getSafetyapproversid() {
        return safetyapproversid;
    }

    public void setSafetyapproversid(String safetyapproversid) {
        this.safetyapproversid = safetyapproversid == null ? null : safetyapproversid.trim();
    }

    public Integer getSafetyattendance() {
        return safetyattendance;
    }

    public void setSafetyattendance(Integer safetyattendance) {
        this.safetyattendance = safetyattendance;
    }

    public String getSafetydept() {
        return safetydept;
    }

    public void setSafetydept(String safetydept) {
        this.safetydept = safetydept == null ? null : safetydept.trim();
    }

    public Integer getSafetytemperature() {
        return safetytemperature;
    }

    public void setSafetytemperature(Integer safetytemperature) {
        this.safetytemperature = safetytemperature;
    }

    public Date getSafetydate() {
        return safetydate;
    }

    public void setSafetydate(Date safetydate) {
        this.safetydate = safetydate;
    }

    public String getSafetypart() {
        return safetypart;
    }

    public void setSafetypart(String safetypart) {
        this.safetypart = safetypart == null ? null : safetypart.trim();
    }

    public String getSafetycondition() {
        return safetycondition;
    }

    public void setSafetycondition(String safetycondition) {
        this.safetycondition = safetycondition == null ? null : safetycondition.trim();
    }

    public String getSafetyeducation() {
        return safetyeducation;
    }

    public void setSafetyeducation(String safetyeducation) {
        this.safetyeducation = safetyeducation == null ? null : safetyeducation.trim();
    }

    public String getSafetyappeal() {
        return safetyappeal;
    }

    public void setSafetyappeal(String safetyappeal) {
        this.safetyappeal = safetyappeal == null ? null : safetyappeal.trim();
    }

    public String getSafetyaccept() {
        return safetyaccept;
    }

    public void setSafetyaccept(String safetyaccept) {
        this.safetyaccept = safetyaccept == null ? null : safetyaccept.trim();
    }

    public String getSafetycheck() {
        return safetycheck;
    }

    public void setSafetycheck(String safetycheck) {
        this.safetycheck = safetycheck == null ? null : safetycheck.trim();
    }

    public String getSafetynote() {
        return safetynote;
    }

    public void setSafetynote(String safetynote) {
        this.safetynote = safetynote == null ? null : safetynote.trim();
    }

    public String getSafetyother() {
        return safetyother;
    }

    public void setSafetyother(String safetyother) {
        this.safetyother = safetyother == null ? null : safetyother.trim();
    }

    public Integer getSafetystatus() {
        return safetystatus;
    }

    public void setSafetystatus(Integer safetystatus) {
        this.safetystatus = safetystatus;
    }

    public Date getApprovedate() {
        return approvedate;
    }

    public void setApprovedate(Date approvedate) {
        this.approvedate = approvedate;
    }

    public String getSafetycomment() {
        return safetycomment;
    }

    public void setSafetycomment(String safetycomment) {
        this.safetycomment = safetycomment == null ? null : safetycomment.trim();
    }
}