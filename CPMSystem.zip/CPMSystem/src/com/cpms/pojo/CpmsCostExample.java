package com.cpms.pojo;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class CpmsCostExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public CpmsCostExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<java.sql.Date>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andCostidIsNull() {
            addCriterion("costId is null");
            return (Criteria) this;
        }

        public Criteria andCostidIsNotNull() {
            addCriterion("costId is not null");
            return (Criteria) this;
        }

        public Criteria andCostidEqualTo(String value) {
            addCriterion("costId =", value, "costid");
            return (Criteria) this;
        }

        public Criteria andCostidNotEqualTo(String value) {
            addCriterion("costId <>", value, "costid");
            return (Criteria) this;
        }

        public Criteria andCostidGreaterThan(String value) {
            addCriterion("costId >", value, "costid");
            return (Criteria) this;
        }

        public Criteria andCostidGreaterThanOrEqualTo(String value) {
            addCriterion("costId >=", value, "costid");
            return (Criteria) this;
        }

        public Criteria andCostidLessThan(String value) {
            addCriterion("costId <", value, "costid");
            return (Criteria) this;
        }

        public Criteria andCostidLessThanOrEqualTo(String value) {
            addCriterion("costId <=", value, "costid");
            return (Criteria) this;
        }

        public Criteria andCostidLike(String value) {
            addCriterion("costId like", value, "costid");
            return (Criteria) this;
        }

        public Criteria andCostidNotLike(String value) {
            addCriterion("costId not like", value, "costid");
            return (Criteria) this;
        }

        public Criteria andCostidIn(List<String> values) {
            addCriterion("costId in", values, "costid");
            return (Criteria) this;
        }

        public Criteria andCostidNotIn(List<String> values) {
            addCriterion("costId not in", values, "costid");
            return (Criteria) this;
        }

        public Criteria andCostidBetween(String value1, String value2) {
            addCriterion("costId between", value1, value2, "costid");
            return (Criteria) this;
        }

        public Criteria andCostidNotBetween(String value1, String value2) {
            addCriterion("costId not between", value1, value2, "costid");
            return (Criteria) this;
        }

        public Criteria andProjectidIsNull() {
            addCriterion("projectId is null");
            return (Criteria) this;
        }

        public Criteria andProjectidIsNotNull() {
            addCriterion("projectId is not null");
            return (Criteria) this;
        }

        public Criteria andProjectidEqualTo(String value) {
            addCriterion("projectId =", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidNotEqualTo(String value) {
            addCriterion("projectId <>", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidGreaterThan(String value) {
            addCriterion("projectId >", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidGreaterThanOrEqualTo(String value) {
            addCriterion("projectId >=", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidLessThan(String value) {
            addCriterion("projectId <", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidLessThanOrEqualTo(String value) {
            addCriterion("projectId <=", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidLike(String value) {
            addCriterion("projectId like", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidNotLike(String value) {
            addCriterion("projectId not like", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidIn(List<String> values) {
            addCriterion("projectId in", values, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidNotIn(List<String> values) {
            addCriterion("projectId not in", values, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidBetween(String value1, String value2) {
            addCriterion("projectId between", value1, value2, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidNotBetween(String value1, String value2) {
            addCriterion("projectId not between", value1, value2, "projectid");
            return (Criteria) this;
        }

        public Criteria andCosteditoridIsNull() {
            addCriterion("costEditorId is null");
            return (Criteria) this;
        }

        public Criteria andCosteditoridIsNotNull() {
            addCriterion("costEditorId is not null");
            return (Criteria) this;
        }

        public Criteria andCosteditoridEqualTo(String value) {
            addCriterion("costEditorId =", value, "costeditorid");
            return (Criteria) this;
        }

        public Criteria andCosteditoridNotEqualTo(String value) {
            addCriterion("costEditorId <>", value, "costeditorid");
            return (Criteria) this;
        }

        public Criteria andCosteditoridGreaterThan(String value) {
            addCriterion("costEditorId >", value, "costeditorid");
            return (Criteria) this;
        }

        public Criteria andCosteditoridGreaterThanOrEqualTo(String value) {
            addCriterion("costEditorId >=", value, "costeditorid");
            return (Criteria) this;
        }

        public Criteria andCosteditoridLessThan(String value) {
            addCriterion("costEditorId <", value, "costeditorid");
            return (Criteria) this;
        }

        public Criteria andCosteditoridLessThanOrEqualTo(String value) {
            addCriterion("costEditorId <=", value, "costeditorid");
            return (Criteria) this;
        }

        public Criteria andCosteditoridLike(String value) {
            addCriterion("costEditorId like", value, "costeditorid");
            return (Criteria) this;
        }

        public Criteria andCosteditoridNotLike(String value) {
            addCriterion("costEditorId not like", value, "costeditorid");
            return (Criteria) this;
        }

        public Criteria andCosteditoridIn(List<String> values) {
            addCriterion("costEditorId in", values, "costeditorid");
            return (Criteria) this;
        }

        public Criteria andCosteditoridNotIn(List<String> values) {
            addCriterion("costEditorId not in", values, "costeditorid");
            return (Criteria) this;
        }

        public Criteria andCosteditoridBetween(String value1, String value2) {
            addCriterion("costEditorId between", value1, value2, "costeditorid");
            return (Criteria) this;
        }

        public Criteria andCosteditoridNotBetween(String value1, String value2) {
            addCriterion("costEditorId not between", value1, value2, "costeditorid");
            return (Criteria) this;
        }

        public Criteria andCostapproversidIsNull() {
            addCriterion("costApproversId is null");
            return (Criteria) this;
        }

        public Criteria andCostapproversidIsNotNull() {
            addCriterion("costApproversId is not null");
            return (Criteria) this;
        }

        public Criteria andCostapproversidEqualTo(String value) {
            addCriterion("costApproversId =", value, "costapproversid");
            return (Criteria) this;
        }

        public Criteria andCostapproversidNotEqualTo(String value) {
            addCriterion("costApproversId <>", value, "costapproversid");
            return (Criteria) this;
        }

        public Criteria andCostapproversidGreaterThan(String value) {
            addCriterion("costApproversId >", value, "costapproversid");
            return (Criteria) this;
        }

        public Criteria andCostapproversidGreaterThanOrEqualTo(String value) {
            addCriterion("costApproversId >=", value, "costapproversid");
            return (Criteria) this;
        }

        public Criteria andCostapproversidLessThan(String value) {
            addCriterion("costApproversId <", value, "costapproversid");
            return (Criteria) this;
        }

        public Criteria andCostapproversidLessThanOrEqualTo(String value) {
            addCriterion("costApproversId <=", value, "costapproversid");
            return (Criteria) this;
        }

        public Criteria andCostapproversidLike(String value) {
            addCriterion("costApproversId like", value, "costapproversid");
            return (Criteria) this;
        }

        public Criteria andCostapproversidNotLike(String value) {
            addCriterion("costApproversId not like", value, "costapproversid");
            return (Criteria) this;
        }

        public Criteria andCostapproversidIn(List<String> values) {
            addCriterion("costApproversId in", values, "costapproversid");
            return (Criteria) this;
        }

        public Criteria andCostapproversidNotIn(List<String> values) {
            addCriterion("costApproversId not in", values, "costapproversid");
            return (Criteria) this;
        }

        public Criteria andCostapproversidBetween(String value1, String value2) {
            addCriterion("costApproversId between", value1, value2, "costapproversid");
            return (Criteria) this;
        }

        public Criteria andCostapproversidNotBetween(String value1, String value2) {
            addCriterion("costApproversId not between", value1, value2, "costapproversid");
            return (Criteria) this;
        }

        public Criteria andCostnameIsNull() {
            addCriterion("costName is null");
            return (Criteria) this;
        }

        public Criteria andCostnameIsNotNull() {
            addCriterion("costName is not null");
            return (Criteria) this;
        }

        public Criteria andCostnameEqualTo(String value) {
            addCriterion("costName =", value, "costname");
            return (Criteria) this;
        }

        public Criteria andCostnameNotEqualTo(String value) {
            addCriterion("costName <>", value, "costname");
            return (Criteria) this;
        }

        public Criteria andCostnameGreaterThan(String value) {
            addCriterion("costName >", value, "costname");
            return (Criteria) this;
        }

        public Criteria andCostnameGreaterThanOrEqualTo(String value) {
            addCriterion("costName >=", value, "costname");
            return (Criteria) this;
        }

        public Criteria andCostnameLessThan(String value) {
            addCriterion("costName <", value, "costname");
            return (Criteria) this;
        }

        public Criteria andCostnameLessThanOrEqualTo(String value) {
            addCriterion("costName <=", value, "costname");
            return (Criteria) this;
        }

        public Criteria andCostnameLike(String value) {
            addCriterion("costName like", value, "costname");
            return (Criteria) this;
        }

        public Criteria andCostnameNotLike(String value) {
            addCriterion("costName not like", value, "costname");
            return (Criteria) this;
        }

        public Criteria andCostnameIn(List<String> values) {
            addCriterion("costName in", values, "costname");
            return (Criteria) this;
        }

        public Criteria andCostnameNotIn(List<String> values) {
            addCriterion("costName not in", values, "costname");
            return (Criteria) this;
        }

        public Criteria andCostnameBetween(String value1, String value2) {
            addCriterion("costName between", value1, value2, "costname");
            return (Criteria) this;
        }

        public Criteria andCostnameNotBetween(String value1, String value2) {
            addCriterion("costName not between", value1, value2, "costname");
            return (Criteria) this;
        }

        public Criteria andCostdateIsNull() {
            addCriterion("costDate is null");
            return (Criteria) this;
        }

        public Criteria andCostdateIsNotNull() {
            addCriterion("costDate is not null");
            return (Criteria) this;
        }

        public Criteria andCostdateEqualTo(Date value) {
            addCriterionForJDBCDate("costDate =", value, "costdate");
            return (Criteria) this;
        }

        public Criteria andCostdateNotEqualTo(Date value) {
            addCriterionForJDBCDate("costDate <>", value, "costdate");
            return (Criteria) this;
        }

        public Criteria andCostdateGreaterThan(Date value) {
            addCriterionForJDBCDate("costDate >", value, "costdate");
            return (Criteria) this;
        }

        public Criteria andCostdateGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("costDate >=", value, "costdate");
            return (Criteria) this;
        }

        public Criteria andCostdateLessThan(Date value) {
            addCriterionForJDBCDate("costDate <", value, "costdate");
            return (Criteria) this;
        }

        public Criteria andCostdateLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("costDate <=", value, "costdate");
            return (Criteria) this;
        }

        public Criteria andCostdateIn(List<Date> values) {
            addCriterionForJDBCDate("costDate in", values, "costdate");
            return (Criteria) this;
        }

        public Criteria andCostdateNotIn(List<Date> values) {
            addCriterionForJDBCDate("costDate not in", values, "costdate");
            return (Criteria) this;
        }

        public Criteria andCostdateBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("costDate between", value1, value2, "costdate");
            return (Criteria) this;
        }

        public Criteria andCostdateNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("costDate not between", value1, value2, "costdate");
            return (Criteria) this;
        }

        public Criteria andCostdeptIsNull() {
            addCriterion("costDept is null");
            return (Criteria) this;
        }

        public Criteria andCostdeptIsNotNull() {
            addCriterion("costDept is not null");
            return (Criteria) this;
        }

        public Criteria andCostdeptEqualTo(String value) {
            addCriterion("costDept =", value, "costdept");
            return (Criteria) this;
        }

        public Criteria andCostdeptNotEqualTo(String value) {
            addCriterion("costDept <>", value, "costdept");
            return (Criteria) this;
        }

        public Criteria andCostdeptGreaterThan(String value) {
            addCriterion("costDept >", value, "costdept");
            return (Criteria) this;
        }

        public Criteria andCostdeptGreaterThanOrEqualTo(String value) {
            addCriterion("costDept >=", value, "costdept");
            return (Criteria) this;
        }

        public Criteria andCostdeptLessThan(String value) {
            addCriterion("costDept <", value, "costdept");
            return (Criteria) this;
        }

        public Criteria andCostdeptLessThanOrEqualTo(String value) {
            addCriterion("costDept <=", value, "costdept");
            return (Criteria) this;
        }

        public Criteria andCostdeptLike(String value) {
            addCriterion("costDept like", value, "costdept");
            return (Criteria) this;
        }

        public Criteria andCostdeptNotLike(String value) {
            addCriterion("costDept not like", value, "costdept");
            return (Criteria) this;
        }

        public Criteria andCostdeptIn(List<String> values) {
            addCriterion("costDept in", values, "costdept");
            return (Criteria) this;
        }

        public Criteria andCostdeptNotIn(List<String> values) {
            addCriterion("costDept not in", values, "costdept");
            return (Criteria) this;
        }

        public Criteria andCostdeptBetween(String value1, String value2) {
            addCriterion("costDept between", value1, value2, "costdept");
            return (Criteria) this;
        }

        public Criteria andCostdeptNotBetween(String value1, String value2) {
            addCriterion("costDept not between", value1, value2, "costdept");
            return (Criteria) this;
        }

        public Criteria andCostattachmentIsNull() {
            addCriterion("costAttachment is null");
            return (Criteria) this;
        }

        public Criteria andCostattachmentIsNotNull() {
            addCriterion("costAttachment is not null");
            return (Criteria) this;
        }

        public Criteria andCostattachmentEqualTo(String value) {
            addCriterion("costAttachment =", value, "costattachment");
            return (Criteria) this;
        }

        public Criteria andCostattachmentNotEqualTo(String value) {
            addCriterion("costAttachment <>", value, "costattachment");
            return (Criteria) this;
        }

        public Criteria andCostattachmentGreaterThan(String value) {
            addCriterion("costAttachment >", value, "costattachment");
            return (Criteria) this;
        }

        public Criteria andCostattachmentGreaterThanOrEqualTo(String value) {
            addCriterion("costAttachment >=", value, "costattachment");
            return (Criteria) this;
        }

        public Criteria andCostattachmentLessThan(String value) {
            addCriterion("costAttachment <", value, "costattachment");
            return (Criteria) this;
        }

        public Criteria andCostattachmentLessThanOrEqualTo(String value) {
            addCriterion("costAttachment <=", value, "costattachment");
            return (Criteria) this;
        }

        public Criteria andCostattachmentLike(String value) {
            addCriterion("costAttachment like", value, "costattachment");
            return (Criteria) this;
        }

        public Criteria andCostattachmentNotLike(String value) {
            addCriterion("costAttachment not like", value, "costattachment");
            return (Criteria) this;
        }

        public Criteria andCostattachmentIn(List<String> values) {
            addCriterion("costAttachment in", values, "costattachment");
            return (Criteria) this;
        }

        public Criteria andCostattachmentNotIn(List<String> values) {
            addCriterion("costAttachment not in", values, "costattachment");
            return (Criteria) this;
        }

        public Criteria andCostattachmentBetween(String value1, String value2) {
            addCriterion("costAttachment between", value1, value2, "costattachment");
            return (Criteria) this;
        }

        public Criteria andCostattachmentNotBetween(String value1, String value2) {
            addCriterion("costAttachment not between", value1, value2, "costattachment");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeIsNull() {
            addCriterion("attachmentType is null");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeIsNotNull() {
            addCriterion("attachmentType is not null");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeEqualTo(String value) {
            addCriterion("attachmentType =", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeNotEqualTo(String value) {
            addCriterion("attachmentType <>", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeGreaterThan(String value) {
            addCriterion("attachmentType >", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeGreaterThanOrEqualTo(String value) {
            addCriterion("attachmentType >=", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeLessThan(String value) {
            addCriterion("attachmentType <", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeLessThanOrEqualTo(String value) {
            addCriterion("attachmentType <=", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeLike(String value) {
            addCriterion("attachmentType like", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeNotLike(String value) {
            addCriterion("attachmentType not like", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeIn(List<String> values) {
            addCriterion("attachmentType in", values, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeNotIn(List<String> values) {
            addCriterion("attachmentType not in", values, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeBetween(String value1, String value2) {
            addCriterion("attachmentType between", value1, value2, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeNotBetween(String value1, String value2) {
            addCriterion("attachmentType not between", value1, value2, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andCostremarkIsNull() {
            addCriterion("costRemark is null");
            return (Criteria) this;
        }

        public Criteria andCostremarkIsNotNull() {
            addCriterion("costRemark is not null");
            return (Criteria) this;
        }

        public Criteria andCostremarkEqualTo(String value) {
            addCriterion("costRemark =", value, "costremark");
            return (Criteria) this;
        }

        public Criteria andCostremarkNotEqualTo(String value) {
            addCriterion("costRemark <>", value, "costremark");
            return (Criteria) this;
        }

        public Criteria andCostremarkGreaterThan(String value) {
            addCriterion("costRemark >", value, "costremark");
            return (Criteria) this;
        }

        public Criteria andCostremarkGreaterThanOrEqualTo(String value) {
            addCriterion("costRemark >=", value, "costremark");
            return (Criteria) this;
        }

        public Criteria andCostremarkLessThan(String value) {
            addCriterion("costRemark <", value, "costremark");
            return (Criteria) this;
        }

        public Criteria andCostremarkLessThanOrEqualTo(String value) {
            addCriterion("costRemark <=", value, "costremark");
            return (Criteria) this;
        }

        public Criteria andCostremarkLike(String value) {
            addCriterion("costRemark like", value, "costremark");
            return (Criteria) this;
        }

        public Criteria andCostremarkNotLike(String value) {
            addCriterion("costRemark not like", value, "costremark");
            return (Criteria) this;
        }

        public Criteria andCostremarkIn(List<String> values) {
            addCriterion("costRemark in", values, "costremark");
            return (Criteria) this;
        }

        public Criteria andCostremarkNotIn(List<String> values) {
            addCriterion("costRemark not in", values, "costremark");
            return (Criteria) this;
        }

        public Criteria andCostremarkBetween(String value1, String value2) {
            addCriterion("costRemark between", value1, value2, "costremark");
            return (Criteria) this;
        }

        public Criteria andCostremarkNotBetween(String value1, String value2) {
            addCriterion("costRemark not between", value1, value2, "costremark");
            return (Criteria) this;
        }

        public Criteria andCostsumIsNull() {
            addCriterion("costSum is null");
            return (Criteria) this;
        }

        public Criteria andCostsumIsNotNull() {
            addCriterion("costSum is not null");
            return (Criteria) this;
        }

        public Criteria andCostsumEqualTo(Double value) {
            addCriterion("costSum =", value, "costsum");
            return (Criteria) this;
        }

        public Criteria andCostsumNotEqualTo(Double value) {
            addCriterion("costSum <>", value, "costsum");
            return (Criteria) this;
        }

        public Criteria andCostsumGreaterThan(Double value) {
            addCriterion("costSum >", value, "costsum");
            return (Criteria) this;
        }

        public Criteria andCostsumGreaterThanOrEqualTo(Double value) {
            addCriterion("costSum >=", value, "costsum");
            return (Criteria) this;
        }

        public Criteria andCostsumLessThan(Double value) {
            addCriterion("costSum <", value, "costsum");
            return (Criteria) this;
        }

        public Criteria andCostsumLessThanOrEqualTo(Double value) {
            addCriterion("costSum <=", value, "costsum");
            return (Criteria) this;
        }

        public Criteria andCostsumIn(List<Double> values) {
            addCriterion("costSum in", values, "costsum");
            return (Criteria) this;
        }

        public Criteria andCostsumNotIn(List<Double> values) {
            addCriterion("costSum not in", values, "costsum");
            return (Criteria) this;
        }

        public Criteria andCostsumBetween(Double value1, Double value2) {
            addCriterion("costSum between", value1, value2, "costsum");
            return (Criteria) this;
        }

        public Criteria andCostsumNotBetween(Double value1, Double value2) {
            addCriterion("costSum not between", value1, value2, "costsum");
            return (Criteria) this;
        }

        public Criteria andCoststatusIsNull() {
            addCriterion("costStatus is null");
            return (Criteria) this;
        }

        public Criteria andCoststatusIsNotNull() {
            addCriterion("costStatus is not null");
            return (Criteria) this;
        }

        public Criteria andCoststatusEqualTo(Integer value) {
            addCriterion("costStatus =", value, "coststatus");
            return (Criteria) this;
        }

        public Criteria andCoststatusNotEqualTo(Integer value) {
            addCriterion("costStatus <>", value, "coststatus");
            return (Criteria) this;
        }

        public Criteria andCoststatusGreaterThan(Integer value) {
            addCriterion("costStatus >", value, "coststatus");
            return (Criteria) this;
        }

        public Criteria andCoststatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("costStatus >=", value, "coststatus");
            return (Criteria) this;
        }

        public Criteria andCoststatusLessThan(Integer value) {
            addCriterion("costStatus <", value, "coststatus");
            return (Criteria) this;
        }

        public Criteria andCoststatusLessThanOrEqualTo(Integer value) {
            addCriterion("costStatus <=", value, "coststatus");
            return (Criteria) this;
        }

        public Criteria andCoststatusIn(List<Integer> values) {
            addCriterion("costStatus in", values, "coststatus");
            return (Criteria) this;
        }

        public Criteria andCoststatusNotIn(List<Integer> values) {
            addCriterion("costStatus not in", values, "coststatus");
            return (Criteria) this;
        }

        public Criteria andCoststatusBetween(Integer value1, Integer value2) {
            addCriterion("costStatus between", value1, value2, "coststatus");
            return (Criteria) this;
        }

        public Criteria andCoststatusNotBetween(Integer value1, Integer value2) {
            addCriterion("costStatus not between", value1, value2, "coststatus");
            return (Criteria) this;
        }

        public Criteria andApprovedateIsNull() {
            addCriterion("approveDate is null");
            return (Criteria) this;
        }

        public Criteria andApprovedateIsNotNull() {
            addCriterion("approveDate is not null");
            return (Criteria) this;
        }

        public Criteria andApprovedateEqualTo(Date value) {
            addCriterion("approveDate =", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateNotEqualTo(Date value) {
            addCriterion("approveDate <>", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateGreaterThan(Date value) {
            addCriterion("approveDate >", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateGreaterThanOrEqualTo(Date value) {
            addCriterion("approveDate >=", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateLessThan(Date value) {
            addCriterion("approveDate <", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateLessThanOrEqualTo(Date value) {
            addCriterion("approveDate <=", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateIn(List<Date> values) {
            addCriterion("approveDate in", values, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateNotIn(List<Date> values) {
            addCriterion("approveDate not in", values, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateBetween(Date value1, Date value2) {
            addCriterion("approveDate between", value1, value2, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateNotBetween(Date value1, Date value2) {
            addCriterion("approveDate not between", value1, value2, "approvedate");
            return (Criteria) this;
        }

        public Criteria andCostcommentIsNull() {
            addCriterion("costComment is null");
            return (Criteria) this;
        }

        public Criteria andCostcommentIsNotNull() {
            addCriterion("costComment is not null");
            return (Criteria) this;
        }

        public Criteria andCostcommentEqualTo(String value) {
            addCriterion("costComment =", value, "costcomment");
            return (Criteria) this;
        }

        public Criteria andCostcommentNotEqualTo(String value) {
            addCriterion("costComment <>", value, "costcomment");
            return (Criteria) this;
        }

        public Criteria andCostcommentGreaterThan(String value) {
            addCriterion("costComment >", value, "costcomment");
            return (Criteria) this;
        }

        public Criteria andCostcommentGreaterThanOrEqualTo(String value) {
            addCriterion("costComment >=", value, "costcomment");
            return (Criteria) this;
        }

        public Criteria andCostcommentLessThan(String value) {
            addCriterion("costComment <", value, "costcomment");
            return (Criteria) this;
        }

        public Criteria andCostcommentLessThanOrEqualTo(String value) {
            addCriterion("costComment <=", value, "costcomment");
            return (Criteria) this;
        }

        public Criteria andCostcommentLike(String value) {
            addCriterion("costComment like", value, "costcomment");
            return (Criteria) this;
        }

        public Criteria andCostcommentNotLike(String value) {
            addCriterion("costComment not like", value, "costcomment");
            return (Criteria) this;
        }

        public Criteria andCostcommentIn(List<String> values) {
            addCriterion("costComment in", values, "costcomment");
            return (Criteria) this;
        }

        public Criteria andCostcommentNotIn(List<String> values) {
            addCriterion("costComment not in", values, "costcomment");
            return (Criteria) this;
        }

        public Criteria andCostcommentBetween(String value1, String value2) {
            addCriterion("costComment between", value1, value2, "costcomment");
            return (Criteria) this;
        }

        public Criteria andCostcommentNotBetween(String value1, String value2) {
            addCriterion("costComment not between", value1, value2, "costcomment");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}