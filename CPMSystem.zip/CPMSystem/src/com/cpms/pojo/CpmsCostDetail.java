package com.cpms.pojo;

public class CpmsCostDetail {
    private Integer costdetailid;

    private String costid;

    private String costsubject;

    private Double costaccount;

    private String costdetail;

    public Integer getCostdetailid() {
        return costdetailid;
    }

    public void setCostdetailid(Integer costdetailid) {
        this.costdetailid = costdetailid;
    }

    public String getCostid() {
        return costid;
    }

    public void setCostid(String costid) {
        this.costid = costid == null ? null : costid.trim();
    }

    public String getCostsubject() {
        return costsubject;
    }

    public void setCostsubject(String costsubject) {
        this.costsubject = costsubject == null ? null : costsubject.trim();
    }

    public Double getCostaccount() {
        return costaccount;
    }

    public void setCostaccount(Double costaccount) {
        this.costaccount = costaccount;
    }

    public String getCostdetail() {
        return costdetail;
    }

    public void setCostdetail(String costdetail) {
        this.costdetail = costdetail == null ? null : costdetail.trim();
    }
}