package com.cpms.pojo;

import java.util.Date;

public class CpmsDiary {
    private String diaryid;

    private String projectid;

    private String diaryeditorid;

    private String diaryapproversid;

    private Date diarydate;

    private String diaryamweather;

    private String diarypmweather;

    private Integer diaryhighesttemp;

    private Integer diarylowesttemp;

    private String diaryattachment;

    private String attachmenttype;

    private String diarypic;

    private String diarypictype;

    private Integer diarystatus;

    private Date approvedate;

    private String diarycomment;

    public String getDiaryid() {
        return diaryid;
    }

    public void setDiaryid(String diaryid) {
        this.diaryid = diaryid == null ? null : diaryid.trim();
    }

    public String getProjectid() {
        return projectid;
    }

    public void setProjectid(String projectid) {
        this.projectid = projectid == null ? null : projectid.trim();
    }

    public String getDiaryeditorid() {
        return diaryeditorid;
    }

    public void setDiaryeditorid(String diaryeditorid) {
        this.diaryeditorid = diaryeditorid == null ? null : diaryeditorid.trim();
    }

    public String getDiaryapproversid() {
        return diaryapproversid;
    }

    public void setDiaryapproversid(String diaryapproversid) {
        this.diaryapproversid = diaryapproversid == null ? null : diaryapproversid.trim();
    }

    public Date getDiarydate() {
        return diarydate;
    }

    public void setDiarydate(Date diarydate) {
        this.diarydate = diarydate;
    }

    public String getDiaryamweather() {
        return diaryamweather;
    }

    public void setDiaryamweather(String diaryamweather) {
        this.diaryamweather = diaryamweather;
    }

    public String getDiarypmweather() {
        return diarypmweather;
    }

    public void setDiarypmweather(String diarypmweather) {
        this.diarypmweather = diarypmweather;
    }

    public Integer getDiaryhighesttemp() {
        return diaryhighesttemp;
    }

    public void setDiaryhighesttemp(Integer diaryhighesttemp) {
        this.diaryhighesttemp = diaryhighesttemp;
    }

    public Integer getDiarylowesttemp() {
        return diarylowesttemp;
    }

    public void setDiarylowesttemp(Integer diarylowesttemp) {
        this.diarylowesttemp = diarylowesttemp;
    }

    public String getDiaryattachment() {
        return diaryattachment;
    }

    public void setDiaryattachment(String diaryattachment) {
        this.diaryattachment = diaryattachment == null ? null : diaryattachment.trim();
    }

    public String getAttachmenttype() {
        return attachmenttype;
    }

    public void setAttachmenttype(String attachmenttype) {
        this.attachmenttype = attachmenttype == null ? null : attachmenttype.trim();
    }

    public String getDiarypic() {
        return diarypic;
    }

    public void setDiarypic(String diarypic) {
        this.diarypic = diarypic == null ? null : diarypic.trim();
    }

    public String getDiarypictype() {
        return diarypictype;
    }

    public void setDiarypictype(String diarypictype) {
        this.diarypictype = diarypictype == null ? null : diarypictype.trim();
    }

    public Integer getDiarystatus() {
        return diarystatus;
    }

    public void setDiarystatus(Integer diarystatus) {
        this.diarystatus = diarystatus;
    }

    public Date getApprovedate() {
        return approvedate;
    }

    public void setApprovedate(Date approvedate) {
        this.approvedate = approvedate;
    }

    public String getDiarycomment() {
        return diarycomment;
    }

    public void setDiarycomment(String diarycomment) {
        this.diarycomment = diarycomment == null ? null : diarycomment.trim();
    }
}