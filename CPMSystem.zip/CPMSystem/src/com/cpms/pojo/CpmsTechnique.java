package com.cpms.pojo;

import java.util.Date;

public class CpmsTechnique {
    private String techniqueid;

    private String projectid;

    private String techniqueeditorid;

    private String techniqueapproversid;

    private String techniquename;

    private String techniqueunit;

    private Date techniquedate;

    private String techniqueplace;

    private String techniquecommitter;

    private String techniquecommitted;

    private String techniqueattachment;

    private String attachmenttype;

    private String techniquecontent;

    private String techniqueremark;

    private Integer techniquestatus;

    private Date approvedate;

    private String techniquecomment;

    public String getTechniqueid() {
        return techniqueid;
    }

    public void setTechniqueid(String techniqueid) {
        this.techniqueid = techniqueid == null ? null : techniqueid.trim();
    }

    public String getProjectid() {
        return projectid;
    }

    public void setProjectid(String projectid) {
        this.projectid = projectid == null ? null : projectid.trim();
    }

    public String getTechniqueeditorid() {
        return techniqueeditorid;
    }

    public void setTechniqueeditorid(String techniqueeditorid) {
        this.techniqueeditorid = techniqueeditorid == null ? null : techniqueeditorid.trim();
    }

    public String getTechniqueapproversid() {
        return techniqueapproversid;
    }

    public void setTechniqueapproversid(String techniqueapproversid) {
        this.techniqueapproversid = techniqueapproversid == null ? null : techniqueapproversid.trim();
    }

    public String getTechniquename() {
        return techniquename;
    }

    public void setTechniquename(String techniquename) {
        this.techniquename = techniquename == null ? null : techniquename.trim();
    }

    public String getTechniqueunit() {
        return techniqueunit;
    }

    public void setTechniqueunit(String techniqueunit) {
        this.techniqueunit = techniqueunit == null ? null : techniqueunit.trim();
    }

    public Date getTechniquedate() {
        return techniquedate;
    }

    public void setTechniquedate(Date techniquedate) {
        this.techniquedate = techniquedate;
    }

    public String getTechniqueplace() {
        return techniqueplace;
    }

    public void setTechniqueplace(String techniqueplace) {
        this.techniqueplace = techniqueplace == null ? null : techniqueplace.trim();
    }

    public String getTechniquecommitter() {
        return techniquecommitter;
    }

    public void setTechniquecommitter(String techniquecommitter) {
        this.techniquecommitter = techniquecommitter == null ? null : techniquecommitter.trim();
    }

    public String getTechniquecommitted() {
        return techniquecommitted;
    }

    public void setTechniquecommitted(String techniquecommitted) {
        this.techniquecommitted = techniquecommitted == null ? null : techniquecommitted.trim();
    }

    public String getTechniqueattachment() {
        return techniqueattachment;
    }

    public void setTechniqueattachment(String techniqueattachment) {
        this.techniqueattachment = techniqueattachment == null ? null : techniqueattachment.trim();
    }

    public String getAttachmenttype() {
        return attachmenttype;
    }

    public void setAttachmenttype(String attachmenttype) {
        this.attachmenttype = attachmenttype == null ? null : attachmenttype.trim();
    }

    public String getTechniquecontent() {
        return techniquecontent;
    }

    public void setTechniquecontent(String techniquecontent) {
        this.techniquecontent = techniquecontent == null ? null : techniquecontent.trim();
    }

    public String getTechniqueremark() {
        return techniqueremark;
    }

    public void setTechniqueremark(String techniqueremark) {
        this.techniqueremark = techniqueremark == null ? null : techniqueremark.trim();
    }

    public Integer getTechniquestatus() {
        return techniquestatus;
    }

    public void setTechniquestatus(Integer techniquestatus) {
        this.techniquestatus = techniquestatus;
    }

    public Date getApprovedate() {
        return approvedate;
    }

    public void setApprovedate(Date approvedate) {
        this.approvedate = approvedate;
    }

    public String getTechniquecomment() {
        return techniquecomment;
    }

    public void setTechniquecomment(String techniquecomment) {
        this.techniquecomment = techniquecomment == null ? null : techniquecomment.trim();
    }
}