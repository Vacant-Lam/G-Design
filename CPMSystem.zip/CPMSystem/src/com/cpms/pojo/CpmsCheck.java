package com.cpms.pojo;

import java.util.Date;

public class CpmsCheck {
    private String checkid;

    private String projectid;

    private String checkapproversid;

    private String checkinspector;

    private Date checkdate;

    private String checkpart;

    private String checkcondition;

    private String checkmeasure;

    private String checkattachment;

    private String attachmenttype;

    private String checkremark;

    private Integer checkstatus;

    private Date approvedate;

    private String checkcomment;

    public String getCheckid() {
        return checkid;
    }

    public void setCheckid(String checkid) {
        this.checkid = checkid == null ? null : checkid.trim();
    }

    public String getProjectid() {
        return projectid;
    }

    public void setProjectid(String projectid) {
        this.projectid = projectid == null ? null : projectid.trim();
    }

    public String getCheckapproversid() {
        return checkapproversid;
    }

    public void setCheckapproversid(String checkapproversid) {
        this.checkapproversid = checkapproversid == null ? null : checkapproversid.trim();
    }

    public String getCheckinspector() {
        return checkinspector;
    }

    public void setCheckinspector(String checkinspector) {
        this.checkinspector = checkinspector == null ? null : checkinspector.trim();
    }

    public Date getCheckdate() {
        return checkdate;
    }

    public void setCheckdate(Date checkdate) {
        this.checkdate = checkdate;
    }

    public String getCheckpart() {
        return checkpart;
    }

    public void setCheckpart(String checkpart) {
        this.checkpart = checkpart == null ? null : checkpart.trim();
    }

    public String getCheckcondition() {
        return checkcondition;
    }

    public void setCheckcondition(String checkcondition) {
        this.checkcondition = checkcondition == null ? null : checkcondition.trim();
    }

    public String getCheckmeasure() {
        return checkmeasure;
    }

    public void setCheckmeasure(String checkmeasure) {
        this.checkmeasure = checkmeasure == null ? null : checkmeasure.trim();
    }

    public String getCheckattachment() {
        return checkattachment;
    }

    public void setCheckattachment(String checkattachment) {
        this.checkattachment = checkattachment == null ? null : checkattachment.trim();
    }

    public String getAttachmenttype() {
        return attachmenttype;
    }

    public void setAttachmenttype(String attachmenttype) {
        this.attachmenttype = attachmenttype == null ? null : attachmenttype.trim();
    }

    public String getCheckremark() {
        return checkremark;
    }

    public void setCheckremark(String checkremark) {
        this.checkremark = checkremark == null ? null : checkremark.trim();
    }

    public Integer getCheckstatus() {
        return checkstatus;
    }

    public void setCheckstatus(Integer checkstatus) {
        this.checkstatus = checkstatus;
    }

    public Date getApprovedate() {
        return approvedate;
    }

    public void setApprovedate(Date approvedate) {
        this.approvedate = approvedate;
    }

    public String getCheckcomment() {
        return checkcomment;
    }

    public void setCheckcomment(String checkcomment) {
        this.checkcomment = checkcomment == null ? null : checkcomment.trim();
    }
}