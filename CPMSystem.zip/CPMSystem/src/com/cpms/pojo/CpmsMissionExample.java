package com.cpms.pojo;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class CpmsMissionExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public CpmsMissionExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<java.sql.Date>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andMissionidIsNull() {
            addCriterion("missionId is null");
            return (Criteria) this;
        }

        public Criteria andMissionidIsNotNull() {
            addCriterion("missionId is not null");
            return (Criteria) this;
        }

        public Criteria andMissionidEqualTo(Integer value) {
            addCriterion("missionId =", value, "missionid");
            return (Criteria) this;
        }

        public Criteria andMissionidNotEqualTo(Integer value) {
            addCriterion("missionId <>", value, "missionid");
            return (Criteria) this;
        }

        public Criteria andMissionidGreaterThan(Integer value) {
            addCriterion("missionId >", value, "missionid");
            return (Criteria) this;
        }

        public Criteria andMissionidGreaterThanOrEqualTo(Integer value) {
            addCriterion("missionId >=", value, "missionid");
            return (Criteria) this;
        }

        public Criteria andMissionidLessThan(Integer value) {
            addCriterion("missionId <", value, "missionid");
            return (Criteria) this;
        }

        public Criteria andMissionidLessThanOrEqualTo(Integer value) {
            addCriterion("missionId <=", value, "missionid");
            return (Criteria) this;
        }

        public Criteria andMissionidIn(List<Integer> values) {
            addCriterion("missionId in", values, "missionid");
            return (Criteria) this;
        }

        public Criteria andMissionidNotIn(List<Integer> values) {
            addCriterion("missionId not in", values, "missionid");
            return (Criteria) this;
        }

        public Criteria andMissionidBetween(Integer value1, Integer value2) {
            addCriterion("missionId between", value1, value2, "missionid");
            return (Criteria) this;
        }

        public Criteria andMissionidNotBetween(Integer value1, Integer value2) {
            addCriterion("missionId not between", value1, value2, "missionid");
            return (Criteria) this;
        }

        public Criteria andProjectidIsNull() {
            addCriterion("projectId is null");
            return (Criteria) this;
        }

        public Criteria andProjectidIsNotNull() {
            addCriterion("projectId is not null");
            return (Criteria) this;
        }

        public Criteria andProjectidEqualTo(String value) {
            addCriterion("projectId =", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidNotEqualTo(String value) {
            addCriterion("projectId <>", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidGreaterThan(String value) {
            addCriterion("projectId >", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidGreaterThanOrEqualTo(String value) {
            addCriterion("projectId >=", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidLessThan(String value) {
            addCriterion("projectId <", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidLessThanOrEqualTo(String value) {
            addCriterion("projectId <=", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidLike(String value) {
            addCriterion("projectId like", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidNotLike(String value) {
            addCriterion("projectId not like", value, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidIn(List<String> values) {
            addCriterion("projectId in", values, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidNotIn(List<String> values) {
            addCriterion("projectId not in", values, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidBetween(String value1, String value2) {
            addCriterion("projectId between", value1, value2, "projectid");
            return (Criteria) this;
        }

        public Criteria andProjectidNotBetween(String value1, String value2) {
            addCriterion("projectId not between", value1, value2, "projectid");
            return (Criteria) this;
        }

        public Criteria andMissiontrackeridIsNull() {
            addCriterion("missionTrackerId is null");
            return (Criteria) this;
        }

        public Criteria andMissiontrackeridIsNotNull() {
            addCriterion("missionTrackerId is not null");
            return (Criteria) this;
        }

        public Criteria andMissiontrackeridEqualTo(String value) {
            addCriterion("missionTrackerId =", value, "missiontrackerid");
            return (Criteria) this;
        }

        public Criteria andMissiontrackeridNotEqualTo(String value) {
            addCriterion("missionTrackerId <>", value, "missiontrackerid");
            return (Criteria) this;
        }

        public Criteria andMissiontrackeridGreaterThan(String value) {
            addCriterion("missionTrackerId >", value, "missiontrackerid");
            return (Criteria) this;
        }

        public Criteria andMissiontrackeridGreaterThanOrEqualTo(String value) {
            addCriterion("missionTrackerId >=", value, "missiontrackerid");
            return (Criteria) this;
        }

        public Criteria andMissiontrackeridLessThan(String value) {
            addCriterion("missionTrackerId <", value, "missiontrackerid");
            return (Criteria) this;
        }

        public Criteria andMissiontrackeridLessThanOrEqualTo(String value) {
            addCriterion("missionTrackerId <=", value, "missiontrackerid");
            return (Criteria) this;
        }

        public Criteria andMissiontrackeridLike(String value) {
            addCriterion("missionTrackerId like", value, "missiontrackerid");
            return (Criteria) this;
        }

        public Criteria andMissiontrackeridNotLike(String value) {
            addCriterion("missionTrackerId not like", value, "missiontrackerid");
            return (Criteria) this;
        }

        public Criteria andMissiontrackeridIn(List<String> values) {
            addCriterion("missionTrackerId in", values, "missiontrackerid");
            return (Criteria) this;
        }

        public Criteria andMissiontrackeridNotIn(List<String> values) {
            addCriterion("missionTrackerId not in", values, "missiontrackerid");
            return (Criteria) this;
        }

        public Criteria andMissiontrackeridBetween(String value1, String value2) {
            addCriterion("missionTrackerId between", value1, value2, "missiontrackerid");
            return (Criteria) this;
        }

        public Criteria andMissiontrackeridNotBetween(String value1, String value2) {
            addCriterion("missionTrackerId not between", value1, value2, "missiontrackerid");
            return (Criteria) this;
        }

        public Criteria andMissionnameIsNull() {
            addCriterion("missionName is null");
            return (Criteria) this;
        }

        public Criteria andMissionnameIsNotNull() {
            addCriterion("missionName is not null");
            return (Criteria) this;
        }

        public Criteria andMissionnameEqualTo(String value) {
            addCriterion("missionName =", value, "missionname");
            return (Criteria) this;
        }

        public Criteria andMissionnameNotEqualTo(String value) {
            addCriterion("missionName <>", value, "missionname");
            return (Criteria) this;
        }

        public Criteria andMissionnameGreaterThan(String value) {
            addCriterion("missionName >", value, "missionname");
            return (Criteria) this;
        }

        public Criteria andMissionnameGreaterThanOrEqualTo(String value) {
            addCriterion("missionName >=", value, "missionname");
            return (Criteria) this;
        }

        public Criteria andMissionnameLessThan(String value) {
            addCriterion("missionName <", value, "missionname");
            return (Criteria) this;
        }

        public Criteria andMissionnameLessThanOrEqualTo(String value) {
            addCriterion("missionName <=", value, "missionname");
            return (Criteria) this;
        }

        public Criteria andMissionnameLike(String value) {
            addCriterion("missionName like", value, "missionname");
            return (Criteria) this;
        }

        public Criteria andMissionnameNotLike(String value) {
            addCriterion("missionName not like", value, "missionname");
            return (Criteria) this;
        }

        public Criteria andMissionnameIn(List<String> values) {
            addCriterion("missionName in", values, "missionname");
            return (Criteria) this;
        }

        public Criteria andMissionnameNotIn(List<String> values) {
            addCriterion("missionName not in", values, "missionname");
            return (Criteria) this;
        }

        public Criteria andMissionnameBetween(String value1, String value2) {
            addCriterion("missionName between", value1, value2, "missionname");
            return (Criteria) this;
        }

        public Criteria andMissionnameNotBetween(String value1, String value2) {
            addCriterion("missionName not between", value1, value2, "missionname");
            return (Criteria) this;
        }

        public Criteria andMissionstarttimeIsNull() {
            addCriterion("missionStartTime is null");
            return (Criteria) this;
        }

        public Criteria andMissionstarttimeIsNotNull() {
            addCriterion("missionStartTime is not null");
            return (Criteria) this;
        }

        public Criteria andMissionstarttimeEqualTo(Date value) {
            addCriterionForJDBCDate("missionStartTime =", value, "missionstarttime");
            return (Criteria) this;
        }

        public Criteria andMissionstarttimeNotEqualTo(Date value) {
            addCriterionForJDBCDate("missionStartTime <>", value, "missionstarttime");
            return (Criteria) this;
        }

        public Criteria andMissionstarttimeGreaterThan(Date value) {
            addCriterionForJDBCDate("missionStartTime >", value, "missionstarttime");
            return (Criteria) this;
        }

        public Criteria andMissionstarttimeGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("missionStartTime >=", value, "missionstarttime");
            return (Criteria) this;
        }

        public Criteria andMissionstarttimeLessThan(Date value) {
            addCriterionForJDBCDate("missionStartTime <", value, "missionstarttime");
            return (Criteria) this;
        }

        public Criteria andMissionstarttimeLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("missionStartTime <=", value, "missionstarttime");
            return (Criteria) this;
        }

        public Criteria andMissionstarttimeIn(List<Date> values) {
            addCriterionForJDBCDate("missionStartTime in", values, "missionstarttime");
            return (Criteria) this;
        }

        public Criteria andMissionstarttimeNotIn(List<Date> values) {
            addCriterionForJDBCDate("missionStartTime not in", values, "missionstarttime");
            return (Criteria) this;
        }

        public Criteria andMissionstarttimeBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("missionStartTime between", value1, value2, "missionstarttime");
            return (Criteria) this;
        }

        public Criteria andMissionstarttimeNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("missionStartTime not between", value1, value2, "missionstarttime");
            return (Criteria) this;
        }

        public Criteria andMissionendtimeIsNull() {
            addCriterion("missionEndTime is null");
            return (Criteria) this;
        }

        public Criteria andMissionendtimeIsNotNull() {
            addCriterion("missionEndTime is not null");
            return (Criteria) this;
        }

        public Criteria andMissionendtimeEqualTo(Date value) {
            addCriterionForJDBCDate("missionEndTime =", value, "missionendtime");
            return (Criteria) this;
        }

        public Criteria andMissionendtimeNotEqualTo(Date value) {
            addCriterionForJDBCDate("missionEndTime <>", value, "missionendtime");
            return (Criteria) this;
        }

        public Criteria andMissionendtimeGreaterThan(Date value) {
            addCriterionForJDBCDate("missionEndTime >", value, "missionendtime");
            return (Criteria) this;
        }

        public Criteria andMissionendtimeGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("missionEndTime >=", value, "missionendtime");
            return (Criteria) this;
        }

        public Criteria andMissionendtimeLessThan(Date value) {
            addCriterionForJDBCDate("missionEndTime <", value, "missionendtime");
            return (Criteria) this;
        }

        public Criteria andMissionendtimeLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("missionEndTime <=", value, "missionendtime");
            return (Criteria) this;
        }

        public Criteria andMissionendtimeIn(List<Date> values) {
            addCriterionForJDBCDate("missionEndTime in", values, "missionendtime");
            return (Criteria) this;
        }

        public Criteria andMissionendtimeNotIn(List<Date> values) {
            addCriterionForJDBCDate("missionEndTime not in", values, "missionendtime");
            return (Criteria) this;
        }

        public Criteria andMissionendtimeBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("missionEndTime between", value1, value2, "missionendtime");
            return (Criteria) this;
        }

        public Criteria andMissionendtimeNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("missionEndTime not between", value1, value2, "missionendtime");
            return (Criteria) this;
        }

        public Criteria andMissioncontentIsNull() {
            addCriterion("missionContent is null");
            return (Criteria) this;
        }

        public Criteria andMissioncontentIsNotNull() {
            addCriterion("missionContent is not null");
            return (Criteria) this;
        }

        public Criteria andMissioncontentEqualTo(String value) {
            addCriterion("missionContent =", value, "missioncontent");
            return (Criteria) this;
        }

        public Criteria andMissioncontentNotEqualTo(String value) {
            addCriterion("missionContent <>", value, "missioncontent");
            return (Criteria) this;
        }

        public Criteria andMissioncontentGreaterThan(String value) {
            addCriterion("missionContent >", value, "missioncontent");
            return (Criteria) this;
        }

        public Criteria andMissioncontentGreaterThanOrEqualTo(String value) {
            addCriterion("missionContent >=", value, "missioncontent");
            return (Criteria) this;
        }

        public Criteria andMissioncontentLessThan(String value) {
            addCriterion("missionContent <", value, "missioncontent");
            return (Criteria) this;
        }

        public Criteria andMissioncontentLessThanOrEqualTo(String value) {
            addCriterion("missionContent <=", value, "missioncontent");
            return (Criteria) this;
        }

        public Criteria andMissioncontentLike(String value) {
            addCriterion("missionContent like", value, "missioncontent");
            return (Criteria) this;
        }

        public Criteria andMissioncontentNotLike(String value) {
            addCriterion("missionContent not like", value, "missioncontent");
            return (Criteria) this;
        }

        public Criteria andMissioncontentIn(List<String> values) {
            addCriterion("missionContent in", values, "missioncontent");
            return (Criteria) this;
        }

        public Criteria andMissioncontentNotIn(List<String> values) {
            addCriterion("missionContent not in", values, "missioncontent");
            return (Criteria) this;
        }

        public Criteria andMissioncontentBetween(String value1, String value2) {
            addCriterion("missionContent between", value1, value2, "missioncontent");
            return (Criteria) this;
        }

        public Criteria andMissioncontentNotBetween(String value1, String value2) {
            addCriterion("missionContent not between", value1, value2, "missioncontent");
            return (Criteria) this;
        }

        public Criteria andMissiondateIsNull() {
            addCriterion("missionDate is null");
            return (Criteria) this;
        }

        public Criteria andMissiondateIsNotNull() {
            addCriterion("missionDate is not null");
            return (Criteria) this;
        }

        public Criteria andMissiondateEqualTo(Date value) {
            addCriterionForJDBCDate("missionDate =", value, "missiondate");
            return (Criteria) this;
        }

        public Criteria andMissiondateNotEqualTo(Date value) {
            addCriterionForJDBCDate("missionDate <>", value, "missiondate");
            return (Criteria) this;
        }

        public Criteria andMissiondateGreaterThan(Date value) {
            addCriterionForJDBCDate("missionDate >", value, "missiondate");
            return (Criteria) this;
        }

        public Criteria andMissiondateGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("missionDate >=", value, "missiondate");
            return (Criteria) this;
        }

        public Criteria andMissiondateLessThan(Date value) {
            addCriterionForJDBCDate("missionDate <", value, "missiondate");
            return (Criteria) this;
        }

        public Criteria andMissiondateLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("missionDate <=", value, "missiondate");
            return (Criteria) this;
        }

        public Criteria andMissiondateIn(List<Date> values) {
            addCriterionForJDBCDate("missionDate in", values, "missiondate");
            return (Criteria) this;
        }

        public Criteria andMissiondateNotIn(List<Date> values) {
            addCriterionForJDBCDate("missionDate not in", values, "missiondate");
            return (Criteria) this;
        }

        public Criteria andMissiondateBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("missionDate between", value1, value2, "missiondate");
            return (Criteria) this;
        }

        public Criteria andMissiondateNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("missionDate not between", value1, value2, "missiondate");
            return (Criteria) this;
        }

        public Criteria andMissionstatusIsNull() {
            addCriterion("missionStatus is null");
            return (Criteria) this;
        }

        public Criteria andMissionstatusIsNotNull() {
            addCriterion("missionStatus is not null");
            return (Criteria) this;
        }

        public Criteria andMissionstatusEqualTo(Integer value) {
            addCriterion("missionStatus =", value, "missionstatus");
            return (Criteria) this;
        }

        public Criteria andMissionstatusNotEqualTo(Integer value) {
            addCriterion("missionStatus <>", value, "missionstatus");
            return (Criteria) this;
        }

        public Criteria andMissionstatusGreaterThan(Integer value) {
            addCriterion("missionStatus >", value, "missionstatus");
            return (Criteria) this;
        }

        public Criteria andMissionstatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("missionStatus >=", value, "missionstatus");
            return (Criteria) this;
        }

        public Criteria andMissionstatusLessThan(Integer value) {
            addCriterion("missionStatus <", value, "missionstatus");
            return (Criteria) this;
        }

        public Criteria andMissionstatusLessThanOrEqualTo(Integer value) {
            addCriterion("missionStatus <=", value, "missionstatus");
            return (Criteria) this;
        }

        public Criteria andMissionstatusIn(List<Integer> values) {
            addCriterion("missionStatus in", values, "missionstatus");
            return (Criteria) this;
        }

        public Criteria andMissionstatusNotIn(List<Integer> values) {
            addCriterion("missionStatus not in", values, "missionstatus");
            return (Criteria) this;
        }

        public Criteria andMissionstatusBetween(Integer value1, Integer value2) {
            addCriterion("missionStatus between", value1, value2, "missionstatus");
            return (Criteria) this;
        }

        public Criteria andMissionstatusNotBetween(Integer value1, Integer value2) {
            addCriterion("missionStatus not between", value1, value2, "missionstatus");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}