package com.cpms.pojo;

import java.util.ArrayList;
import java.util.List;

public class CpmsDiaryDetailExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public CpmsDiaryDetailExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andDiarydetailidIsNull() {
            addCriterion("diaryDetailId is null");
            return (Criteria) this;
        }

        public Criteria andDiarydetailidIsNotNull() {
            addCriterion("diaryDetailId is not null");
            return (Criteria) this;
        }

        public Criteria andDiarydetailidEqualTo(Integer value) {
            addCriterion("diaryDetailId =", value, "diarydetailid");
            return (Criteria) this;
        }

        public Criteria andDiarydetailidNotEqualTo(Integer value) {
            addCriterion("diaryDetailId <>", value, "diarydetailid");
            return (Criteria) this;
        }

        public Criteria andDiarydetailidGreaterThan(Integer value) {
            addCriterion("diaryDetailId >", value, "diarydetailid");
            return (Criteria) this;
        }

        public Criteria andDiarydetailidGreaterThanOrEqualTo(Integer value) {
            addCriterion("diaryDetailId >=", value, "diarydetailid");
            return (Criteria) this;
        }

        public Criteria andDiarydetailidLessThan(Integer value) {
            addCriterion("diaryDetailId <", value, "diarydetailid");
            return (Criteria) this;
        }

        public Criteria andDiarydetailidLessThanOrEqualTo(Integer value) {
            addCriterion("diaryDetailId <=", value, "diarydetailid");
            return (Criteria) this;
        }

        public Criteria andDiarydetailidIn(List<Integer> values) {
            addCriterion("diaryDetailId in", values, "diarydetailid");
            return (Criteria) this;
        }

        public Criteria andDiarydetailidNotIn(List<Integer> values) {
            addCriterion("diaryDetailId not in", values, "diarydetailid");
            return (Criteria) this;
        }

        public Criteria andDiarydetailidBetween(Integer value1, Integer value2) {
            addCriterion("diaryDetailId between", value1, value2, "diarydetailid");
            return (Criteria) this;
        }

        public Criteria andDiarydetailidNotBetween(Integer value1, Integer value2) {
            addCriterion("diaryDetailId not between", value1, value2, "diarydetailid");
            return (Criteria) this;
        }

        public Criteria andDiaryidIsNull() {
            addCriterion("diaryId is null");
            return (Criteria) this;
        }

        public Criteria andDiaryidIsNotNull() {
            addCriterion("diaryId is not null");
            return (Criteria) this;
        }

        public Criteria andDiaryidEqualTo(String value) {
            addCriterion("diaryId =", value, "diaryid");
            return (Criteria) this;
        }

        public Criteria andDiaryidNotEqualTo(String value) {
            addCriterion("diaryId <>", value, "diaryid");
            return (Criteria) this;
        }

        public Criteria andDiaryidGreaterThan(String value) {
            addCriterion("diaryId >", value, "diaryid");
            return (Criteria) this;
        }

        public Criteria andDiaryidGreaterThanOrEqualTo(String value) {
            addCriterion("diaryId >=", value, "diaryid");
            return (Criteria) this;
        }

        public Criteria andDiaryidLessThan(String value) {
            addCriterion("diaryId <", value, "diaryid");
            return (Criteria) this;
        }

        public Criteria andDiaryidLessThanOrEqualTo(String value) {
            addCriterion("diaryId <=", value, "diaryid");
            return (Criteria) this;
        }

        public Criteria andDiaryidLike(String value) {
            addCriterion("diaryId like", value, "diaryid");
            return (Criteria) this;
        }

        public Criteria andDiaryidNotLike(String value) {
            addCriterion("diaryId not like", value, "diaryid");
            return (Criteria) this;
        }

        public Criteria andDiaryidIn(List<String> values) {
            addCriterion("diaryId in", values, "diaryid");
            return (Criteria) this;
        }

        public Criteria andDiaryidNotIn(List<String> values) {
            addCriterion("diaryId not in", values, "diaryid");
            return (Criteria) this;
        }

        public Criteria andDiaryidBetween(String value1, String value2) {
            addCriterion("diaryId between", value1, value2, "diaryid");
            return (Criteria) this;
        }

        public Criteria andDiaryidNotBetween(String value1, String value2) {
            addCriterion("diaryId not between", value1, value2, "diaryid");
            return (Criteria) this;
        }

        public Criteria andDetailteamIsNull() {
            addCriterion("detailTeam is null");
            return (Criteria) this;
        }

        public Criteria andDetailteamIsNotNull() {
            addCriterion("detailTeam is not null");
            return (Criteria) this;
        }

        public Criteria andDetailteamEqualTo(String value) {
            addCriterion("detailTeam =", value, "detailteam");
            return (Criteria) this;
        }

        public Criteria andDetailteamNotEqualTo(String value) {
            addCriterion("detailTeam <>", value, "detailteam");
            return (Criteria) this;
        }

        public Criteria andDetailteamGreaterThan(String value) {
            addCriterion("detailTeam >", value, "detailteam");
            return (Criteria) this;
        }

        public Criteria andDetailteamGreaterThanOrEqualTo(String value) {
            addCriterion("detailTeam >=", value, "detailteam");
            return (Criteria) this;
        }

        public Criteria andDetailteamLessThan(String value) {
            addCriterion("detailTeam <", value, "detailteam");
            return (Criteria) this;
        }

        public Criteria andDetailteamLessThanOrEqualTo(String value) {
            addCriterion("detailTeam <=", value, "detailteam");
            return (Criteria) this;
        }

        public Criteria andDetailteamLike(String value) {
            addCriterion("detailTeam like", value, "detailteam");
            return (Criteria) this;
        }

        public Criteria andDetailteamNotLike(String value) {
            addCriterion("detailTeam not like", value, "detailteam");
            return (Criteria) this;
        }

        public Criteria andDetailteamIn(List<String> values) {
            addCriterion("detailTeam in", values, "detailteam");
            return (Criteria) this;
        }

        public Criteria andDetailteamNotIn(List<String> values) {
            addCriterion("detailTeam not in", values, "detailteam");
            return (Criteria) this;
        }

        public Criteria andDetailteamBetween(String value1, String value2) {
            addCriterion("detailTeam between", value1, value2, "detailteam");
            return (Criteria) this;
        }

        public Criteria andDetailteamNotBetween(String value1, String value2) {
            addCriterion("detailTeam not between", value1, value2, "detailteam");
            return (Criteria) this;
        }

        public Criteria andDetailworkernumIsNull() {
            addCriterion("detailWorkerNum is null");
            return (Criteria) this;
        }

        public Criteria andDetailworkernumIsNotNull() {
            addCriterion("detailWorkerNum is not null");
            return (Criteria) this;
        }

        public Criteria andDetailworkernumEqualTo(Integer value) {
            addCriterion("detailWorkerNum =", value, "detailworkernum");
            return (Criteria) this;
        }

        public Criteria andDetailworkernumNotEqualTo(Integer value) {
            addCriterion("detailWorkerNum <>", value, "detailworkernum");
            return (Criteria) this;
        }

        public Criteria andDetailworkernumGreaterThan(Integer value) {
            addCriterion("detailWorkerNum >", value, "detailworkernum");
            return (Criteria) this;
        }

        public Criteria andDetailworkernumGreaterThanOrEqualTo(Integer value) {
            addCriterion("detailWorkerNum >=", value, "detailworkernum");
            return (Criteria) this;
        }

        public Criteria andDetailworkernumLessThan(Integer value) {
            addCriterion("detailWorkerNum <", value, "detailworkernum");
            return (Criteria) this;
        }

        public Criteria andDetailworkernumLessThanOrEqualTo(Integer value) {
            addCriterion("detailWorkerNum <=", value, "detailworkernum");
            return (Criteria) this;
        }

        public Criteria andDetailworkernumIn(List<Integer> values) {
            addCriterion("detailWorkerNum in", values, "detailworkernum");
            return (Criteria) this;
        }

        public Criteria andDetailworkernumNotIn(List<Integer> values) {
            addCriterion("detailWorkerNum not in", values, "detailworkernum");
            return (Criteria) this;
        }

        public Criteria andDetailworkernumBetween(Integer value1, Integer value2) {
            addCriterion("detailWorkerNum between", value1, value2, "detailworkernum");
            return (Criteria) this;
        }

        public Criteria andDetailworkernumNotBetween(Integer value1, Integer value2) {
            addCriterion("detailWorkerNum not between", value1, value2, "detailworkernum");
            return (Criteria) this;
        }

        public Criteria andDetailcontentIsNull() {
            addCriterion("detailContent is null");
            return (Criteria) this;
        }

        public Criteria andDetailcontentIsNotNull() {
            addCriterion("detailContent is not null");
            return (Criteria) this;
        }

        public Criteria andDetailcontentEqualTo(String value) {
            addCriterion("detailContent =", value, "detailcontent");
            return (Criteria) this;
        }

        public Criteria andDetailcontentNotEqualTo(String value) {
            addCriterion("detailContent <>", value, "detailcontent");
            return (Criteria) this;
        }

        public Criteria andDetailcontentGreaterThan(String value) {
            addCriterion("detailContent >", value, "detailcontent");
            return (Criteria) this;
        }

        public Criteria andDetailcontentGreaterThanOrEqualTo(String value) {
            addCriterion("detailContent >=", value, "detailcontent");
            return (Criteria) this;
        }

        public Criteria andDetailcontentLessThan(String value) {
            addCriterion("detailContent <", value, "detailcontent");
            return (Criteria) this;
        }

        public Criteria andDetailcontentLessThanOrEqualTo(String value) {
            addCriterion("detailContent <=", value, "detailcontent");
            return (Criteria) this;
        }

        public Criteria andDetailcontentLike(String value) {
            addCriterion("detailContent like", value, "detailcontent");
            return (Criteria) this;
        }

        public Criteria andDetailcontentNotLike(String value) {
            addCriterion("detailContent not like", value, "detailcontent");
            return (Criteria) this;
        }

        public Criteria andDetailcontentIn(List<String> values) {
            addCriterion("detailContent in", values, "detailcontent");
            return (Criteria) this;
        }

        public Criteria andDetailcontentNotIn(List<String> values) {
            addCriterion("detailContent not in", values, "detailcontent");
            return (Criteria) this;
        }

        public Criteria andDetailcontentBetween(String value1, String value2) {
            addCriterion("detailContent between", value1, value2, "detailcontent");
            return (Criteria) this;
        }

        public Criteria andDetailcontentNotBetween(String value1, String value2) {
            addCriterion("detailContent not between", value1, value2, "detailcontent");
            return (Criteria) this;
        }

        public Criteria andDetailremarkIsNull() {
            addCriterion("detailRemark is null");
            return (Criteria) this;
        }

        public Criteria andDetailremarkIsNotNull() {
            addCriterion("detailRemark is not null");
            return (Criteria) this;
        }

        public Criteria andDetailremarkEqualTo(String value) {
            addCriterion("detailRemark =", value, "detailremark");
            return (Criteria) this;
        }

        public Criteria andDetailremarkNotEqualTo(String value) {
            addCriterion("detailRemark <>", value, "detailremark");
            return (Criteria) this;
        }

        public Criteria andDetailremarkGreaterThan(String value) {
            addCriterion("detailRemark >", value, "detailremark");
            return (Criteria) this;
        }

        public Criteria andDetailremarkGreaterThanOrEqualTo(String value) {
            addCriterion("detailRemark >=", value, "detailremark");
            return (Criteria) this;
        }

        public Criteria andDetailremarkLessThan(String value) {
            addCriterion("detailRemark <", value, "detailremark");
            return (Criteria) this;
        }

        public Criteria andDetailremarkLessThanOrEqualTo(String value) {
            addCriterion("detailRemark <=", value, "detailremark");
            return (Criteria) this;
        }

        public Criteria andDetailremarkLike(String value) {
            addCriterion("detailRemark like", value, "detailremark");
            return (Criteria) this;
        }

        public Criteria andDetailremarkNotLike(String value) {
            addCriterion("detailRemark not like", value, "detailremark");
            return (Criteria) this;
        }

        public Criteria andDetailremarkIn(List<String> values) {
            addCriterion("detailRemark in", values, "detailremark");
            return (Criteria) this;
        }

        public Criteria andDetailremarkNotIn(List<String> values) {
            addCriterion("detailRemark not in", values, "detailremark");
            return (Criteria) this;
        }

        public Criteria andDetailremarkBetween(String value1, String value2) {
            addCriterion("detailRemark between", value1, value2, "detailremark");
            return (Criteria) this;
        }

        public Criteria andDetailremarkNotBetween(String value1, String value2) {
            addCriterion("detailRemark not between", value1, value2, "detailremark");
            return (Criteria) this;
        }

        public Criteria andDetailprogressIsNull() {
            addCriterion("detailProgress is null");
            return (Criteria) this;
        }

        public Criteria andDetailprogressIsNotNull() {
            addCriterion("detailProgress is not null");
            return (Criteria) this;
        }

        public Criteria andDetailprogressEqualTo(String value) {
            addCriterion("detailProgress =", value, "detailprogress");
            return (Criteria) this;
        }

        public Criteria andDetailprogressNotEqualTo(String value) {
            addCriterion("detailProgress <>", value, "detailprogress");
            return (Criteria) this;
        }

        public Criteria andDetailprogressGreaterThan(String value) {
            addCriterion("detailProgress >", value, "detailprogress");
            return (Criteria) this;
        }

        public Criteria andDetailprogressGreaterThanOrEqualTo(String value) {
            addCriterion("detailProgress >=", value, "detailprogress");
            return (Criteria) this;
        }

        public Criteria andDetailprogressLessThan(String value) {
            addCriterion("detailProgress <", value, "detailprogress");
            return (Criteria) this;
        }

        public Criteria andDetailprogressLessThanOrEqualTo(String value) {
            addCriterion("detailProgress <=", value, "detailprogress");
            return (Criteria) this;
        }

        public Criteria andDetailprogressLike(String value) {
            addCriterion("detailProgress like", value, "detailprogress");
            return (Criteria) this;
        }

        public Criteria andDetailprogressNotLike(String value) {
            addCriterion("detailProgress not like", value, "detailprogress");
            return (Criteria) this;
        }

        public Criteria andDetailprogressIn(List<String> values) {
            addCriterion("detailProgress in", values, "detailprogress");
            return (Criteria) this;
        }

        public Criteria andDetailprogressNotIn(List<String> values) {
            addCriterion("detailProgress not in", values, "detailprogress");
            return (Criteria) this;
        }

        public Criteria andDetailprogressBetween(String value1, String value2) {
            addCriterion("detailProgress between", value1, value2, "detailprogress");
            return (Criteria) this;
        }

        public Criteria andDetailprogressNotBetween(String value1, String value2) {
            addCriterion("detailProgress not between", value1, value2, "detailprogress");
            return (Criteria) this;
        }

        public Criteria andDetailmainworkIsNull() {
            addCriterion("detailMainWork is null");
            return (Criteria) this;
        }

        public Criteria andDetailmainworkIsNotNull() {
            addCriterion("detailMainWork is not null");
            return (Criteria) this;
        }

        public Criteria andDetailmainworkEqualTo(String value) {
            addCriterion("detailMainWork =", value, "detailmainwork");
            return (Criteria) this;
        }

        public Criteria andDetailmainworkNotEqualTo(String value) {
            addCriterion("detailMainWork <>", value, "detailmainwork");
            return (Criteria) this;
        }

        public Criteria andDetailmainworkGreaterThan(String value) {
            addCriterion("detailMainWork >", value, "detailmainwork");
            return (Criteria) this;
        }

        public Criteria andDetailmainworkGreaterThanOrEqualTo(String value) {
            addCriterion("detailMainWork >=", value, "detailmainwork");
            return (Criteria) this;
        }

        public Criteria andDetailmainworkLessThan(String value) {
            addCriterion("detailMainWork <", value, "detailmainwork");
            return (Criteria) this;
        }

        public Criteria andDetailmainworkLessThanOrEqualTo(String value) {
            addCriterion("detailMainWork <=", value, "detailmainwork");
            return (Criteria) this;
        }

        public Criteria andDetailmainworkLike(String value) {
            addCriterion("detailMainWork like", value, "detailmainwork");
            return (Criteria) this;
        }

        public Criteria andDetailmainworkNotLike(String value) {
            addCriterion("detailMainWork not like", value, "detailmainwork");
            return (Criteria) this;
        }

        public Criteria andDetailmainworkIn(List<String> values) {
            addCriterion("detailMainWork in", values, "detailmainwork");
            return (Criteria) this;
        }

        public Criteria andDetailmainworkNotIn(List<String> values) {
            addCriterion("detailMainWork not in", values, "detailmainwork");
            return (Criteria) this;
        }

        public Criteria andDetailmainworkBetween(String value1, String value2) {
            addCriterion("detailMainWork between", value1, value2, "detailmainwork");
            return (Criteria) this;
        }

        public Criteria andDetailmainworkNotBetween(String value1, String value2) {
            addCriterion("detailMainWork not between", value1, value2, "detailmainwork");
            return (Criteria) this;
        }

        public Criteria andDetailotherIsNull() {
            addCriterion("detailOther is null");
            return (Criteria) this;
        }

        public Criteria andDetailotherIsNotNull() {
            addCriterion("detailOther is not null");
            return (Criteria) this;
        }

        public Criteria andDetailotherEqualTo(String value) {
            addCriterion("detailOther =", value, "detailother");
            return (Criteria) this;
        }

        public Criteria andDetailotherNotEqualTo(String value) {
            addCriterion("detailOther <>", value, "detailother");
            return (Criteria) this;
        }

        public Criteria andDetailotherGreaterThan(String value) {
            addCriterion("detailOther >", value, "detailother");
            return (Criteria) this;
        }

        public Criteria andDetailotherGreaterThanOrEqualTo(String value) {
            addCriterion("detailOther >=", value, "detailother");
            return (Criteria) this;
        }

        public Criteria andDetailotherLessThan(String value) {
            addCriterion("detailOther <", value, "detailother");
            return (Criteria) this;
        }

        public Criteria andDetailotherLessThanOrEqualTo(String value) {
            addCriterion("detailOther <=", value, "detailother");
            return (Criteria) this;
        }

        public Criteria andDetailotherLike(String value) {
            addCriterion("detailOther like", value, "detailother");
            return (Criteria) this;
        }

        public Criteria andDetailotherNotLike(String value) {
            addCriterion("detailOther not like", value, "detailother");
            return (Criteria) this;
        }

        public Criteria andDetailotherIn(List<String> values) {
            addCriterion("detailOther in", values, "detailother");
            return (Criteria) this;
        }

        public Criteria andDetailotherNotIn(List<String> values) {
            addCriterion("detailOther not in", values, "detailother");
            return (Criteria) this;
        }

        public Criteria andDetailotherBetween(String value1, String value2) {
            addCriterion("detailOther between", value1, value2, "detailother");
            return (Criteria) this;
        }

        public Criteria andDetailotherNotBetween(String value1, String value2) {
            addCriterion("detailOther not between", value1, value2, "detailother");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}