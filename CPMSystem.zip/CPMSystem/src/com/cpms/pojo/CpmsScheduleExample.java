package com.cpms.pojo;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class CpmsScheduleExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public CpmsScheduleExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<java.sql.Date>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andScheduleidIsNull() {
            addCriterion("scheduleId is null");
            return (Criteria) this;
        }

        public Criteria andScheduleidIsNotNull() {
            addCriterion("scheduleId is not null");
            return (Criteria) this;
        }

        public Criteria andScheduleidEqualTo(String value) {
            addCriterion("scheduleId =", value, "scheduleid");
            return (Criteria) this;
        }

        public Criteria andScheduleidNotEqualTo(String value) {
            addCriterion("scheduleId <>", value, "scheduleid");
            return (Criteria) this;
        }

        public Criteria andScheduleidGreaterThan(String value) {
            addCriterion("scheduleId >", value, "scheduleid");
            return (Criteria) this;
        }

        public Criteria andScheduleidGreaterThanOrEqualTo(String value) {
            addCriterion("scheduleId >=", value, "scheduleid");
            return (Criteria) this;
        }

        public Criteria andScheduleidLessThan(String value) {
            addCriterion("scheduleId <", value, "scheduleid");
            return (Criteria) this;
        }

        public Criteria andScheduleidLessThanOrEqualTo(String value) {
            addCriterion("scheduleId <=", value, "scheduleid");
            return (Criteria) this;
        }

        public Criteria andScheduleidLike(String value) {
            addCriterion("scheduleId like", value, "scheduleid");
            return (Criteria) this;
        }

        public Criteria andScheduleidNotLike(String value) {
            addCriterion("scheduleId not like", value, "scheduleid");
            return (Criteria) this;
        }

        public Criteria andScheduleidIn(List<String> values) {
            addCriterion("scheduleId in", values, "scheduleid");
            return (Criteria) this;
        }

        public Criteria andScheduleidNotIn(List<String> values) {
            addCriterion("scheduleId not in", values, "scheduleid");
            return (Criteria) this;
        }

        public Criteria andScheduleidBetween(String value1, String value2) {
            addCriterion("scheduleId between", value1, value2, "scheduleid");
            return (Criteria) this;
        }

        public Criteria andScheduleidNotBetween(String value1, String value2) {
            addCriterion("scheduleId not between", value1, value2, "scheduleid");
            return (Criteria) this;
        }

        public Criteria andScheduleeditoridIsNull() {
            addCriterion("scheduleEditorId is null");
            return (Criteria) this;
        }

        public Criteria andScheduleeditoridIsNotNull() {
            addCriterion("scheduleEditorId is not null");
            return (Criteria) this;
        }

        public Criteria andScheduleeditoridEqualTo(String value) {
            addCriterion("scheduleEditorId =", value, "scheduleeditorid");
            return (Criteria) this;
        }

        public Criteria andScheduleeditoridNotEqualTo(String value) {
            addCriterion("scheduleEditorId <>", value, "scheduleeditorid");
            return (Criteria) this;
        }

        public Criteria andScheduleeditoridGreaterThan(String value) {
            addCriterion("scheduleEditorId >", value, "scheduleeditorid");
            return (Criteria) this;
        }

        public Criteria andScheduleeditoridGreaterThanOrEqualTo(String value) {
            addCriterion("scheduleEditorId >=", value, "scheduleeditorid");
            return (Criteria) this;
        }

        public Criteria andScheduleeditoridLessThan(String value) {
            addCriterion("scheduleEditorId <", value, "scheduleeditorid");
            return (Criteria) this;
        }

        public Criteria andScheduleeditoridLessThanOrEqualTo(String value) {
            addCriterion("scheduleEditorId <=", value, "scheduleeditorid");
            return (Criteria) this;
        }

        public Criteria andScheduleeditoridLike(String value) {
            addCriterion("scheduleEditorId like", value, "scheduleeditorid");
            return (Criteria) this;
        }

        public Criteria andScheduleeditoridNotLike(String value) {
            addCriterion("scheduleEditorId not like", value, "scheduleeditorid");
            return (Criteria) this;
        }

        public Criteria andScheduleeditoridIn(List<String> values) {
            addCriterion("scheduleEditorId in", values, "scheduleeditorid");
            return (Criteria) this;
        }

        public Criteria andScheduleeditoridNotIn(List<String> values) {
            addCriterion("scheduleEditorId not in", values, "scheduleeditorid");
            return (Criteria) this;
        }

        public Criteria andScheduleeditoridBetween(String value1, String value2) {
            addCriterion("scheduleEditorId between", value1, value2, "scheduleeditorid");
            return (Criteria) this;
        }

        public Criteria andScheduleeditoridNotBetween(String value1, String value2) {
            addCriterion("scheduleEditorId not between", value1, value2, "scheduleeditorid");
            return (Criteria) this;
        }

        public Criteria andScheduleapproversidIsNull() {
            addCriterion("scheduleApproversId is null");
            return (Criteria) this;
        }

        public Criteria andScheduleapproversidIsNotNull() {
            addCriterion("scheduleApproversId is not null");
            return (Criteria) this;
        }

        public Criteria andScheduleapproversidEqualTo(String value) {
            addCriterion("scheduleApproversId =", value, "scheduleapproversid");
            return (Criteria) this;
        }

        public Criteria andScheduleapproversidNotEqualTo(String value) {
            addCriterion("scheduleApproversId <>", value, "scheduleapproversid");
            return (Criteria) this;
        }

        public Criteria andScheduleapproversidGreaterThan(String value) {
            addCriterion("scheduleApproversId >", value, "scheduleapproversid");
            return (Criteria) this;
        }

        public Criteria andScheduleapproversidGreaterThanOrEqualTo(String value) {
            addCriterion("scheduleApproversId >=", value, "scheduleapproversid");
            return (Criteria) this;
        }

        public Criteria andScheduleapproversidLessThan(String value) {
            addCriterion("scheduleApproversId <", value, "scheduleapproversid");
            return (Criteria) this;
        }

        public Criteria andScheduleapproversidLessThanOrEqualTo(String value) {
            addCriterion("scheduleApproversId <=", value, "scheduleapproversid");
            return (Criteria) this;
        }

        public Criteria andScheduleapproversidLike(String value) {
            addCriterion("scheduleApproversId like", value, "scheduleapproversid");
            return (Criteria) this;
        }

        public Criteria andScheduleapproversidNotLike(String value) {
            addCriterion("scheduleApproversId not like", value, "scheduleapproversid");
            return (Criteria) this;
        }

        public Criteria andScheduleapproversidIn(List<String> values) {
            addCriterion("scheduleApproversId in", values, "scheduleapproversid");
            return (Criteria) this;
        }

        public Criteria andScheduleapproversidNotIn(List<String> values) {
            addCriterion("scheduleApproversId not in", values, "scheduleapproversid");
            return (Criteria) this;
        }

        public Criteria andScheduleapproversidBetween(String value1, String value2) {
            addCriterion("scheduleApproversId between", value1, value2, "scheduleapproversid");
            return (Criteria) this;
        }

        public Criteria andScheduleapproversidNotBetween(String value1, String value2) {
            addCriterion("scheduleApproversId not between", value1, value2, "scheduleapproversid");
            return (Criteria) this;
        }

        public Criteria andSchedulenameIsNull() {
            addCriterion("scheduleName is null");
            return (Criteria) this;
        }

        public Criteria andSchedulenameIsNotNull() {
            addCriterion("scheduleName is not null");
            return (Criteria) this;
        }

        public Criteria andSchedulenameEqualTo(String value) {
            addCriterion("scheduleName =", value, "schedulename");
            return (Criteria) this;
        }

        public Criteria andSchedulenameNotEqualTo(String value) {
            addCriterion("scheduleName <>", value, "schedulename");
            return (Criteria) this;
        }

        public Criteria andSchedulenameGreaterThan(String value) {
            addCriterion("scheduleName >", value, "schedulename");
            return (Criteria) this;
        }

        public Criteria andSchedulenameGreaterThanOrEqualTo(String value) {
            addCriterion("scheduleName >=", value, "schedulename");
            return (Criteria) this;
        }

        public Criteria andSchedulenameLessThan(String value) {
            addCriterion("scheduleName <", value, "schedulename");
            return (Criteria) this;
        }

        public Criteria andSchedulenameLessThanOrEqualTo(String value) {
            addCriterion("scheduleName <=", value, "schedulename");
            return (Criteria) this;
        }

        public Criteria andSchedulenameLike(String value) {
            addCriterion("scheduleName like", value, "schedulename");
            return (Criteria) this;
        }

        public Criteria andSchedulenameNotLike(String value) {
            addCriterion("scheduleName not like", value, "schedulename");
            return (Criteria) this;
        }

        public Criteria andSchedulenameIn(List<String> values) {
            addCriterion("scheduleName in", values, "schedulename");
            return (Criteria) this;
        }

        public Criteria andSchedulenameNotIn(List<String> values) {
            addCriterion("scheduleName not in", values, "schedulename");
            return (Criteria) this;
        }

        public Criteria andSchedulenameBetween(String value1, String value2) {
            addCriterion("scheduleName between", value1, value2, "schedulename");
            return (Criteria) this;
        }

        public Criteria andSchedulenameNotBetween(String value1, String value2) {
            addCriterion("scheduleName not between", value1, value2, "schedulename");
            return (Criteria) this;
        }

        public Criteria andScheduledateIsNull() {
            addCriterion("scheduleDate is null");
            return (Criteria) this;
        }

        public Criteria andScheduledateIsNotNull() {
            addCriterion("scheduleDate is not null");
            return (Criteria) this;
        }

        public Criteria andScheduledateEqualTo(Date value) {
            addCriterionForJDBCDate("scheduleDate =", value, "scheduledate");
            return (Criteria) this;
        }

        public Criteria andScheduledateNotEqualTo(Date value) {
            addCriterionForJDBCDate("scheduleDate <>", value, "scheduledate");
            return (Criteria) this;
        }

        public Criteria andScheduledateGreaterThan(Date value) {
            addCriterionForJDBCDate("scheduleDate >", value, "scheduledate");
            return (Criteria) this;
        }

        public Criteria andScheduledateGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("scheduleDate >=", value, "scheduledate");
            return (Criteria) this;
        }

        public Criteria andScheduledateLessThan(Date value) {
            addCriterionForJDBCDate("scheduleDate <", value, "scheduledate");
            return (Criteria) this;
        }

        public Criteria andScheduledateLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("scheduleDate <=", value, "scheduledate");
            return (Criteria) this;
        }

        public Criteria andScheduledateIn(List<Date> values) {
            addCriterionForJDBCDate("scheduleDate in", values, "scheduledate");
            return (Criteria) this;
        }

        public Criteria andScheduledateNotIn(List<Date> values) {
            addCriterionForJDBCDate("scheduleDate not in", values, "scheduledate");
            return (Criteria) this;
        }

        public Criteria andScheduledateBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("scheduleDate between", value1, value2, "scheduledate");
            return (Criteria) this;
        }

        public Criteria andScheduledateNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("scheduleDate not between", value1, value2, "scheduledate");
            return (Criteria) this;
        }

        public Criteria andSchedulestatusIsNull() {
            addCriterion("scheduleStatus is null");
            return (Criteria) this;
        }

        public Criteria andSchedulestatusIsNotNull() {
            addCriterion("scheduleStatus is not null");
            return (Criteria) this;
        }

        public Criteria andSchedulestatusEqualTo(Integer value) {
            addCriterion("scheduleStatus =", value, "schedulestatus");
            return (Criteria) this;
        }

        public Criteria andSchedulestatusNotEqualTo(Integer value) {
            addCriterion("scheduleStatus <>", value, "schedulestatus");
            return (Criteria) this;
        }

        public Criteria andSchedulestatusGreaterThan(Integer value) {
            addCriterion("scheduleStatus >", value, "schedulestatus");
            return (Criteria) this;
        }

        public Criteria andSchedulestatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("scheduleStatus >=", value, "schedulestatus");
            return (Criteria) this;
        }

        public Criteria andSchedulestatusLessThan(Integer value) {
            addCriterion("scheduleStatus <", value, "schedulestatus");
            return (Criteria) this;
        }

        public Criteria andSchedulestatusLessThanOrEqualTo(Integer value) {
            addCriterion("scheduleStatus <=", value, "schedulestatus");
            return (Criteria) this;
        }

        public Criteria andSchedulestatusIn(List<Integer> values) {
            addCriterion("scheduleStatus in", values, "schedulestatus");
            return (Criteria) this;
        }

        public Criteria andSchedulestatusNotIn(List<Integer> values) {
            addCriterion("scheduleStatus not in", values, "schedulestatus");
            return (Criteria) this;
        }

        public Criteria andSchedulestatusBetween(Integer value1, Integer value2) {
            addCriterion("scheduleStatus between", value1, value2, "schedulestatus");
            return (Criteria) this;
        }

        public Criteria andSchedulestatusNotBetween(Integer value1, Integer value2) {
            addCriterion("scheduleStatus not between", value1, value2, "schedulestatus");
            return (Criteria) this;
        }

        public Criteria andApprovedateIsNull() {
            addCriterion("approveDate is null");
            return (Criteria) this;
        }

        public Criteria andApprovedateIsNotNull() {
            addCriterion("approveDate is not null");
            return (Criteria) this;
        }

        public Criteria andApprovedateEqualTo(Date value) {
            addCriterion("approveDate =", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateNotEqualTo(Date value) {
            addCriterion("approveDate <>", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateGreaterThan(Date value) {
            addCriterion("approveDate >", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateGreaterThanOrEqualTo(Date value) {
            addCriterion("approveDate >=", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateLessThan(Date value) {
            addCriterion("approveDate <", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateLessThanOrEqualTo(Date value) {
            addCriterion("approveDate <=", value, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateIn(List<Date> values) {
            addCriterion("approveDate in", values, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateNotIn(List<Date> values) {
            addCriterion("approveDate not in", values, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateBetween(Date value1, Date value2) {
            addCriterion("approveDate between", value1, value2, "approvedate");
            return (Criteria) this;
        }

        public Criteria andApprovedateNotBetween(Date value1, Date value2) {
            addCriterion("approveDate not between", value1, value2, "approvedate");
            return (Criteria) this;
        }

        public Criteria andSchedulecommentIsNull() {
            addCriterion("scheduleComment is null");
            return (Criteria) this;
        }

        public Criteria andSchedulecommentIsNotNull() {
            addCriterion("scheduleComment is not null");
            return (Criteria) this;
        }

        public Criteria andSchedulecommentEqualTo(String value) {
            addCriterion("scheduleComment =", value, "schedulecomment");
            return (Criteria) this;
        }

        public Criteria andSchedulecommentNotEqualTo(String value) {
            addCriterion("scheduleComment <>", value, "schedulecomment");
            return (Criteria) this;
        }

        public Criteria andSchedulecommentGreaterThan(String value) {
            addCriterion("scheduleComment >", value, "schedulecomment");
            return (Criteria) this;
        }

        public Criteria andSchedulecommentGreaterThanOrEqualTo(String value) {
            addCriterion("scheduleComment >=", value, "schedulecomment");
            return (Criteria) this;
        }

        public Criteria andSchedulecommentLessThan(String value) {
            addCriterion("scheduleComment <", value, "schedulecomment");
            return (Criteria) this;
        }

        public Criteria andSchedulecommentLessThanOrEqualTo(String value) {
            addCriterion("scheduleComment <=", value, "schedulecomment");
            return (Criteria) this;
        }

        public Criteria andSchedulecommentLike(String value) {
            addCriterion("scheduleComment like", value, "schedulecomment");
            return (Criteria) this;
        }

        public Criteria andSchedulecommentNotLike(String value) {
            addCriterion("scheduleComment not like", value, "schedulecomment");
            return (Criteria) this;
        }

        public Criteria andSchedulecommentIn(List<String> values) {
            addCriterion("scheduleComment in", values, "schedulecomment");
            return (Criteria) this;
        }

        public Criteria andSchedulecommentNotIn(List<String> values) {
            addCriterion("scheduleComment not in", values, "schedulecomment");
            return (Criteria) this;
        }

        public Criteria andSchedulecommentBetween(String value1, String value2) {
            addCriterion("scheduleComment between", value1, value2, "schedulecomment");
            return (Criteria) this;
        }

        public Criteria andSchedulecommentNotBetween(String value1, String value2) {
            addCriterion("scheduleComment not between", value1, value2, "schedulecomment");
            return (Criteria) this;
        }

        public Criteria andScheduleattachmentIsNull() {
            addCriterion("scheduleAttachment is null");
            return (Criteria) this;
        }

        public Criteria andScheduleattachmentIsNotNull() {
            addCriterion("scheduleAttachment is not null");
            return (Criteria) this;
        }

        public Criteria andScheduleattachmentEqualTo(String value) {
            addCriterion("scheduleAttachment =", value, "scheduleattachment");
            return (Criteria) this;
        }

        public Criteria andScheduleattachmentNotEqualTo(String value) {
            addCriterion("scheduleAttachment <>", value, "scheduleattachment");
            return (Criteria) this;
        }

        public Criteria andScheduleattachmentGreaterThan(String value) {
            addCriterion("scheduleAttachment >", value, "scheduleattachment");
            return (Criteria) this;
        }

        public Criteria andScheduleattachmentGreaterThanOrEqualTo(String value) {
            addCriterion("scheduleAttachment >=", value, "scheduleattachment");
            return (Criteria) this;
        }

        public Criteria andScheduleattachmentLessThan(String value) {
            addCriterion("scheduleAttachment <", value, "scheduleattachment");
            return (Criteria) this;
        }

        public Criteria andScheduleattachmentLessThanOrEqualTo(String value) {
            addCriterion("scheduleAttachment <=", value, "scheduleattachment");
            return (Criteria) this;
        }

        public Criteria andScheduleattachmentLike(String value) {
            addCriterion("scheduleAttachment like", value, "scheduleattachment");
            return (Criteria) this;
        }

        public Criteria andScheduleattachmentNotLike(String value) {
            addCriterion("scheduleAttachment not like", value, "scheduleattachment");
            return (Criteria) this;
        }

        public Criteria andScheduleattachmentIn(List<String> values) {
            addCriterion("scheduleAttachment in", values, "scheduleattachment");
            return (Criteria) this;
        }

        public Criteria andScheduleattachmentNotIn(List<String> values) {
            addCriterion("scheduleAttachment not in", values, "scheduleattachment");
            return (Criteria) this;
        }

        public Criteria andScheduleattachmentBetween(String value1, String value2) {
            addCriterion("scheduleAttachment between", value1, value2, "scheduleattachment");
            return (Criteria) this;
        }

        public Criteria andScheduleattachmentNotBetween(String value1, String value2) {
            addCriterion("scheduleAttachment not between", value1, value2, "scheduleattachment");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeIsNull() {
            addCriterion("attachmentType is null");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeIsNotNull() {
            addCriterion("attachmentType is not null");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeEqualTo(String value) {
            addCriterion("attachmentType =", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeNotEqualTo(String value) {
            addCriterion("attachmentType <>", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeGreaterThan(String value) {
            addCriterion("attachmentType >", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeGreaterThanOrEqualTo(String value) {
            addCriterion("attachmentType >=", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeLessThan(String value) {
            addCriterion("attachmentType <", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeLessThanOrEqualTo(String value) {
            addCriterion("attachmentType <=", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeLike(String value) {
            addCriterion("attachmentType like", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeNotLike(String value) {
            addCriterion("attachmentType not like", value, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeIn(List<String> values) {
            addCriterion("attachmentType in", values, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeNotIn(List<String> values) {
            addCriterion("attachmentType not in", values, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeBetween(String value1, String value2) {
            addCriterion("attachmentType between", value1, value2, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andAttachmenttypeNotBetween(String value1, String value2) {
            addCriterion("attachmentType not between", value1, value2, "attachmenttype");
            return (Criteria) this;
        }

        public Criteria andScheduleremarkIsNull() {
            addCriterion("scheduleRemark is null");
            return (Criteria) this;
        }

        public Criteria andScheduleremarkIsNotNull() {
            addCriterion("scheduleRemark is not null");
            return (Criteria) this;
        }

        public Criteria andScheduleremarkEqualTo(String value) {
            addCriterion("scheduleRemark =", value, "scheduleremark");
            return (Criteria) this;
        }

        public Criteria andScheduleremarkNotEqualTo(String value) {
            addCriterion("scheduleRemark <>", value, "scheduleremark");
            return (Criteria) this;
        }

        public Criteria andScheduleremarkGreaterThan(String value) {
            addCriterion("scheduleRemark >", value, "scheduleremark");
            return (Criteria) this;
        }

        public Criteria andScheduleremarkGreaterThanOrEqualTo(String value) {
            addCriterion("scheduleRemark >=", value, "scheduleremark");
            return (Criteria) this;
        }

        public Criteria andScheduleremarkLessThan(String value) {
            addCriterion("scheduleRemark <", value, "scheduleremark");
            return (Criteria) this;
        }

        public Criteria andScheduleremarkLessThanOrEqualTo(String value) {
            addCriterion("scheduleRemark <=", value, "scheduleremark");
            return (Criteria) this;
        }

        public Criteria andScheduleremarkLike(String value) {
            addCriterion("scheduleRemark like", value, "scheduleremark");
            return (Criteria) this;
        }

        public Criteria andScheduleremarkNotLike(String value) {
            addCriterion("scheduleRemark not like", value, "scheduleremark");
            return (Criteria) this;
        }

        public Criteria andScheduleremarkIn(List<String> values) {
            addCriterion("scheduleRemark in", values, "scheduleremark");
            return (Criteria) this;
        }

        public Criteria andScheduleremarkNotIn(List<String> values) {
            addCriterion("scheduleRemark not in", values, "scheduleremark");
            return (Criteria) this;
        }

        public Criteria andScheduleremarkBetween(String value1, String value2) {
            addCriterion("scheduleRemark between", value1, value2, "scheduleremark");
            return (Criteria) this;
        }

        public Criteria andScheduleremarkNotBetween(String value1, String value2) {
            addCriterion("scheduleRemark not between", value1, value2, "scheduleremark");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}