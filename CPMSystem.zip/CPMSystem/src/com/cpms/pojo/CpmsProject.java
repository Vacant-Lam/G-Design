package com.cpms.pojo;

import java.util.Date;

public class CpmsProject {
    private String projectid;

    private String projectname;

    private Date projectstarttime;

    private Date projectendtime;

    private String projectarea;

    private String projectaddress;

    private String projectduration;

    private Integer projectquantitiesestimate;

    private Double projectcostestimate;

    private Double projectprofitestimate;

    private String projectqualitylevel;

    private String projecttrackerid;

    private String projectstatus;

    private Date projectdate;

    private String projectremark;

    public String getProjectid() {
        return projectid;
    }

    public void setProjectid(String projectid) {
        this.projectid = projectid == null ? null : projectid.trim();
    }

    public String getProjectname() {
        return projectname;
    }

    public void setProjectname(String projectname) {
        this.projectname = projectname == null ? null : projectname.trim();
    }

    public Date getProjectstarttime() {
        return projectstarttime;
    }

    public void setProjectstarttime(Date projectstarttime) {
        this.projectstarttime = projectstarttime;
    }

    public Date getProjectendtime() {
        return projectendtime;
    }

    public void setProjectendtime(Date projectendtime) {
        this.projectendtime = projectendtime;
    }

    public String getProjectarea() {
        return projectarea;
    }

    public void setProjectarea(String projectarea) {
        this.projectarea = projectarea == null ? null : projectarea.trim();
    }

    public String getProjectaddress() {
        return projectaddress;
    }

    public void setProjectaddress(String projectaddress) {
        this.projectaddress = projectaddress == null ? null : projectaddress.trim();
    }

    public String getProjectduration() {
        return projectduration;
    }

    public void setProjectduration(String projectduration) {
        this.projectduration = projectduration == null ? null : projectduration.trim();
    }

    public Integer getProjectquantitiesestimate() {
        return projectquantitiesestimate;
    }

    public void setProjectquantitiesestimate(Integer projectquantitiesestimate) {
        this.projectquantitiesestimate = projectquantitiesestimate;
    }

    public Double getProjectcostestimate() {
        return projectcostestimate;
    }

    public void setProjectcostestimate(Double projectcostestimate) {
        this.projectcostestimate = projectcostestimate;
    }

    public Double getProjectprofitestimate() {
        return projectprofitestimate;
    }

    public void setProjectprofitestimate(Double projectprofitestimate) {
        this.projectprofitestimate = projectprofitestimate;
    }

    public String getProjectqualitylevel() {
        return projectqualitylevel;
    }

    public void setProjectqualitylevel(String projectqualitylevel) {
        this.projectqualitylevel = projectqualitylevel;
    }

    public String getProjecttrackerid() {
        return projecttrackerid;
    }

    public void setProjecttrackerid(String projecttrackerid) {
        this.projecttrackerid = projecttrackerid == null ? null : projecttrackerid.trim();
    }

    public String getProjectstatus() {
        return projectstatus;
    }

    public void setProjectstatus(String projectstatus) {
        this.projectstatus = projectstatus;
    }

    public Date getProjectdate() {
        return projectdate;
    }

    public void setProjectdate(Date projectdate) {
        this.projectdate = projectdate;
    }

    public String getProjectremark() {
        return projectremark;
    }

    public void setProjectremark(String projectremark) {
        this.projectremark = projectremark == null ? null : projectremark.trim();
    }
}